import SwiftUI
import Observation

@MainActor
@Observable
final class AppState {
    let health = HealthKitService()
    let watch = PhoneWatchSession.shared

    var selectedTab: AppTab = .home
    var activeWorkout: WorkoutLaunch?
    var lastCompletion: WorkoutCompletion?

    var toast: ToastMessage?
    @ObservationIgnored private var toastTask: Task<Void, Never>?

    func showToast(
        _ message: String,
        symbol: String = "checkmark.circle.fill",
        tone: ToastMessage.Tone = .success
    ) {
        let toast = ToastMessage(message: message, symbol: symbol, tone: tone)
        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
            self.toast = toast
        }
        Haptics.tap()

        toastTask?.cancel()
        toastTask = Task { [weak self] in
            try? await Task.sleep(for: .seconds(2.8))
            guard !Task.isCancelled else { return }
            await MainActor.run {
                guard self?.toast?.id == toast.id else { return }
                withAnimation(.easeOut(duration: 0.25)) {
                    self?.toast = nil
                }
            }
        }
    }
}
