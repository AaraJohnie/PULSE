import SwiftUI
import SwiftData

enum AppTab: String, CaseIterable, Identifiable, Hashable {
    case home
    case train
    case insights
    case fuel
    case you

    var id: String { rawValue }

    var title: String {
        switch self {
        case .home: "Home"
        case .train: "Train"
        case .insights: "Insights"
        case .fuel: "Fuel"
        case .you: "You"
        }
    }

    var symbol: String {
        switch self {
        case .home: "house"
        case .train: "figure.strengthtraining.traditional"
        case .insights: "chart.xyaxis.line"
        case .fuel: "fork.knife"
        case .you: "person.crop.circle"
        }
    }
}

struct MainTabView: View {
    @Environment(AppState.self) private var app
    @Environment(\.modelContext) private var context
    @Environment(\.scenePhase) private var scenePhase
    let profile: UserProfile

    var body: some View {
        @Bindable var app = app

        TabView(selection: $app.selectedTab) {
            NavigationStack {
                HomeView(profile: profile)
            }
            .tabItem { Label(AppTab.home.title, systemImage: AppTab.home.symbol) }
            .tag(AppTab.home)

            NavigationStack {
                TrainView(profile: profile)
            }
            .tabItem { Label(AppTab.train.title, systemImage: AppTab.train.symbol) }
            .tag(AppTab.train)

            NavigationStack {
                InsightsView(profile: profile)
            }
            .tabItem { Label(AppTab.insights.title, systemImage: AppTab.insights.symbol) }
            .tag(AppTab.insights)

            NavigationStack {
                FuelView(profile: profile)
            }
            .tabItem { Label(AppTab.fuel.title, systemImage: AppTab.fuel.symbol) }
            .tag(AppTab.fuel)

            NavigationStack {
                YouView(profile: profile)
            }
            .tabItem { Label(AppTab.you.title, systemImage: AppTab.you.symbol) }
            .tag(AppTab.you)
        }
        .tint(PulseColor.accent)
        .toolbarBackground(PulseColor.surface, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
        .fullScreenCover(item: $app.activeWorkout) { launch in
            ActiveWorkoutView(launch: launch)
                .environment(app)
        }
        .overlay(alignment: .bottom) {
            if let toast = app.toast {
                PulseToastView(toast: toast)
                    .padding(.bottom, 74)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .allowsHitTesting(false)
            }
        }
        .onChange(of: app.watch.pendingWorkout) { _, payload in
            guard let payload else { return }
            ingestWatchWorkout(payload)
        }
        .onChange(of: profile.unitSystem) { _, _ in
            publishWatchPreferences()
        }
        .onChange(of: profile.calorieGoal) { _, _ in
            publishWatchPreferences()
        }
        .onChange(of: scenePhase) { _, phase in
            guard phase == .active else { return }
            Task {
                await app.health.refresh(days: 30, force: true)
            }
        }
        .task {
            await app.health.refresh(days: 30, force: true)
            publishWatchPreferences()
            if let pending = app.watch.pendingWorkout {
                ingestWatchWorkout(pending)
            }
        }
    }

    private var watchMoveGoal: Double {
        max(320, (Double(profile.calorieGoal) * 0.12).rounded())
    }

    private func publishWatchPreferences() {
        app.watch.publishPreferences(units: profile.unitSystem, moveGoal: watchMoveGoal)
    }

    private func ingestWatchWorkout(_ payload: WatchWorkoutPayload) {
        guard !contextContains(sessionID: payload.id) else {
            app.watch.pendingWorkout = nil
            return
        }
        let calories = payload.activeEnergy
            ?? WorkoutAnalytics.estimatedCalories(
                category: payload.category,
                minutes: Double(payload.durationMinutes),
                weightKg: profile.weightKg
            )
        let session = WorkoutSession(
            id: payload.id,
            title: payload.title,
            category: payload.category,
            startedAt: payload.startedAt,
            endedAt: payload.endedAt,
            estimatedCalories: calories,
            averageHeartRate: payload.averageHeartRate,
            maxHeartRate: payload.maxHeartRate,
            distanceMeters: payload.distanceMeters,
            isFromWatch: true
        )
        context.insert(session)
        try? context.save()
        app.watch.pendingWorkout = nil
        Haptics.success()
        app.showToast("Watch workout added to your history", symbol: "applewatch")
    }

    private func contextContains(sessionID: UUID) -> Bool {
        let descriptor = FetchDescriptor<WorkoutSession>()
        let sessions = (try? context.fetch(descriptor)) ?? []
        return sessions.contains { $0.id == sessionID }
    }
}
