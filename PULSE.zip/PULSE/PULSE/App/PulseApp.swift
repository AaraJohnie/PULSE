import SwiftUI
import SwiftData

@main
struct PulseApp: App {
    @State private var appState = AppState()
    private let container = PulseStore.makeContainer()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environment(appState)
                .modelContainer(container)
        }
    }
}
