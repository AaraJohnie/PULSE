import SwiftUI
import SwiftData

struct RootView: View {
    @Environment(AppState.self) private var app
    @Environment(\.modelContext) private var context
    @Query(sort: \UserProfile.createdAt) private var profiles: [UserProfile]

    private var profile: UserProfile? { profiles.first }

    var body: some View {
        Group {
            if let profile {
                if profile.onboardingCompleted {
                    MainTabView(profile: profile)
                        .transition(.opacity)
                } else {
                    OnboardingFlowView(profile: profile)
                        .transition(.opacity)
                }
            } else {
                OnboardingFlowView()
                    .transition(.opacity)
            }
        }
        .tint(PulseColor.accent)
        .preferredColorScheme(profile?.appearance.colorScheme)
        .animation(.easeInOut(duration: 0.35), value: profile?.onboardingCompleted)
        .onAppear {
            app.watch.activate()
        }
        .task(id: profile?.healthKitRequested) {
            await app.health.prepare(requested: profile?.healthKitRequested == true)
        }
    }
}
