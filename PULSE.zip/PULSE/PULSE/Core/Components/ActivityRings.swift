import SwiftUI

struct PulseRing: View {
    var progress: Double
    var color: Color
    var lineWidth: CGFloat
    var trackOpacity: Double = 0.16
    @State private var animated: Double = 0
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        ZStack {
            Circle()
                .stroke(color.opacity(trackOpacity), lineWidth: lineWidth)

            Circle()
                .trim(from: 0, to: min(max(animated, 0), 1))
                .stroke(
                    AngularGradient(
                        colors: [color.opacity(0.55), color, color.opacity(0.9)],
                        center: .center,
                        startAngle: .degrees(-90),
                        endAngle: .degrees(270)
                    ),
                    style: StrokeStyle(lineWidth: lineWidth, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
                .animation(.easeOut(duration: 1.05), value: animated)
        }
        .onAppear {
            if reduceMotion {
                animated = progress
            } else {
                withAnimation(.easeOut(duration: 1.05)) {
                    animated = progress
                }
            }
        }
        .onChange(of: progress) { _, newValue in
            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.8)) {
                animated = newValue
            }
        }
    }
}

struct ActivityRings: View {
    var move: Double
    var exercise: Double
    var stand: Double
    var size: CGFloat = 156
    var lineWidth: CGFloat = 14
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        ZStack {
            PulseRing(progress: move, color: PulseColor.ringMove, lineWidth: lineWidth)
            PulseRing(progress: exercise, color: PulseColor.ringExercise, lineWidth: lineWidth)
                .padding(lineWidth + 6)
            PulseRing(progress: stand, color: PulseColor.ringStand, lineWidth: lineWidth)
                .padding((lineWidth + 6) * 2)
        }
        .frame(width: size, height: size)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Activity rings")
        .accessibilityValue("Move \(Int(move * 100)) percent, exercise \(Int(exercise * 100)) percent, stand \(Int(stand * 100)) percent")
    }
}

struct PulseProgressBar: View {
    var value: Double
    var tint: Color = PulseColor.accent
    var height: CGFloat = 8
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Capsule()
                    .fill(PulseColor.surfaceMuted)
                Capsule()
                    .fill(tint)
                    .frame(width: max(0, min(value, 1) * geometry.size.width))
                    .animation(reduceMotion ? nil : .spring(response: 0.5, dampingFraction: 0.85), value: value)
            }
        }
        .frame(height: height)
        .accessibilityElement()
        .accessibilityLabel("Progress")
        .accessibilityValue("\(Int(min(max(value, 0), 1) * 100)) percent")
    }
}

struct PulseLogo: View {
    var size: CGFloat = 52
    var ringColor: Color = PulseColor.sage
    var waveColor: Color = PulseColor.ivory

    var body: some View {
        ZStack {
            Circle()
                .trim(from: 0.12, to: 0.88)
                .stroke(
                    ringColor,
                    style: StrokeStyle(lineWidth: size * 0.075, lineCap: .round)
                )
                .rotationEffect(.degrees(128))

            PulseWaveShape()
                .stroke(
                    waveColor,
                    style: StrokeStyle(lineWidth: size * 0.052, lineCap: .round, lineJoin: .round)
                )
                .padding(.horizontal, size * 0.23)

            Circle()
                .fill(waveColor)
                .frame(width: size * 0.075, height: size * 0.075)
                .offset(x: size * 0.27, y: -size * 0.27)
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }
}

struct PulseWaveShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let w = rect.width
        let h = rect.height
        let midY = rect.midY
        path.move(to: CGPoint(x: rect.minX, y: midY))
        path.addLine(to: CGPoint(x: rect.minX + w * 0.18, y: midY))
        path.addLine(to: CGPoint(x: rect.minX + w * 0.29, y: midY - h * 0.28))
        path.addLine(to: CGPoint(x: rect.minX + w * 0.42, y: midY + h * 0.34))
        path.addLine(to: CGPoint(x: rect.minX + w * 0.56, y: midY - h * 0.42))
        path.addLine(to: CGPoint(x: rect.minX + w * 0.68, y: midY + h * 0.16))
        path.addLine(to: CGPoint(x: rect.minX + w * 0.78, y: midY))
        path.addLine(to: CGPoint(x: rect.maxX, y: midY))
        return path
    }
}

struct PulseBrandMark: View {
    var size: CGFloat = 96
    var body: some View {
        PulseLogo(size: size, ringColor: PulseColor.sage, waveColor: PulseColor.ivory)
    }
}
