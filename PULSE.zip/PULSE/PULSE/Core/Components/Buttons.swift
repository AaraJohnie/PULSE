import SwiftUI

struct PulsePrimaryButtonStyle: ButtonStyle {
    var tint: Color = PulseColor.sage
    var foreground: Color = PulseColor.midnight
    var fullWidth: Bool = true

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(PulseFont.headline)
            .foregroundStyle(foreground)
            .frame(maxWidth: fullWidth ? .infinity : nil)
            .padding(.horizontal, 22)
            .padding(.vertical, 16)
            .background(tint, in: Capsule())
            .shadow(color: tint.opacity(0.22), radius: 14, y: 7)
            .opacity(configuration.isPressed ? 0.86 : 1)
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
            .animation(.spring(response: 0.24, dampingFraction: 0.8), value: configuration.isPressed)
    }
}

struct PulseSecondaryButtonStyle: ButtonStyle {
    var fullWidth: Bool = true

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(PulseFont.headline)
            .foregroundStyle(PulseColor.textPrimary)
            .frame(maxWidth: fullWidth ? .infinity : nil)
            .padding(.horizontal, 22)
            .padding(.vertical, 15)
            .background(PulseColor.surface, in: Capsule())
            .overlay(Capsule().strokeBorder(PulseColor.hairlineStrong, lineWidth: 1))
            .opacity(configuration.isPressed ? 0.72 : 1)
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
            .animation(.spring(response: 0.24, dampingFraction: 0.8), value: configuration.isPressed)
    }
}

struct PulseTertiaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(PulseFont.footnote.weight(.semibold))
            .foregroundStyle(PulseColor.accent)
            .opacity(configuration.isPressed ? 0.6 : 1)
    }
}

extension ButtonStyle where Self == PulsePrimaryButtonStyle {
    static var pulsePrimary: PulsePrimaryButtonStyle { .init() }
}

extension ButtonStyle where Self == PulseSecondaryButtonStyle {
    static var pulseSecondary: PulseSecondaryButtonStyle { .init() }
}

extension ButtonStyle where Self == PulseTertiaryButtonStyle {
    static var pulseTertiary: PulseTertiaryButtonStyle { .init() }
}

struct PulseIconButton: View {
    let symbol: String
    var size: CGFloat = 40
    var tint: Color = PulseColor.textPrimary
    var background: Color = PulseColor.surface
    var accessibilityLabel: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(tint)
                .frame(width: size, height: size)
                .background(background, in: Circle())
                .overlay(Circle().strokeBorder(PulseColor.hairline, lineWidth: 1))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(accessibilityLabel)
    }
}

struct PulseChip: View {
    let title: String
    var symbol: String?
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                if let symbol {
                    Image(systemName: symbol)
                        .font(.system(size: 11, weight: .semibold))
                }
                Text(title)
                    .font(PulseFont.footnote.weight(.medium))
            }
            .foregroundStyle(isSelected ? PulseColor.midnight : PulseColor.textSecondary)
            .padding(.horizontal, 14)
            .padding(.vertical, 9)
            .background(
                Capsule().fill(isSelected ? PulseColor.sage : PulseColor.surface)
            )
            .overlay(
                Capsule().strokeBorder(isSelected ? Color.clear : PulseColor.hairline, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .animation(.snappy(duration: 0.2), value: isSelected)
        .accessibilityAddTraits(isSelected ? .isSelected : [])
    }
}

struct PulseSegmentedControl<Item: Hashable>: View {
    let items: [Item]
    let label: (Item) -> String
    @Binding var selection: Item
    @Namespace private var namespace

    var body: some View {
        HStack(spacing: 2) {
            ForEach(items, id: \.self) { item in
                segment(for: item)
            }
        }
        .padding(4)
        .background(PulseColor.surfaceMuted.opacity(0.85), in: Capsule())
    }

    private func segment(for item: Item) -> some View {
        let isSelected = selection == item
        return Button {
            select(item)
        } label: {
            Text(label(item))
                .font(PulseFont.footnote.weight(.semibold))
                .foregroundStyle(isSelected ? PulseColor.textPrimary : PulseColor.textTertiary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 9)
                .background {
                    if isSelected {
                        selectedCapsule
                    }
                }
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(isSelected ? .isSelected : [])
    }

    private var selectedCapsule: some View {
        Capsule()
            .fill(PulseColor.surfaceRaised)
            .shadow(color: .black.opacity(0.08), radius: 6, y: 2)
            .matchedGeometryEffect(id: "segment", in: namespace)
    }

    private func select(_ item: Item) {
        withAnimation(.snappy(duration: 0.28)) {
            selection = item
        }
        Haptics.selection()
    }
}
