import SwiftUI

struct PulseCard<Content: View>: View {
    var padding: CGFloat
    var radius: CGFloat
    var fill: Color
    var strokeColor: Color?
    let content: Content

    init(
        padding: CGFloat = PulseMetrics.cardPadding,
        radius: CGFloat = PulseMetrics.cardRadius,
        fill: Color = PulseColor.surface,
        strokeColor: Color? = PulseColor.hairline,
        @ViewBuilder content: () -> Content
    ) {
        self.padding = padding
        self.radius = radius
        self.fill = fill
        self.strokeColor = strokeColor
        self.content = content()
    }

    var body: some View {
        content
            .padding(padding)
            .background(fill, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay {
                if let strokeColor {
                    RoundedRectangle(cornerRadius: radius, style: .continuous)
                        .strokeBorder(strokeColor, lineWidth: 1)
                }
            }
            .shadow(color: PulseColor.shadow.opacity(0.35), radius: 18, x: 0, y: 10)
    }
}

struct PulseSectionHeader: View {
    let overline: String?
    let title: String
    var actionTitle: String?
    var action: (() -> Void)?

    init(
        _ title: String,
        overline: String? = nil,
        actionTitle: String? = nil,
        action: (() -> Void)? = nil
    ) {
        self.title = title
        self.overline = overline
        self.actionTitle = actionTitle
        self.action = action
    }

    var body: some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 5) {
                if let overline {
                    Text(overline)
                        .pulseOverline()
                        .foregroundStyle(PulseColor.textTertiary)
                }
                Text(title)
                    .font(PulseFont.title3)
                    .foregroundStyle(PulseColor.textPrimary)
            }

            Spacer(minLength: 12)

            if let actionTitle, let action {
                Button(actionTitle, action: action)
                    .font(PulseFont.footnote.weight(.semibold))
                    .foregroundStyle(PulseColor.accent)
            }
        }
    }
}

struct PulsePageTitle: View {
    let eyebrow: String?
    let title: String
    var subtitle: String?

    init(_ title: String, eyebrow: String? = nil, subtitle: String? = nil) {
        self.title = title
        self.eyebrow = eyebrow
        self.subtitle = subtitle
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            if let eyebrow {
                Text(eyebrow)
                    .pulseOverline()
                    .foregroundStyle(PulseColor.textTertiary)
            }
            Text(title)
                .font(PulseFont.largeTitle)
                .foregroundStyle(PulseColor.textPrimary)
                .fixedSize(horizontal: false, vertical: true)
            if let subtitle {
                Text(subtitle)
                    .font(PulseFont.callout)
                    .foregroundStyle(PulseColor.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct PulseDivider: View {
    var body: some View {
        Rectangle()
            .fill(PulseColor.hairline)
            .frame(height: 1)
    }
}
