import SwiftUI

struct PulseEmptyState: View {
    let symbol: String
    let title: String
    let message: String
    var actionTitle: String?
    var action: (() -> Void)?
    var compact: Bool = false

    var body: some View {
        VStack(spacing: compact ? 10 : 14) {
            Image(systemName: symbol)
                .font(.system(size: compact ? 18 : 24, weight: .medium))
                .foregroundStyle(PulseColor.accent)
                .frame(width: compact ? 42 : 58, height: compact ? 42 : 58)
                .background(PulseColor.accentSoft, in: Circle())

            VStack(spacing: 5) {
                Text(title)
                    .font(PulseFont.headline)
                    .foregroundStyle(PulseColor.textPrimary)
                    .multilineTextAlignment(.center)
                Text(message)
                    .font(PulseFont.footnote)
                    .foregroundStyle(PulseColor.textSecondary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }

            if let actionTitle, let action {
                Button(actionTitle, action: action)
                    .buttonStyle(PulseSecondaryButtonStyle(fullWidth: false))
                    .padding(.top, 2)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, compact ? 22 : 32)
        .padding(.horizontal, 20)
    }
}

struct PulseLoadingLabel: View {
    var text: String = "Syncing Apple Health"

    var body: some View {
        HStack(spacing: 8) {
            ProgressView()
                .controlSize(.small)
                .tint(PulseColor.accent)
            Text(text)
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textSecondary)
        }
        .accessibilityElement(children: .combine)
    }
}

struct ToastMessage: Identifiable, Equatable {
    enum Tone: Equatable {
        case success
        case info
        case error
    }

    let id = UUID()
    let message: String
    var symbol: String = "checkmark.circle.fill"
    var tone: Tone = .success
}

struct PulseToastView: View {
    let toast: ToastMessage

    private var tint: Color {
        switch toast.tone {
        case .success: PulseColor.accent
        case .info: PulseColor.textPrimary
        case .error: PulseColor.danger
        }
    }

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: toast.symbol)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(tint)
            Text(toast.message)
                .font(PulseFont.footnote.weight(.medium))
                .foregroundStyle(PulseColor.textPrimary)
                .lineLimit(2)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(.regularMaterial, in: Capsule())
        .overlay(Capsule().strokeBorder(PulseColor.hairlineStrong, lineWidth: 1))
        .shadow(color: .black.opacity(0.18), radius: 18, y: 8)
        .padding(.horizontal, PulseMetrics.screenPadding)
    }
}
