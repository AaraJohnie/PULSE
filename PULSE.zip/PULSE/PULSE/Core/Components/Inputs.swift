import SwiftUI
import UIKit

struct PulseField: View {
    let title: String
    var placeholder: String = ""
    var unit: String?
    @Binding var text: String
    var keyboard: UIKeyboardType = .default
    var capitalization: TextInputAutocapitalization = .words
    var error: String?
    var hint: String?
    @FocusState private var isFocused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .pulseOverline()
                .foregroundStyle(PulseColor.textTertiary)

            HStack(alignment: .firstTextBaseline, spacing: 8) {
                TextField(placeholder, text: $text)
                    .font(PulseFont.text(23, weight: .medium))
                    .foregroundStyle(PulseColor.textPrimary)
                    .keyboardType(keyboard)
                    .textInputAutocapitalization(capitalization)
                    .autocorrectionDisabled(keyboard != .default)
                    .focused($isFocused)
                    .accessibilityLabel(title)

                if let unit {
                    Text(unit)
                        .font(PulseFont.footnote)
                        .foregroundStyle(PulseColor.textTertiary)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .strokeBorder(
                        error != nil ? PulseColor.danger.opacity(0.8) : (isFocused ? PulseColor.accent.opacity(0.8) : PulseColor.hairline),
                        lineWidth: 1
                    )
            }

            if let error {
                Text(error)
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.danger)
                    .transition(.opacity)
            } else if let hint {
                Text(hint)
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
            }
        }
        .animation(.easeOut(duration: 0.18), value: isFocused)
        .animation(.easeOut(duration: 0.18), value: error)
    }
}

struct PulseCounter: View {
    let title: String
    @Binding var value: Int
    var range: ClosedRange<Int>
    var step: Int = 1
    var unit: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .pulseOverline()
                .foregroundStyle(PulseColor.textTertiary)

            HStack(spacing: 16) {
                Button {
                    guard value - step >= range.lowerBound else { return }
                    withAnimation(.snappy(duration: 0.18)) { value -= step }
                    Haptics.selection()
                } label: {
                    Image(systemName: "minus")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(value - step >= range.lowerBound ? PulseColor.textPrimary : PulseColor.textTertiary)
                        .frame(width: 42, height: 42)
                        .background(PulseColor.surfaceMuted, in: Circle())
                }
                .buttonStyle(.plain)
                .disabled(value - step < range.lowerBound)
                .accessibilityLabel("Decrease \(title)")

                Spacer(minLength: 0)

                HStack(alignment: .firstTextBaseline, spacing: 5) {
                    Text("\(value)")
                        .font(PulseFont.number(32, weight: .semibold))
                        .foregroundStyle(PulseColor.textPrimary)
                        .contentTransition(.numericText(value: Double(value)))
                    if let unit {
                        Text(unit)
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textTertiary)
                    }
                }

                Spacer(minLength: 0)

                Button {
                    guard value + step <= range.upperBound else { return }
                    withAnimation(.snappy(duration: 0.18)) { value += step }
                    Haptics.selection()
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(value + step <= range.upperBound ? PulseColor.textPrimary : PulseColor.textTertiary)
                        .frame(width: 42, height: 42)
                        .background(PulseColor.surfaceMuted, in: Circle())
                }
                .buttonStyle(.plain)
                .disabled(value + step > range.upperBound)
                .accessibilityLabel("Increase \(title)")
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .strokeBorder(PulseColor.hairline, lineWidth: 1)
            }
        }
    }
}

struct PulseValueSlider: View {
    let title: String
    let valueText: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    var step: Double
    var minimumLabel: String
    var maximumLabel: String

    private var hapticTrigger: Int {
        Int((value / step).rounded())
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                Text(title)
                    .pulseOverline()
                    .foregroundStyle(PulseColor.textTertiary)
                Spacer()
                Text(valueText)
                    .font(PulseFont.number(22, weight: .semibold))
                    .foregroundStyle(PulseColor.textPrimary)
                    .contentTransition(.numericText())
            }

            Slider(value: $value, in: range, step: step)
                .tint(PulseColor.accent)
                .sensoryFeedback(.selection, trigger: hapticTrigger)
                .accessibilityLabel(title)
                .accessibilityValue(valueText)

            HStack {
                Text(minimumLabel)
                Spacer()
                Text(maximumLabel)
            }
            .font(PulseFont.caption)
            .foregroundStyle(PulseColor.textTertiary)
        }
        .padding(16)
        .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(PulseColor.hairline, lineWidth: 1)
        }
    }
}

struct PulseSheetHeader: View {
    let title: String
    var subtitle: String?
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(PulseFont.title)
                    .foregroundStyle(PulseColor.textPrimary)
                if let subtitle {
                    Text(subtitle)
                        .font(PulseFont.footnote)
                        .foregroundStyle(PulseColor.textSecondary)
                }
            }
            Spacer(minLength: 12)
            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(PulseColor.textSecondary)
                    .frame(width: 32, height: 32)
                    .background(PulseColor.surfaceMuted, in: Circle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Close")
        }
        .padding(.horizontal, PulseMetrics.screenPadding)
        .padding(.top, 20)
        .padding(.bottom, 12)
    }
}
