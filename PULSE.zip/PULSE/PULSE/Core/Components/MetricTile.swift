import SwiftUI

struct PulseMetricTile: View {
    let symbol: String
    let value: String
    var unit: String?
    let label: String
    var tint: Color = PulseColor.textPrimary
    var isLoading: Bool = false

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: symbol)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(tint)
                    .frame(width: 30, height: 30)
                    .background(tint.opacity(0.12), in: Circle())
                Spacer(minLength: 0)
            }

            HStack(alignment: .firstTextBaseline, spacing: 4) {
                if isLoading {
                    RoundedRectangle(cornerRadius: 5)
                        .fill(PulseColor.surfaceMuted)
                        .frame(width: 54, height: 24)
                } else {
                    Text(value)
                        .font(PulseFont.number(26, weight: .semibold))
                        .foregroundStyle(PulseColor.textPrimary)
                        .contentTransition(.numericText())
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                    if let unit {
                        Text(unit)
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                            .lineLimit(1)
                    }
                }
            }

            Text(label)
                .font(PulseFont.footnote)
                .foregroundStyle(PulseColor.textSecondary)
                .lineLimit(1)
        }
        .padding(16)
        .frame(maxWidth: .infinity, minHeight: 122, alignment: .leading)
        .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous)
                .strokeBorder(PulseColor.hairline, lineWidth: 1)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(label)
        .accessibilityValue(isLoading ? "Loading" : "\(value) \(unit ?? "")")
    }
}

struct PulseMiniStat: View {
    let value: String
    let label: String
    var tint: Color = PulseColor.textPrimary

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(value)
                .font(PulseFont.number(20, weight: .semibold))
                .foregroundStyle(tint)
                .contentTransition(.numericText())
            Text(label)
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .combine)
    }
}

struct PulsePillBadge: View {
    let text: String
    var symbol: String?
    var tint: Color = PulseColor.accent
    var filled: Bool = false

    var body: some View {
        HStack(spacing: 5) {
            if let symbol {
                Image(systemName: symbol)
                    .font(.system(size: 10, weight: .bold))
            }
            Text(text)
                .font(.system(size: 11, weight: .semibold))
                .tracking(0.2)
        }
        .foregroundStyle(filled ? PulseColor.midnight : tint)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(filled ? tint : tint.opacity(0.12), in: Capsule())
    }
}

struct PulseIconTile: View {
    let symbol: String
    var tint: Color = PulseColor.accent
    var size: CGFloat = 42

    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: size * 0.4, weight: .semibold))
            .foregroundStyle(tint)
            .frame(width: size, height: size)
            .background(tint.opacity(0.13), in: RoundedRectangle(cornerRadius: size * 0.32, style: .continuous))
    }
}
