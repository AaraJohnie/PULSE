import SwiftUI

struct PreviewDataBanner: View {
    var onManage: (() -> Void)?
    var compact: Bool = false

    var body: some View {
        HStack(alignment: .center, spacing: 10) {
            Image(systemName: "eyeglasses")
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(PulseColor.warning)
                .frame(width: 26, height: 26)
                .background(PulseColor.warning.opacity(0.14), in: Circle())

            VStack(alignment: .leading, spacing: 1) {
                Text("Preview data")
                    .font(PulseFont.caption.weight(.semibold))
                    .foregroundStyle(PulseColor.textPrimary)
                if !compact {
                    Text("Sample records for exploring PULSE — not your Health data.")
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }

            Spacer(minLength: 8)

            if let onManage {
                Button("Manage", action: onManage)
                    .font(PulseFont.caption.weight(.semibold))
                    .foregroundStyle(PulseColor.accent)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 9)
        .background(PulseColor.surfaceMuted.opacity(0.75), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(PulseColor.warning.opacity(0.22), lineWidth: 1)
        }
        .accessibilityElement(children: .combine)
    }
}
