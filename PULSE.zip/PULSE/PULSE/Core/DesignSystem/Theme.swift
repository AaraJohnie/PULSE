import SwiftUI
import UIKit

// MARK: - Brand palette

enum PulseColor {
    static let midnight = Color(hex: 0x101212)
    static let graphite = Color(hex: 0x242A27)
    static let sage = Color(hex: 0xB5D8BE)
    static let ivory = Color(hex: 0xF2F0E9)

    static let background = Color(light: 0xF2F0E9, dark: 0x101212)
    static let backgroundDeep = Color(light: 0xE9E6DC, dark: 0x0B0D0C)
    static let surface = Color(light: 0xFBFAF4, dark: 0x171C19)
    static let surfaceRaised = Color(light: 0xFFFFFF, dark: 0x1D2420)
    static let surfaceMuted = Color(light: 0xEAE6DB, dark: 0x222925)
    static let surfaceInverse = Color(light: 0x1A1F1C, dark: 0x242A27)

    static let textPrimary = Color(light: 0x101212, dark: 0xF2F0E9)
    static let textSecondary = Color(light: 0x5C645E, dark: 0xA6B1AA)
    static let textTertiary = Color(light: 0x8B928C, dark: 0x737E77)
    static let textInverse = Color(light: 0xF2F0E9, dark: 0x101212)

    static let hairline = Color(light: 0x101212, dark: 0xF2F0E9).opacity(0.08)
    static let hairlineStrong = Color(light: 0x101212, dark: 0xF2F0E9).opacity(0.14)

    static let accent = Color(light: 0x628B6F, dark: 0xB5D8BE)
    static let accentSoft = Color(light: 0xDCEADF, dark: 0x25372B)
    static let sageFixed = Color(hex: 0xB5D8BE)

    static let ringMove = Color(light: 0x6E967A, dark: 0xB5D8BE)
    static let ringExercise = Color(light: 0xB99358, dark: 0xE4CB9A)
    static let ringStand = Color(light: 0x648C97, dark: 0x9CC2CC)

    static let positive = Color(light: 0x5E8A6C, dark: 0xB5D8BE)
    static let warning = Color(light: 0xB99358, dark: 0xE4CB9A)
    static let danger = Color(light: 0xB56A5C, dark: 0xE2A294)

    static let chartPrimary = Color(light: 0x6E967A, dark: 0xB5D8BE)
    static let chartSecondary = Color(light: 0xC5A56C, dark: 0xE4CB9A)
    static let chartTertiary = Color(light: 0x7F9FA8, dark: 0xA9C9D1)

    static let shadow = Color.black.opacity(0.16)
}

extension Color {
    init(hex: UInt32, opacity: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: opacity
        )
    }

    init(light: UInt32, dark: UInt32) {
        self.init(uiColor: UIColor { traits in
            UIColor(hex: traits.userInterfaceStyle == .dark ? dark : light)
        })
    }
}

extension UIColor {
    convenience init(hex: UInt32, alpha: CGFloat = 1) {
        self.init(
            red: CGFloat((hex >> 16) & 0xFF) / 255,
            green: CGFloat((hex >> 8) & 0xFF) / 255,
            blue: CGFloat(hex & 0xFF) / 255,
            alpha: alpha
        )
    }
}

// MARK: - Typography

enum PulseFont {
    static func number(_ size: CGFloat, weight: Font.Weight = .semibold) -> Font {
        .system(size: size, weight: weight, design: .rounded).monospacedDigit()
    }

    static func text(_ size: CGFloat, weight: Font.Weight = .regular) -> Font {
        .system(size: size, weight: weight, design: .default)
    }

    static let display = Font.system(size: 36, weight: .semibold, design: .default)
    static let largeTitle = Font.system(size: 32, weight: .semibold, design: .default)
    static let title = Font.system(size: 24, weight: .semibold, design: .default)
    static let title3 = Font.system(size: 19, weight: .semibold, design: .default)
    static let headline = Font.system(size: 16, weight: .semibold, design: .default)
    static let body = Font.system(size: 16, weight: .regular, design: .default)
    static let callout = Font.system(size: 15, weight: .regular, design: .default)
    static let footnote = Font.system(size: 13, weight: .regular, design: .default)
    static let caption = Font.system(size: 12, weight: .medium, design: .default)
    static let overline = Font.system(size: 11, weight: .semibold, design: .default)
}

// MARK: - Layout constants

enum PulseMetrics {
    static let screenPadding: CGFloat = 20
    static let cardPadding: CGFloat = 20
    static let cardRadius: CGFloat = 26
    static let tileRadius: CGFloat = 20
    static let buttonRadius: CGFloat = 18
    static let sectionSpacing: CGFloat = 28
    static let itemSpacing: CGFloat = 12
}

// MARK: - Gradients

enum PulseGradient {
    static var sageGlow: RadialGradient {
        RadialGradient(
            colors: [PulseColor.sage.opacity(0.22), PulseColor.sage.opacity(0.0)],
            center: .topTrailing,
            startRadius: 10,
            endRadius: 420
        )
    }

    static var hero: LinearGradient {
        LinearGradient(
            colors: [Color(hex: 0x232B27), Color(hex: 0x141816)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    static var sage: LinearGradient {
        LinearGradient(
            colors: [Color(hex: 0xCBE7D2), Color(hex: 0xA3C9AE)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    static var ringMove: AngularGradient {
        AngularGradient(
            colors: [PulseColor.ringMove.opacity(0.45), PulseColor.ringMove],
            center: .center
        )
    }
}

// MARK: - Background

struct PulseScreenBackground: View {
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        ZStack {
            PulseColor.background

            if colorScheme == .dark {
                PulseGradient.sageGlow
                    .opacity(0.55)
                    .ignoresSafeArea()
            } else {
                LinearGradient(
                    colors: [Color.white.opacity(0.65), PulseColor.background.opacity(0)],
                    startPoint: .top,
                    endPoint: .center
                )
                .ignoresSafeArea()
            }
        }
        .ignoresSafeArea()
    }
}

extension View {
    func pulseScreen() -> some View {
        self.background(PulseScreenBackground())
    }

    func pulseOverline() -> some View {
        self.font(PulseFont.overline)
            .tracking(1.3)
            .textCase(.uppercase)
    }
}
