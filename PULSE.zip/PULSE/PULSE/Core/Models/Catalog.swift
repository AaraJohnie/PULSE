import Foundation

struct Exercise: Identifiable, Hashable {
    let id: String
    let name: String
    let category: WorkoutCategory
    let muscles: [MuscleGroup]
    let equipment: Equipment
    let instructions: [String]

    var primaryMuscle: MuscleGroup { muscles.first ?? .fullBody }

    var muscleSummary: String {
        muscles.map(\.label).joined(separator: " · ")
    }
}

enum ExerciseCatalog {
    static let all: [Exercise] = [
        Exercise(
            id: "push-up",
            name: "Push-Up",
            category: .strength,
            muscles: [.chest, .arms, .core],
            equipment: .bodyweight,
            instructions: [
                "Start in a high plank with hands slightly wider than your shoulders.",
                "Brace your core and lower your chest until your elbows reach about 90°.",
                "Press the floor away and return to a strong plank without flaring your ribs."
            ]
        ),
        Exercise(
            id: "dumbbell-bench-press",
            name: "Dumbbell Bench Press",
            category: .strength,
            muscles: [.chest, .arms],
            equipment: .dumbbell,
            instructions: [
                "Lie on a bench with feet planted and dumbbells stacked over your chest.",
                "Lower the dumbbells with control until your upper arms are level with the bench.",
                "Press up and slightly together, keeping your shoulder blades set."
            ]
        ),
        Exercise(
            id: "incline-dumbbell-press",
            name: "Incline Dumbbell Press",
            category: .strength,
            muscles: [.chest, .shoulders],
            equipment: .dumbbell,
            instructions: [
                "Set the bench to a low incline and plant both feet.",
                "Lower the dumbbells toward the upper chest with elbows under the wrists.",
                "Drive up without arching your lower back off the bench."
            ]
        ),
        Exercise(
            id: "cable-fly",
            name: "Cable Chest Fly",
            category: .strength,
            muscles: [.chest],
            equipment: .cable,
            instructions: [
                "Set the pulleys around chest height and take a split stance.",
                "With a soft elbow bend, bring your hands together in front of your sternum.",
                "Resist the handles back out until you feel a gentle stretch across the chest."
            ]
        ),
        Exercise(
            id: "bench-dip",
            name: "Bench Dip",
            category: .strength,
            muscles: [.chest, .arms],
            equipment: .bodyweight,
            instructions: [
                "Place your hands on a bench behind you with fingers pointing forward.",
                "Lower your hips close to the bench until your elbows reach about 90°.",
                "Press through your palms to rise without shrugging your shoulders."
            ]
        ),
        Exercise(
            id: "dumbbell-row",
            name: "Single-Arm Dumbbell Row",
            category: .strength,
            muscles: [.back, .arms],
            equipment: .dumbbell,
            instructions: [
                "Support one hand on a bench and let the dumbbell hang under your shoulder.",
                "Pull your elbow toward your hip, keeping your torso quiet.",
                "Lower until the arm is long, then repeat without twisting your lower back."
            ]
        ),
        Exercise(
            id: "lat-pulldown",
            name: "Lat Pulldown",
            category: .strength,
            muscles: [.back, .arms],
            equipment: .cable,
            instructions: [
                "Set the thigh pad snug and grip the bar slightly wider than your shoulders.",
                "Draw your shoulder blades down, then pull the bar toward your upper chest.",
                "Control the bar back up until your arms are long."
            ]
        ),
        Exercise(
            id: "barbell-row",
            name: "Barbell Bent-Over Row",
            category: .strength,
            muscles: [.back, .core],
            equipment: .barbell,
            instructions: [
                "Hinge at the hips until your torso is around 45°, back flat.",
                "Pull the bar toward your lower ribs and squeeze your shoulder blades.",
                "Lower under control without letting your chest drop."
            ]
        ),
        Exercise(
            id: "pull-up",
            name: "Pull-Up",
            category: .strength,
            muscles: [.back, .arms],
            equipment: .bodyweight,
            instructions: [
                "Hang from the bar with a strong grip and slightly active shoulders.",
                "Pull your chest toward the bar while keeping ribs down.",
                "Lower slowly to a full hang. Use a band if you need assistance."
            ]
        ),
        Exercise(
            id: "face-pull",
            name: "Face Pull",
            category: .strength,
            muscles: [.shoulders, .back],
            equipment: .cable,
            instructions: [
                "Set the rope at eye height and hold with thumbs facing you.",
                "Pull the rope toward your forehead and rotate your knuckles up.",
                "Finish with elbows wide and shoulder blades gently squeezed."
            ]
        ),
        Exercise(
            id: "overhead-press",
            name: "Dumbbell Overhead Press",
            category: .strength,
            muscles: [.shoulders, .arms],
            equipment: .dumbbell,
            instructions: [
                "Stand tall with dumbbells at shoulder height and ribs stacked over hips.",
                "Press up and slightly back until your arms are overhead.",
                "Lower with control to the start, keeping your core braced."
            ]
        ),
        Exercise(
            id: "lateral-raise",
            name: "Lateral Raise",
            category: .strength,
            muscles: [.shoulders],
            equipment: .dumbbell,
            instructions: [
                "Hold light dumbbells at your sides with a soft elbow bend.",
                "Raise your arms out to the sides until they are near shoulder height.",
                "Lower slowly, avoiding momentum and shrugging."
            ]
        ),
        Exercise(
            id: "rear-delt-fly",
            name: "Rear Delt Fly",
            category: .strength,
            muscles: [.shoulders, .back],
            equipment: .dumbbell,
            instructions: [
                "Hinge forward with a flat back and let the dumbbells hang below your chest.",
                "Sweep your arms out to the sides with a slight elbow bend.",
                "Pause at the top, then lower under control."
            ]
        ),
        Exercise(
            id: "bicep-curl",
            name: "Dumbbell Bicep Curl",
            category: .strength,
            muscles: [.arms],
            equipment: .dumbbell,
            instructions: [
                "Stand tall with dumbbells at your sides and palms forward.",
                "Curl the weights without letting your elbows drift forward.",
                "Lower slowly to a fully extended arm."
            ]
        ),
        Exercise(
            id: "tricep-pushdown",
            name: "Triceps Pushdown",
            category: .strength,
            muscles: [.arms],
            equipment: .cable,
            instructions: [
                "Set the rope at chest height and pin your elbows near your ribs.",
                "Extend your arms down and spread the rope slightly.",
                "Return until your forearms are level, keeping elbows still."
            ]
        ),
        Exercise(
            id: "hammer-curl",
            name: "Hammer Curl",
            category: .strength,
            muscles: [.arms],
            equipment: .dumbbell,
            instructions: [
                "Hold dumbbells with neutral grips and elbows close to your body.",
                "Curl up while keeping the thumbs pointing toward the ceiling.",
                "Lower under control, avoiding a swing at the bottom."
            ]
        ),
        Exercise(
            id: "overhead-triceps-extension",
            name: "Overhead Triceps Extension",
            category: .strength,
            muscles: [.arms],
            equipment: .dumbbell,
            instructions: [
                "Hold one dumbbell overhead with both hands and ribs down.",
                "Lower the weight behind your head by bending at the elbows.",
                "Extend back up without letting your elbows flare wide."
            ]
        ),
        Exercise(
            id: "plank",
            name: "Forearm Plank",
            category: .strength,
            muscles: [.core],
            equipment: .bodyweight,
            instructions: [
                "Set elbows under shoulders and extend your legs behind you.",
                "Brace your abs and glutes so your body forms one line.",
                "Breathe steadily and stop when your lower back starts to dip."
            ]
        ),
        Exercise(
            id: "dead-bug",
            name: "Dead Bug",
            category: .strength,
            muscles: [.core],
            equipment: .bodyweight,
            instructions: [
                "Lie on your back with arms up and hips and knees at 90°.",
                "Press your lower back gently into the floor.",
                "Extend the opposite arm and leg slowly, then switch sides."
            ]
        ),
        Exercise(
            id: "hanging-leg-raise",
            name: "Hanging Leg Raise",
            category: .strength,
            muscles: [.core, .arms],
            equipment: .bodyweight,
            instructions: [
                "Hang from a bar with legs long and shoulders active.",
                "Curl your pelvis and raise your legs without swinging.",
                "Lower slowly and reset before the next rep."
            ]
        ),
        Exercise(
            id: "russian-twist",
            name: "Russian Twist",
            category: .strength,
            muscles: [.core],
            equipment: .bodyweight,
            instructions: [
                "Sit tall with knees bent and heels light on the floor.",
                "Rotate through your ribcage, reaching toward one hip.",
                "Move with control to the other side without collapsing your posture."
            ]
        ),
        Exercise(
            id: "side-plank",
            name: "Side Plank",
            category: .strength,
            muscles: [.core],
            equipment: .bodyweight,
            instructions: [
                "Set your elbow under your shoulder with legs stacked.",
                "Lift your hips until your body forms a straight line.",
                "Keep breathing and switch sides after your hold."
            ]
        ),
        Exercise(
            id: "hip-thrust",
            name: "Barbell Hip Thrust",
            category: .strength,
            muscles: [.glutes, .legs],
            equipment: .barbell,
            instructions: [
                "Rest your upper back on a bench with the bar across your hips.",
                "Tuck your ribs and drive your hips up until they are level with your torso.",
                "Squeeze your glutes at the top, then lower with control."
            ]
        ),
        Exercise(
            id: "glute-bridge",
            name: "Glute Bridge",
            category: .strength,
            muscles: [.glutes],
            equipment: .bodyweight,
            instructions: [
                "Lie on your back with heels planted close to your hips.",
                "Exhale and lift your pelvis, keeping ribs down.",
                "Pause at the top, then lower slowly."
            ]
        ),
        Exercise(
            id: "cable-kickback",
            name: "Cable Kickback",
            category: .strength,
            muscles: [.glutes],
            equipment: .cable,
            instructions: [
                "Attach an ankle strap and hold the frame for balance.",
                "Hinge slightly and sweep one leg back without arching your back.",
                "Squeeze the glute at the end range, then return slowly."
            ]
        ),
        Exercise(
            id: "step-up",
            name: "Dumbbell Step-Up",
            category: .strength,
            muscles: [.glutes, .legs],
            equipment: .dumbbell,
            instructions: [
                "Choose a box height where your knee is around 90° at the start.",
                "Drive through the lead foot to stand tall on the box.",
                "Lower with control and repeat without pushing off the trailing foot."
            ]
        ),
        Exercise(
            id: "goblet-squat",
            name: "Goblet Squat",
            category: .strength,
            muscles: [.legs, .glutes],
            equipment: .dumbbell,
            instructions: [
                "Hold one dumbbell at your chest and set your feet around shoulder width.",
                "Sit down between your hips with your chest proud.",
                "Drive through your whole foot to stand tall."
            ]
        ),
        Exercise(
            id: "romanian-deadlift",
            name: "Romanian Deadlift",
            category: .strength,
            muscles: [.legs, .glutes, .back],
            equipment: .barbell,
            instructions: [
                "Stand tall with the bar against your thighs and knees soft.",
                "Hinge your hips back, keeping the bar close and back flat.",
                "Stop when you feel a strong hamstring stretch, then drive your hips forward."
            ]
        ),
        Exercise(
            id: "walking-lunge",
            name: "Walking Lunge",
            category: .strength,
            muscles: [.legs, .glutes],
            equipment: .dumbbell,
            instructions: [
                "Hold dumbbells at your sides and take a controlled step forward.",
                "Lower until both knees are around 90°.",
                "Push through the front foot to step into the next lunge."
            ]
        ),
        Exercise(
            id: "leg-press",
            name: "Leg Press",
            category: .strength,
            muscles: [.legs],
            equipment: .machine,
            instructions: [
                "Set your feet around shoulder width and keep your lower back against the pad.",
                "Lower the sled until your knees are comfortably deep.",
                "Press through your feet without locking your knees hard."
            ]
        ),
        Exercise(
            id: "calf-raise",
            name: "Standing Calf Raise",
            category: .strength,
            muscles: [.legs],
            equipment: .machine,
            instructions: [
                "Stand tall with the balls of your feet on the platform.",
                "Rise as high as you can and pause for a second.",
                "Lower slowly until you feel a stretch in your calves."
            ]
        ),
        Exercise(
            id: "bulgarian-split-squat",
            name: "Bulgarian Split Squat",
            category: .strength,
            muscles: [.legs, .glutes],
            equipment: .dumbbell,
            instructions: [
                "Place your rear foot on a bench and step the front foot forward.",
                "Lower straight down until your front thigh is close to parallel.",
                "Drive through the front foot and keep your torso tall."
            ]
        ),
        Exercise(
            id: "kettlebell-swing",
            name: "Kettlebell Swing",
            category: .strength,
            muscles: [.fullBody, .glutes, .core],
            equipment: .kettlebell,
            instructions: [
                "Hinge and hike the kettlebell back between your legs.",
                "Snap your hips forward to float the bell to chest height.",
                "Let the bell fall back into the next hinge without rounding your back."
            ]
        ),
        Exercise(
            id: "burpee",
            name: "Burpee",
            category: .hiit,
            muscles: [.fullBody, .chest, .legs],
            equipment: .bodyweight,
            instructions: [
                "From standing, place your hands down and step or jump to a plank.",
                "Lower your chest, then press back up.",
                "Jump or step your feet forward and stand tall."
            ]
        ),
        Exercise(
            id: "mountain-climber",
            name: "Mountain Climber",
            category: .hiit,
            muscles: [.core, .fullBody],
            equipment: .bodyweight,
            instructions: [
                "Start in a high plank with shoulders stacked over wrists.",
                "Drive one knee toward your chest without bouncing your hips.",
                "Alternate legs at a pace you can control while breathing."
            ]
        ),
        Exercise(
            id: "cat-cow",
            name: "Cat-Cow",
            category: .mobility,
            muscles: [.back, .core],
            equipment: .none,
            instructions: [
                "Start on all fours with a long spine.",
                "Inhale to drop your belly and lift your chest and gaze.",
                "Exhale to round your spine and tuck your chin."
            ]
        ),
        Exercise(
            id: "world-greatest-stretch",
            name: "World's Greatest Stretch",
            category: .mobility,
            muscles: [.fullBody, .legs, .back],
            equipment: .none,
            instructions: [
                "Step into a low lunge and place both hands inside the front foot.",
                "Rotate your inside arm toward the ceiling and follow with your gaze.",
                "Return, shift back to straighten the front leg, then switch sides."
            ]
        ),
        Exercise(
            id: "hip-flexor-stretch",
            name: "Kneeling Hip Flexor Stretch",
            category: .mobility,
            muscles: [.legs, .glutes],
            equipment: .none,
            instructions: [
                "Kneel with one foot forward and tuck your pelvis under.",
                "Shift gently forward until you feel a stretch at the front hip.",
                "Keep your ribs down and breathe slowly before switching sides."
            ]
        ),
        Exercise(
            id: "thoracic-rotation",
            name: "Thoracic Rotation",
            category: .mobility,
            muscles: [.back, .shoulders],
            equipment: .none,
            instructions: [
                "Kneel on all fours and place one hand behind your head.",
                "Rotate that elbow toward the ceiling while keeping your hips square.",
                "Return slowly through the center and repeat."
            ]
        ),
        Exercise(
            id: "hamstring-stretch",
            name: "Standing Hamstring Stretch",
            category: .mobility,
            muscles: [.legs],
            equipment: .none,
            instructions: [
                "Place one heel on a low step with your leg straight.",
                "Hinge from your hips with a long spine until you feel the hamstring.",
                "Hold and breathe, then switch legs."
            ]
        ),
        Exercise(
            id: "childs-pose",
            name: "Child's Pose",
            category: .mobility,
            muscles: [.back],
            equipment: .none,
            instructions: [
                "Kneel and sit your hips back toward your heels.",
                "Walk your hands forward and let your forehead rest on the floor.",
                "Breathe into your back ribs and relax your shoulders."
            ]
        ),
        Exercise(
            id: "down-dog",
            name: "Downward Dog",
            category: .yoga,
            muscles: [.fullBody, .shoulders],
            equipment: .none,
            instructions: [
                "From all fours, lift your hips up and back.",
                "Press through your hands and keep a soft bend in your knees.",
                "Lengthen your spine and breathe steadily."
            ]
        ),
        Exercise(
            id: "sun-salutation",
            name: "Sun Salutation",
            category: .yoga,
            muscles: [.fullBody],
            equipment: .none,
            instructions: [
                "Move through standing, forward fold, plank and low lunge with your breath.",
                "Keep each transition smooth rather than forcing depth.",
                "Repeat for a few rounds until your body feels warm."
            ]
        ),
        Exercise(
            id: "easy-run",
            name: "Easy Run",
            category: .running,
            muscles: [.legs, .fullBody],
            equipment: .none,
            instructions: [
                "Run at a conversational pace you could hold all day.",
                "Keep your steps quick and light, with relaxed shoulders.",
                "Finish feeling like you could do a little more."
            ]
        ),
        Exercise(
            id: "treadmill-intervals",
            name: "Treadmill Intervals",
            category: .running,
            muscles: [.legs],
            equipment: .machine,
            instructions: [
                "Warm up for five minutes at an easy pace.",
                "Alternate one minute hard with two minutes easy.",
                "Cool down and bring your breathing back under control."
            ]
        ),
        Exercise(
            id: "stationary-bike",
            name: "Stationary Bike",
            category: .cycling,
            muscles: [.legs],
            equipment: .machine,
            instructions: [
                "Set the saddle so your knee is softly bent at the bottom.",
                "Ride at a steady aerobic effort with your upper body relaxed.",
                "Spin easy for the final five minutes."
            ]
        ),
        Exercise(
            id: "outdoor-ride",
            name: "Outdoor Ride",
            category: .cycling,
            muscles: [.legs, .fullBody],
            equipment: .none,
            instructions: [
                "Choose a route with manageable traffic and a smooth warm-up.",
                "Ride at a steady effort and fuel before you feel empty.",
                "Ease off for the final stretch to recover."
            ]
        )
    ]

    static func exercises(for category: WorkoutCategory) -> [Exercise] {
        all.filter { $0.category == category }
    }

    static func exercises(for muscle: MuscleGroup) -> [Exercise] {
        all.filter { $0.muscles.contains(muscle) || muscle == .fullBody }
    }

    static func exercise(id: String) -> Exercise? {
        all.first { $0.id == id }
    }

    static func search(_ query: String, muscle: MuscleGroup?) -> [Exercise] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        return all.filter { exercise in
            let matchesMuscle = muscle == nil || exercise.muscles.contains(muscle!)
            guard matchesMuscle else { return false }
            guard !trimmed.isEmpty else { return true }
            return exercise.name.localizedCaseInsensitiveContains(trimmed)
        }
    }
}

struct WorkoutPlan: Identifiable, Hashable {
    let id: String
    let name: String
    let tagline: String
    let category: WorkoutCategory
    let level: FitnessLevel
    let weeks: Int
    let daysPerWeek: Int
    let days: [PlanDay]

    var sessionCount: Int { days.count }
}

struct PlanDay: Identifiable, Hashable {
    let id: String
    let title: String
    let focus: String
    let estimatedMinutes: Int
    let exercises: [PlanExercise]
}

struct PlanExercise: Identifiable, Hashable {
    let exerciseID: String
    let sets: Int
    let reps: Int
    let restSeconds: Int

    var id: String { "\(exerciseID)-\(sets)-\(reps)" }

    var exercise: Exercise? {
        ExerciseCatalog.exercise(id: exerciseID)
    }
}

enum WorkoutPlans {
    static let all: [WorkoutPlan] = [foundation, strongLines, mobilityReset]

    static let foundation = WorkoutPlan(
        id: "foundation",
        name: "Foundation",
        tagline: "Three full-body sessions that build a base you can trust.",
        category: .strength,
        level: .beginner,
        weeks: 4,
        daysPerWeek: 3,
        days: [
            PlanDay(
                id: "foundation-a",
                title: "Full Body A",
                focus: "Squat · Press · Pull",
                estimatedMinutes: 42,
                exercises: [
                    PlanExercise(exerciseID: "goblet-squat", sets: 3, reps: 10, restSeconds: 90),
                    PlanExercise(exerciseID: "dumbbell-bench-press", sets: 3, reps: 10, restSeconds: 90),
                    PlanExercise(exerciseID: "dumbbell-row", sets: 3, reps: 10, restSeconds: 75),
                    PlanExercise(exerciseID: "romanian-deadlift", sets: 3, reps: 8, restSeconds: 90),
                    PlanExercise(exerciseID: "dead-bug", sets: 3, reps: 8, restSeconds: 60)
                ]
            ),
            PlanDay(
                id: "foundation-b",
                title: "Full Body B",
                focus: "Hinge · Shoulders · Lunge",
                estimatedMinutes: 44,
                exercises: [
                    PlanExercise(exerciseID: "hip-thrust", sets: 3, reps: 10, restSeconds: 90),
                    PlanExercise(exerciseID: "overhead-press", sets: 3, reps: 10, restSeconds: 90),
                    PlanExercise(exerciseID: "lat-pulldown", sets: 3, reps: 10, restSeconds: 75),
                    PlanExercise(exerciseID: "walking-lunge", sets: 3, reps: 8, restSeconds: 90),
                    PlanExercise(exerciseID: "russian-twist", sets: 3, reps: 12, restSeconds: 60)
                ]
            ),
            PlanDay(
                id: "foundation-c",
                title: "Full Body C",
                focus: "Power · Push · Pull",
                estimatedMinutes: 40,
                exercises: [
                    PlanExercise(exerciseID: "kettlebell-swing", sets: 4, reps: 12, restSeconds: 75),
                    PlanExercise(exerciseID: "incline-dumbbell-press", sets: 3, reps: 10, restSeconds: 90),
                    PlanExercise(exerciseID: "barbell-row", sets: 3, reps: 8, restSeconds: 90),
                    PlanExercise(exerciseID: "step-up", sets: 3, reps: 8, restSeconds: 75),
                    PlanExercise(exerciseID: "plank", sets: 3, reps: 30, restSeconds: 60)
                ]
            )
        ]
    )

    static let strongLines = WorkoutPlan(
        id: "strong-lines",
        name: "Strong Lines",
        tagline: "A focused upper, lower and full-body split for steady strength.",
        category: .strength,
        level: .intermediate,
        weeks: 6,
        daysPerWeek: 3,
        days: [
            PlanDay(
                id: "strong-upper",
                title: "Upper Strength",
                focus: "Press · Pull · Arms",
                estimatedMinutes: 52,
                exercises: [
                    PlanExercise(exerciseID: "dumbbell-bench-press", sets: 4, reps: 8, restSeconds: 120),
                    PlanExercise(exerciseID: "barbell-row", sets: 4, reps: 8, restSeconds: 120),
                    PlanExercise(exerciseID: "overhead-press", sets: 3, reps: 8, restSeconds: 90),
                    PlanExercise(exerciseID: "pull-up", sets: 3, reps: 6, restSeconds: 120),
                    PlanExercise(exerciseID: "hammer-curl", sets: 3, reps: 10, restSeconds: 60),
                    PlanExercise(exerciseID: "tricep-pushdown", sets: 3, reps: 12, restSeconds: 60)
                ]
            ),
            PlanDay(
                id: "strong-lower",
                title: "Lower Strength",
                focus: "Hinge · Squat · Glutes",
                estimatedMinutes: 50,
                exercises: [
                    PlanExercise(exerciseID: "romanian-deadlift", sets: 4, reps: 8, restSeconds: 120),
                    PlanExercise(exerciseID: "bulgarian-split-squat", sets: 3, reps: 8, restSeconds: 90),
                    PlanExercise(exerciseID: "leg-press", sets: 3, reps: 10, restSeconds: 90),
                    PlanExercise(exerciseID: "hip-thrust", sets: 3, reps: 10, restSeconds: 90),
                    PlanExercise(exerciseID: "calf-raise", sets: 3, reps: 15, restSeconds: 60)
                ]
            ),
            PlanDay(
                id: "strong-full",
                title: "Full Body Volume",
                focus: "Athletic · Balanced",
                estimatedMinutes: 46,
                exercises: [
                    PlanExercise(exerciseID: "kettlebell-swing", sets: 4, reps: 15, restSeconds: 75),
                    PlanExercise(exerciseID: "goblet-squat", sets: 3, reps: 12, restSeconds: 90),
                    PlanExercise(exerciseID: "cable-fly", sets: 3, reps: 12, restSeconds: 60),
                    PlanExercise(exerciseID: "face-pull", sets: 3, reps: 15, restSeconds: 60),
                    PlanExercise(exerciseID: "walking-lunge", sets: 3, reps: 10, restSeconds: 90),
                    PlanExercise(exerciseID: "side-plank", sets: 2, reps: 30, restSeconds: 45)
                ]
            )
        ]
    )

    static let mobilityReset = WorkoutPlan(
        id: "mobility-reset",
        name: "Mobility Reset",
        tagline: "Short, deliberate sessions to keep your body moving freely.",
        category: .mobility,
        level: .beginner,
        weeks: 2,
        daysPerWeek: 4,
        days: [
            PlanDay(
                id: "mobility-morning",
                title: "Morning Unwind",
                focus: "Spine · Hips · Breath",
                estimatedMinutes: 15,
                exercises: [
                    PlanExercise(exerciseID: "cat-cow", sets: 2, reps: 8, restSeconds: 20),
                    PlanExercise(exerciseID: "world-greatest-stretch", sets: 2, reps: 6, restSeconds: 20),
                    PlanExercise(exerciseID: "thoracic-rotation", sets: 2, reps: 8, restSeconds: 20),
                    PlanExercise(exerciseID: "childs-pose", sets: 2, reps: 5, restSeconds: 20)
                ]
            ),
            PlanDay(
                id: "mobility-desk",
                title: "Desk Reset",
                focus: "Neck · Shoulders · Hips",
                estimatedMinutes: 12,
                exercises: [
                    PlanExercise(exerciseID: "thoracic-rotation", sets: 2, reps: 8, restSeconds: 20),
                    PlanExercise(exerciseID: "hip-flexor-stretch", sets: 2, reps: 8, restSeconds: 20),
                    PlanExercise(exerciseID: "cat-cow", sets: 2, reps: 8, restSeconds: 20),
                    PlanExercise(exerciseID: "childs-pose", sets: 2, reps: 5, restSeconds: 20)
                ]
            ),
            PlanDay(
                id: "mobility-run",
                title: "Post-Run Downshift",
                focus: "Calves · Hamstrings · Back",
                estimatedMinutes: 14,
                exercises: [
                    PlanExercise(exerciseID: "hamstring-stretch", sets: 2, reps: 8, restSeconds: 20),
                    PlanExercise(exerciseID: "down-dog", sets: 2, reps: 5, restSeconds: 20),
                    PlanExercise(exerciseID: "hip-flexor-stretch", sets: 2, reps: 8, restSeconds: 20),
                    PlanExercise(exerciseID: "childs-pose", sets: 2, reps: 5, restSeconds: 20)
                ]
            ),
            PlanDay(
                id: "mobility-hips",
                title: "Deep Hips",
                focus: "Glutes · Hip flexors",
                estimatedMinutes: 16,
                exercises: [
                    PlanExercise(exerciseID: "world-greatest-stretch", sets: 2, reps: 6, restSeconds: 20),
                    PlanExercise(exerciseID: "hip-flexor-stretch", sets: 2, reps: 8, restSeconds: 20),
                    PlanExercise(exerciseID: "glute-bridge", sets: 2, reps: 12, restSeconds: 30),
                    PlanExercise(exerciseID: "cat-cow", sets: 2, reps: 8, restSeconds: 20)
                ]
            )
        ]
    )

    static func plan(id: String) -> WorkoutPlan? {
        all.first { $0.id == id }
    }
}

struct CardioTemplate: Identifiable, Hashable {
    let id: String
    let title: String
    let category: WorkoutCategory
    let focus: CardioSessionFocus
    let minutes: Int
    let summary: String
    let effort: String
}

enum CardioCatalog {
    static let all: [CardioTemplate] = [
        CardioTemplate(id: "easy-run", title: "Easy Run", category: .running, focus: .easy, minutes: 30, summary: "Conversational pace to build your aerobic base.", effort: "Zone 2"),
        CardioTemplate(id: "tempo-run", title: "Tempo Run", category: .running, focus: .tempo, minutes: 25, summary: "Comfortably hard, steady effort after a warm-up.", effort: "RPE 7"),
        CardioTemplate(id: "run-intervals", title: "Run Intervals", category: .running, focus: .intervals, minutes: 22, summary: "Six rounds of one minute fast, two minutes easy.", effort: "RPE 9"),
        CardioTemplate(id: "recovery-walk", title: "Recovery Walk", category: .walking, focus: .recovery, minutes: 20, summary: "Gentle movement to help you reset and digest.", effort: "Easy"),
        CardioTemplate(id: "brisk-walk", title: "Brisk Walk", category: .walking, focus: .tempo, minutes: 30, summary: "A purposeful pace that lifts your heart rate.", effort: "RPE 5"),
        CardioTemplate(id: "steady-ride", title: "Steady Ride", category: .cycling, focus: .easy, minutes: 40, summary: "Smooth aerobic work with a relaxed upper body.", effort: "Zone 2"),
        CardioTemplate(id: "hill-intervals", title: "Hill Intervals", category: .cycling, focus: .intervals, minutes: 30, summary: "Five climbs at a strong, seated effort.", effort: "RPE 8"),
        CardioTemplate(id: "sunrise-flow", title: "Sunrise Flow", category: .yoga, focus: .easy, minutes: 20, summary: "A gentle sequence to wake up your spine and hips.", effort: "Breath-led"),
        CardioTemplate(id: "deep-stretch", title: "Deep Stretch", category: .yoga, focus: .recovery, minutes: 15, summary: "Long holds for the hips, hamstrings and back.", effort: "Wind down"),
        CardioTemplate(id: "conditioning", title: "Conditioning", category: .hiit, focus: .intervals, minutes: 15, summary: "Short, honest work intervals with full recoveries.", effort: "RPE 8")
    ]

    static func templates(for categories: [WorkoutCategory]) -> [CardioTemplate] {
        all.filter { categories.contains($0.category) }
    }
}
