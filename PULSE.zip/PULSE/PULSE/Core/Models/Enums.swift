import SwiftUI
import HealthKit

// MARK: - Units

enum UnitSystem: String, CaseIterable, Codable, Identifiable, Hashable {
    case metric
    case imperial

    var id: String { rawValue }

    var label: String {
        switch self {
        case .metric: "Metric"
        case .imperial: "Imperial"
        }
    }

    var detail: String {
        switch self {
        case .metric: "Centimetres, kilograms, kilometres"
        case .imperial: "Feet, pounds, miles"
        }
    }

    var heightUnit: String { self == .metric ? "cm" : "ft / in" }
    var weightUnit: String { self == .metric ? "kg" : "lb" }
    var distanceUnit: String { self == .metric ? "km" : "mi" }
    var waterUnit: String { self == .metric ? "ml" : "fl oz" }
}

// MARK: - Fitness profile

enum FitnessLevel: String, CaseIterable, Codable, Identifiable, Hashable {
    case beginner
    case intermediate
    case advanced
    case athlete

    var id: String { rawValue }

    var label: String {
        switch self {
        case .beginner: "Beginner"
        case .intermediate: "Intermediate"
        case .advanced: "Advanced"
        case .athlete: "Athlete"
        }
    }

    var detail: String {
        switch self {
        case .beginner: "New to training, or returning after a break"
        case .intermediate: "Training 2–3 times a week"
        case .advanced: "Training 4+ times a week with structure"
        case .athlete: "Competing or training at a high volume"
        }
    }

    var symbol: String {
        switch self {
        case .beginner: "leaf.fill"
        case .intermediate: "figure.walk.motion"
        case .advanced: "figure.run"
        case .athlete: "bolt.fill"
        }
    }

    var activityFactor: Double {
        switch self {
        case .beginner: 1.30
        case .intermediate: 1.45
        case .advanced: 1.58
        case .athlete: 1.72
        }
    }
}

enum FitnessGoal: String, CaseIterable, Codable, Identifiable, Hashable {
    case buildStrength
    case loseWeight
    case improveEndurance
    case stayConsistent
    case moveBetter

    var id: String { rawValue }

    var label: String {
        switch self {
        case .buildStrength: "Build strength"
        case .loseWeight: "Lose weight"
        case .improveEndurance: "Improve endurance"
        case .stayConsistent: "Stay consistent"
        case .moveBetter: "Move better"
        }
    }

    var detail: String {
        switch self {
        case .buildStrength: "Progressive lifting and muscular control"
        case .loseWeight: "Sustainable energy balance and daily movement"
        case .improveEndurance: "Build your engine with steady, repeatable effort"
        case .stayConsistent: "Simple routines that fit your real week"
        case .moveBetter: "Mobility, posture and pain-free range"
        }
    }

    var symbol: String {
        switch self {
        case .buildStrength: "dumbbell.fill"
        case .loseWeight: "flame.fill"
        case .improveEndurance: "heart.fill"
        case .stayConsistent: "calendar"
        case .moveBetter: "figure.flexibility"
        }
    }

    var calorieAdjustment: Double {
        switch self {
        case .buildStrength: 150
        case .loseWeight: -400
        case .improveEndurance: 200
        case .stayConsistent: 0
        case .moveBetter: 0
        }
    }

    var proteinPerKilogram: Double {
        switch self {
        case .buildStrength: 1.9
        case .loseWeight: 2.0
        case .improveEndurance: 1.6
        case .stayConsistent: 1.6
        case .moveBetter: 1.4
        }
    }
}

enum ActivityPreference: String, CaseIterable, Codable, Identifiable, Hashable {
    case strength
    case running
    case walking
    case cycling
    case yoga
    case hiit
    case mobility
    case swimming

    var id: String { rawValue }

    var label: String {
        switch self {
        case .strength: "Strength"
        case .running: "Running"
        case .walking: "Walking"
        case .cycling: "Cycling"
        case .yoga: "Yoga"
        case .hiit: "HIIT"
        case .mobility: "Mobility"
        case .swimming: "Swimming"
        }
    }

    var symbol: String {
        switch self {
        case .strength: "dumbbell.fill"
        case .running: "figure.run"
        case .walking: "figure.walk"
        case .cycling: "bicycle"
        case .yoga: "figure.yoga"
        case .hiit: "figure.highintensity.intervaltraining"
        case .mobility: "figure.flexibility"
        case .swimming: "figure.pool.swim"
        }
    }
}

// MARK: - Workouts

enum WorkoutCategory: String, CaseIterable, Codable, Identifiable, Hashable {
    case strength
    case running
    case walking
    case cycling
    case yoga
    case mobility
    case hiit

    var id: String { rawValue }

    var label: String {
        switch self {
        case .strength: "Strength"
        case .running: "Running"
        case .walking: "Walking"
        case .cycling: "Cycling"
        case .yoga: "Yoga"
        case .mobility: "Mobility"
        case .hiit: "HIIT"
        }
    }

    var symbol: String {
        switch self {
        case .strength: "figure.strengthtraining.traditional"
        case .running: "figure.run"
        case .walking: "figure.walk"
        case .cycling: "bicycle"
        case .yoga: "figure.yoga"
        case .mobility: "figure.flexibility"
        case .hiit: "figure.highintensity.intervaltraining"
        }
    }

    var tint: Color {
        switch self {
        case .strength: PulseColor.ringMove
        case .running: PulseColor.ringExercise
        case .walking: PulseColor.ringStand
        case .cycling: PulseColor.ringStand
        case .yoga: PulseColor.ringExercise
        case .mobility: PulseColor.ringMove
        case .hiit: PulseColor.danger
        }
    }

    var met: Double {
        switch self {
        case .strength: 5.0
        case .running: 9.0
        case .walking: 3.8
        case .cycling: 7.5
        case .yoga: 3.0
        case .mobility: 2.5
        case .hiit: 8.0
        }
    }
}

enum MuscleGroup: String, CaseIterable, Codable, Identifiable, Hashable {
    case chest
    case back
    case shoulders
    case arms
    case core
    case glutes
    case legs
    case fullBody

    var id: String { rawValue }

    var label: String {
        switch self {
        case .chest: "Chest"
        case .back: "Back"
        case .shoulders: "Shoulders"
        case .arms: "Arms"
        case .core: "Core"
        case .glutes: "Glutes"
        case .legs: "Legs"
        case .fullBody: "Full body"
        }
    }
}

enum Equipment: String, CaseIterable, Codable, Identifiable, Hashable {
    case bodyweight
    case dumbbell
    case barbell
    case kettlebell
    case cable
    case machine
    case band
    case none

    var id: String { rawValue }

    var label: String {
        switch self {
        case .bodyweight: "Bodyweight"
        case .dumbbell: "Dumbbell"
        case .barbell: "Barbell"
        case .kettlebell: "Kettlebell"
        case .cable: "Cable"
        case .machine: "Machine"
        case .band: "Resistance band"
        case .none: "No equipment"
        }
    }
}

enum WorkoutStatus: String, Codable {
    case active
    case completed
    case discarded
}

enum CardioSessionFocus: String, CaseIterable, Identifiable, Hashable {
    case easy
    case tempo
    case intervals
    case recovery

    var id: String { rawValue }

    var label: String {
        switch self {
        case .easy: "Easy"
        case .tempo: "Tempo"
        case .intervals: "Intervals"
        case .recovery: "Recovery"
        }
    }
}

// MARK: - Nutrition

enum MealType: String, CaseIterable, Codable, Identifiable, Hashable {
    case breakfast
    case lunch
    case dinner
    case snacks

    var id: String { rawValue }

    var label: String {
        switch self {
        case .breakfast: "Breakfast"
        case .lunch: "Lunch"
        case .dinner: "Dinner"
        case .snacks: "Snacks"
        }
    }

    var symbol: String {
        switch self {
        case .breakfast: "sunrise.fill"
        case .lunch: "sun.max.fill"
        case .dinner: "moon.stars.fill"
        case .snacks: "carrot.fill"
        }
    }

    var defaultTimeHint: String {
        switch self {
        case .breakfast: "Start strong"
        case .lunch: "Midday fuel"
        case .dinner: "Wind down"
        case .snacks: "Between meals"
        }
    }
}

// MARK: - Preferences

enum AppearanceMode: String, CaseIterable, Codable, Identifiable, Hashable {
    case system
    case light
    case dark

    var id: String { rawValue }

    var label: String {
        switch self {
        case .system: "System"
        case .light: "Light"
        case .dark: "Dark"
        }
    }

    var symbol: String {
        switch self {
        case .system: "circle.lefthalf.filled"
        case .light: "sun.max.fill"
        case .dark: "moon.fill"
        }
    }

    var colorScheme: ColorScheme? {
        switch self {
        case .system: nil
        case .light: .light
        case .dark: .dark
        }
    }
}

enum InsightRange: String, CaseIterable, Identifiable, Hashable {
    case day
    case week
    case month

    var id: String { rawValue }

    var label: String {
        switch self {
        case .day: "Day"
        case .week: "Week"
        case .month: "Month"
        }
    }

    var days: Int {
        switch self {
        case .day: 1
        case .week: 7
        case .month: 30
        }
    }
}

enum HealthAccessState {
    case unknown
    case notRequested
    case requested
    case unavailable
}
