import Foundation

struct FoodItem: Identifiable, Hashable {
    let id: String
    let name: String
    let servingDescription: String
    let calories: Double
    let proteinG: Double
    let carbsG: Double
    let fatG: Double
}

enum FoodCatalog {
    static let all: [FoodItem] = [
        FoodItem(id: "egg", name: "Egg", servingDescription: "1 large egg", calories: 72, proteinG: 6.3, carbsG: 0.4, fatG: 4.8),
        FoodItem(id: "egg-whites", name: "Egg Whites", servingDescription: "3 large whites", calories: 51, proteinG: 10.8, carbsG: 0.7, fatG: 0.2),
        FoodItem(id: "oats", name: "Rolled Oats", servingDescription: "60 g dry", calories: 228, proteinG: 8.0, carbsG: 39.0, fatG: 4.2),
        FoodItem(id: "greek-yogurt", name: "Greek Yogurt", servingDescription: "170 g cup, 2%", calories: 146, proteinG: 20.0, carbsG: 8.0, fatG: 4.0),
        FoodItem(id: "cottage-cheese", name: "Cottage Cheese", servingDescription: "150 g", calories: 146, proteinG: 19.0, carbsG: 5.0, fatG: 4.5),
        FoodItem(id: "banana", name: "Banana", servingDescription: "1 medium", calories: 105, proteinG: 1.3, carbsG: 27.0, fatG: 0.4),
        FoodItem(id: "apple", name: "Apple", servingDescription: "1 medium", calories: 95, proteinG: 0.5, carbsG: 25.0, fatG: 0.3),
        FoodItem(id: "blueberries", name: "Blueberries", servingDescription: "1 cup", calories: 84, proteinG: 1.1, carbsG: 21.0, fatG: 0.5),
        FoodItem(id: "strawberries", name: "Strawberries", servingDescription: "1 cup", calories: 49, proteinG: 1.0, carbsG: 11.7, fatG: 0.5),
        FoodItem(id: "orange", name: "Orange", servingDescription: "1 medium", calories: 62, proteinG: 1.2, carbsG: 15.4, fatG: 0.2),
        FoodItem(id: "avocado", name: "Avocado", servingDescription: "1/2 medium", calories: 120, proteinG: 1.5, carbsG: 6.4, fatG: 11.0),
        FoodItem(id: "chicken-breast", name: "Chicken Breast", servingDescription: "150 g cooked", calories: 248, proteinG: 46.5, carbsG: 0.0, fatG: 5.4),
        FoodItem(id: "salmon", name: "Salmon Fillet", servingDescription: "140 g cooked", calories: 292, proteinG: 39.0, carbsG: 0.0, fatG: 14.0),
        FoodItem(id: "tuna", name: "Tuna", servingDescription: "1 can, 120 g drained", calories: 132, proteinG: 29.0, carbsG: 0.0, fatG: 1.0),
        FoodItem(id: "ground-beef", name: "Lean Ground Beef", servingDescription: "120 g cooked", calories: 250, proteinG: 30.0, carbsG: 0.0, fatG: 13.0),
        FoodItem(id: "turkey", name: "Roast Turkey", servingDescription: "120 g", calories: 160, proteinG: 32.0, carbsG: 0.0, fatG: 3.0),
        FoodItem(id: "tofu", name: "Firm Tofu", servingDescription: "150 g", calories: 173, proteinG: 18.0, carbsG: 4.5, fatG: 10.5),
        FoodItem(id: "lentils", name: "Cooked Lentils", servingDescription: "1 cup", calories: 230, proteinG: 17.9, carbsG: 39.9, fatG: 0.8),
        FoodItem(id: "chickpeas", name: "Chickpeas", servingDescription: "1 cup cooked", calories: 269, proteinG: 14.5, carbsG: 45.0, fatG: 4.2),
        FoodItem(id: "black-beans", name: "Black Beans", servingDescription: "1 cup cooked", calories: 227, proteinG: 15.2, carbsG: 40.8, fatG: 0.9),
        FoodItem(id: "brown-rice", name: "Brown Rice", servingDescription: "1 cup cooked", calories: 216, proteinG: 5.0, carbsG: 44.8, fatG: 1.8),
        FoodItem(id: "quinoa", name: "Quinoa", servingDescription: "1 cup cooked", calories: 222, proteinG: 8.1, carbsG: 39.4, fatG: 3.6),
        FoodItem(id: "sweet-potato", name: "Sweet Potato", servingDescription: "1 medium baked", calories: 180, proteinG: 4.0, carbsG: 41.0, fatG: 0.3),
        FoodItem(id: "pasta", name: "Pasta", servingDescription: "1 cup cooked", calories: 221, proteinG: 8.1, carbsG: 43.2, fatG: 1.3),
        FoodItem(id: "whole-wheat-bread", name: "Whole Wheat Bread", servingDescription: "1 slice", calories: 81, proteinG: 4.0, carbsG: 13.8, fatG: 1.1),
        FoodItem(id: "sourdough", name: "Sourdough Bread", servingDescription: "1 slice", calories: 93, proteinG: 3.8, carbsG: 18.0, fatG: 0.6),
        FoodItem(id: "broccoli", name: "Broccoli", servingDescription: "1 cup steamed", calories: 55, proteinG: 3.7, carbsG: 11.2, fatG: 0.6),
        FoodItem(id: "spinach", name: "Spinach", servingDescription: "2 cups raw", calories: 14, proteinG: 1.7, carbsG: 2.2, fatG: 0.2),
        FoodItem(id: "mixed-salad", name: "Mixed Green Salad", servingDescription: "1 large bowl", calories: 110, proteinG: 3.0, carbsG: 12.0, fatG: 6.0),
        FoodItem(id: "carrots", name: "Carrots", servingDescription: "1 cup raw", calories: 52, proteinG: 1.2, carbsG: 12.3, fatG: 0.3),
        FoodItem(id: "almonds", name: "Almonds", servingDescription: "28 g, about 23 nuts", calories: 164, proteinG: 6.0, carbsG: 6.1, fatG: 14.2),
        FoodItem(id: "peanut-butter", name: "Peanut Butter", servingDescription: "2 tbsp", calories: 190, proteinG: 7.0, carbsG: 7.0, fatG: 16.0),
        FoodItem(id: "olive-oil", name: "Olive Oil", servingDescription: "1 tbsp", calories: 119, proteinG: 0.0, carbsG: 0.0, fatG: 13.5),
        FoodItem(id: "milk", name: "Whole Milk", servingDescription: "1 cup", calories: 149, proteinG: 7.7, carbsG: 11.7, fatG: 8.0),
        FoodItem(id: "almond-milk", name: "Almond Milk", servingDescription: "1 cup, unsweetened", calories: 39, proteinG: 1.5, carbsG: 3.4, fatG: 2.5),
        FoodItem(id: "protein-powder", name: "Whey Protein", servingDescription: "1 scoop, 30 g", calories: 116, proteinG: 24.0, carbsG: 3.0, fatG: 1.5),
        FoodItem(id: "hummus", name: "Hummus", servingDescription: "2 tbsp", calories: 70, proteinG: 2.0, carbsG: 6.0, fatG: 4.5),
        FoodItem(id: "granola", name: "Granola", servingDescription: "50 g", calories: 215, proteinG: 4.5, carbsG: 32.0, fatG: 8.0),
        FoodItem(id: "honey", name: "Honey", servingDescription: "1 tbsp", calories: 64, proteinG: 0.1, carbsG: 17.3, fatG: 0.0),
        FoodItem(id: "dark-chocolate", name: "Dark Chocolate", servingDescription: "2 squares, 20 g", calories: 120, proteinG: 1.6, carbsG: 9.0, fatG: 8.4),
        FoodItem(id: "cheddar", name: "Cheddar Cheese", servingDescription: "30 g", calories: 120, proteinG: 7.0, carbsG: 0.4, fatG: 10.0),
        FoodItem(id: "butter", name: "Butter", servingDescription: "1 tbsp", calories: 102, proteinG: 0.1, carbsG: 0.0, fatG: 11.5),
        FoodItem(id: "latte", name: "Oat Milk Latte", servingDescription: "12 oz", calories: 160, proteinG: 5.0, carbsG: 22.0, fatG: 5.5),
        FoodItem(id: "black-coffee", name: "Black Coffee", servingDescription: "1 cup", calories: 2, proteinG: 0.3, carbsG: 0.0, fatG: 0.0),
        FoodItem(id: "green-tea", name: "Green Tea", servingDescription: "1 cup", calories: 2, proteinG: 0.0, carbsG: 0.5, fatG: 0.0),
        FoodItem(id: "protein-bar", name: "Protein Bar", servingDescription: "1 bar, 60 g", calories: 210, proteinG: 20.0, carbsG: 22.0, fatG: 7.0),
        FoodItem(id: "rice-cakes", name: "Rice Cakes", servingDescription: "2 cakes", calories: 70, proteinG: 1.4, carbsG: 14.6, fatG: 0.6),
        FoodItem(id: "crackers", name: "Wholegrain Crackers", servingDescription: "4 crackers", calories: 120, proteinG: 3.0, carbsG: 18.0, fatG: 4.5),
        FoodItem(id: "ice-cream", name: "Vanilla Ice Cream", servingDescription: "1/2 cup", calories: 137, proteinG: 2.3, carbsG: 16.0, fatG: 7.3),
        FoodItem(id: "pizza-slice", name: "Cheese Pizza", servingDescription: "1 large slice", calories: 285, proteinG: 12.0, carbsG: 36.0, fatG: 10.0),
        FoodItem(id: "turkey-sandwich", name: "Turkey Sandwich", servingDescription: "1 sandwich", calories: 380, proteinG: 26.0, carbsG: 45.0, fatG: 10.0),
        FoodItem(id: "burrito-bowl", name: "Chicken Burrito Bowl", servingDescription: "1 bowl", calories: 625, proteinG: 45.0, carbsG: 68.0, fatG: 20.0),
        FoodItem(id: "sushi-roll", name: "Salmon Sushi Roll", servingDescription: "6 pieces", calories: 304, proteinG: 13.0, carbsG: 48.0, fatG: 6.0),
        FoodItem(id: "burger", name: "Beef Burger", servingDescription: "1 burger", calories: 540, proteinG: 29.0, carbsG: 43.0, fatG: 27.0),
        FoodItem(id: "fries", name: "French Fries", servingDescription: "medium serving", calories: 340, proteinG: 4.0, carbsG: 44.0, fatG: 17.0),
        FoodItem(id: "soup", name: "Vegetable Soup", servingDescription: "1 bowl, 350 ml", calories: 160, proteinG: 6.0, carbsG: 24.0, fatG: 4.0)
    ]

    static func search(_ query: String) -> [FoodItem] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return all }
        return all.filter { $0.name.localizedCaseInsensitiveContains(trimmed) }
    }

    static func item(id: String) -> FoodItem? {
        all.first { $0.id == id }
    }
}
