import Foundation
import SwiftData

@Model
final class FoodEntry {
    @Attribute(.unique) var id: UUID
    var date: Date
    var mealRaw: String
    var name: String
    var calories: Double
    var proteinG: Double
    var carbsG: Double
    var fatG: Double
    var servings: Double
    var servingDescription: String
    var createdAt: Date

    init(
        id: UUID = UUID(),
        date: Date = .now,
        meal: MealType,
        name: String,
        calories: Double,
        proteinG: Double,
        carbsG: Double,
        fatG: Double,
        servings: Double = 1,
        servingDescription: String = "1 serving",
        createdAt: Date = .now
    ) {
        self.id = id
        self.date = date
        self.mealRaw = meal.rawValue
        self.name = name
        self.calories = calories
        self.proteinG = proteinG
        self.carbsG = carbsG
        self.fatG = fatG
        self.servings = servings
        self.servingDescription = servingDescription
        self.createdAt = createdAt
    }

    var meal: MealType {
        get { MealType(rawValue: mealRaw) ?? .snacks }
        set { mealRaw = newValue.rawValue }
    }
}

@Model
final class HydrationEntry {
    @Attribute(.unique) var id: UUID
    var date: Date
    var amountMl: Double
    var createdAt: Date

    init(id: UUID = UUID(), date: Date = .now, amountMl: Double, createdAt: Date = .now) {
        self.id = id
        self.date = date
        self.amountMl = amountMl
        self.createdAt = createdAt
    }
}

@Model
final class WeightEntry {
    @Attribute(.unique) var id: UUID
    var date: Date
    var weightKg: Double
    var createdAt: Date

    init(id: UUID = UUID(), date: Date = .now, weightKg: Double, createdAt: Date = .now) {
        self.id = id
        self.date = date
        self.weightKg = weightKg
        self.createdAt = createdAt
    }
}
