import Foundation
import SwiftData

@Model
final class UserProfile {
    @Attribute(.unique) var id: UUID
    var name: String
    var age: Int
    var heightCm: Double
    var weightKg: Double
    var levelRaw: String
    var goalRaw: String
    var preferredActivitiesRaw: [String]
    var unitSystemRaw: String
    var onboardingCompleted: Bool
    var calorieGoal: Int
    var proteinGoalG: Int
    var carbsGoalG: Int
    var fatGoalG: Int
    var hydrationGoalMl: Int
    var appearanceRaw: String
    var notificationsEnabled: Bool
    var restTimerNotificationsEnabled: Bool
    var workoutRemindersEnabled: Bool
    var healthKitRequested: Bool
    var usesPreviewData: Bool
    var createdAt: Date
    var updatedAt: Date

    init(
        id: UUID = UUID(),
        name: String = "",
        age: Int = 30,
        heightCm: Double = 175,
        weightKg: Double = 72,
        level: FitnessLevel = .intermediate,
        goal: FitnessGoal = .stayConsistent,
        activities: [ActivityPreference] = [.strength, .walking],
        unitSystem: UnitSystem = .metric,
        onboardingCompleted: Bool = false
    ) {
        self.id = id
        self.name = name
        self.age = age
        self.heightCm = heightCm
        self.weightKg = weightKg
        self.levelRaw = level.rawValue
        self.goalRaw = goal.rawValue
        self.preferredActivitiesRaw = activities.map(\.rawValue)
        self.unitSystemRaw = unitSystem.rawValue
        self.onboardingCompleted = onboardingCompleted
        self.calorieGoal = 2200
        self.proteinGoalG = 140
        self.carbsGoalG = 240
        self.fatGoalG = 70
        self.hydrationGoalMl = 2500
        self.appearanceRaw = AppearanceMode.system.rawValue
        self.notificationsEnabled = false
        self.restTimerNotificationsEnabled = true
        self.workoutRemindersEnabled = false
        self.healthKitRequested = false
        self.usesPreviewData = false
        self.createdAt = .now
        self.updatedAt = .now
        recalculateTargets()
    }

    var level: FitnessLevel {
        get { FitnessLevel(rawValue: levelRaw) ?? .intermediate }
        set { levelRaw = newValue.rawValue }
    }

    var goal: FitnessGoal {
        get { FitnessGoal(rawValue: goalRaw) ?? .stayConsistent }
        set { goalRaw = newValue.rawValue }
    }

    var activities: [ActivityPreference] {
        get { preferredActivitiesRaw.compactMap(ActivityPreference.init(rawValue:)) }
        set { preferredActivitiesRaw = newValue.map(\.rawValue) }
    }

    var unitSystem: UnitSystem {
        get { UnitSystem(rawValue: unitSystemRaw) ?? .metric }
        set { unitSystemRaw = newValue.rawValue }
    }

    var appearance: AppearanceMode {
        get { AppearanceMode(rawValue: appearanceRaw) ?? .system }
        set { appearanceRaw = newValue.rawValue }
    }

    var firstName: String {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let first = trimmed.split(separator: " ").first, !first.isEmpty else {
            return "there"
        }
        return String(first)
    }

    var initials: String {
        let parts = name.trimmingCharacters(in: .whitespacesAndNewlines)
            .split(separator: " ")
            .prefix(2)
        let letters = parts.compactMap(\.first)
        return letters.isEmpty ? "P" : String(letters).uppercased()
    }

    var bmi: Double {
        guard heightCm > 0 else { return 0 }
        let meters = heightCm / 100
        return weightKg / (meters * meters)
    }

    var bmiLabel: String {
        switch bmi {
        case ..<18.5: "Underweight"
        case 18.5..<25: "Healthy range"
        case 25..<30: "Above range"
        default: "High range"
        }
    }

    func recalculateTargets() {
        let bmr = (10 * weightKg) + (6.25 * heightCm) - (5 * Double(age)) - 78
        let maintenance = bmr * level.activityFactor
        let adjusted = maintenance + goal.calorieAdjustment
        calorieGoal = Int((adjusted / 10).rounded() * 10).clamped(to: 1400...4200)

        proteinGoalG = Int((weightKg * goal.proteinPerKilogram).rounded())
        let fatCalories = Double(calorieGoal) * 0.30
        fatGoalG = Int((fatCalories / 9).rounded())
        let remaining = Double(calorieGoal) - (Double(proteinGoalG) * 4) - fatCalories
        carbsGoalG = max(50, Int((remaining / 4).rounded()))

        let hydration = (weightKg * 35 / 50).rounded() * 50
        hydrationGoalMl = Int(hydration).clamped(to: 1500...4500)
        updatedAt = .now
    }
}

extension Comparable {
    func clamped(to range: ClosedRange<Self>) -> Self {
        min(max(self, range.lowerBound), range.upperBound)
    }
}
