import Foundation
import SwiftData

@Model
final class Routine {
    @Attribute(.unique) var id: UUID
    var name: String
    var notes: String
    var categoryRaw: String
    var estimatedMinutes: Int
    var createdAt: Date
    var lastUsedAt: Date?
    @Relationship(deleteRule: .cascade, inverse: \RoutineExercise.routine) var exercises: [RoutineExercise]

    init(
        id: UUID = UUID(),
        name: String,
        notes: String = "",
        category: WorkoutCategory = .strength,
        estimatedMinutes: Int = 45
    ) {
        self.id = id
        self.name = name
        self.notes = notes
        self.categoryRaw = category.rawValue
        self.estimatedMinutes = estimatedMinutes
        self.createdAt = .now
        self.exercises = []
    }

    var category: WorkoutCategory {
        get { WorkoutCategory(rawValue: categoryRaw) ?? .strength }
        set { categoryRaw = newValue.rawValue }
    }

    var orderedExercises: [RoutineExercise] {
        exercises.sorted { $0.order < $1.order }
    }

    var totalSets: Int {
        exercises.reduce(0) { $0 + $1.targetSets }
    }

    var muscleSummary: String {
        let unique = orderedExercises.map(\.muscleGroup.label).removingDuplicates().prefix(3)
        return unique.joined(separator: " · ")
    }
}

@Model
final class RoutineExercise {
    @Attribute(.unique) var id: UUID
    var order: Int
    var exerciseID: String
    var exerciseName: String
    var muscleGroupRaw: String
    var targetSets: Int
    var targetReps: Int
    var targetWeightKg: Double
    var restSeconds: Int
    var routine: Routine?

    init(
        id: UUID = UUID(),
        exercise: Exercise,
        order: Int,
        sets: Int = 3,
        reps: Int = 10,
        weightKg: Double = 0,
        restSeconds: Int = 90
    ) {
        self.id = id
        self.order = order
        self.exerciseID = exercise.id
        self.exerciseName = exercise.name
        self.muscleGroupRaw = exercise.primaryMuscle.rawValue
        self.targetSets = sets
        self.targetReps = reps
        self.targetWeightKg = weightKg
        self.restSeconds = restSeconds
    }

    var muscleGroup: MuscleGroup {
        MuscleGroup(rawValue: muscleGroupRaw) ?? .fullBody
    }
}

@Model
final class WorkoutSession {
    @Attribute(.unique) var id: UUID
    var title: String
    var categoryRaw: String
    var startedAt: Date
    var endedAt: Date?
    var statusRaw: String
    var totalVolumeKg: Double
    var estimatedCalories: Double?
    var averageHeartRate: Double?
    var maxHeartRate: Double?
    var distanceMeters: Double?
    var notes: String?
    var routineID: UUID?
    var isFromWatch: Bool
    @Relationship(deleteRule: .cascade, inverse: \WorkoutSetRecord.session) var sets: [WorkoutSetRecord]

    init(
        id: UUID = UUID(),
        title: String,
        category: WorkoutCategory,
        startedAt: Date,
        endedAt: Date? = nil,
        status: WorkoutStatus = .completed,
        totalVolumeKg: Double = 0,
        estimatedCalories: Double? = nil,
        averageHeartRate: Double? = nil,
        maxHeartRate: Double? = nil,
        distanceMeters: Double? = nil,
        notes: String? = nil,
        routineID: UUID? = nil,
        isFromWatch: Bool = false
    ) {
        self.id = id
        self.title = title
        self.categoryRaw = category.rawValue
        self.startedAt = startedAt
        self.endedAt = endedAt
        self.statusRaw = status.rawValue
        self.totalVolumeKg = totalVolumeKg
        self.estimatedCalories = estimatedCalories
        self.averageHeartRate = averageHeartRate
        self.maxHeartRate = maxHeartRate
        self.distanceMeters = distanceMeters
        self.notes = notes
        self.routineID = routineID
        self.isFromWatch = isFromWatch
        self.sets = []
    }

    var category: WorkoutCategory {
        get { WorkoutCategory(rawValue: categoryRaw) ?? .strength }
        set { categoryRaw = newValue.rawValue }
    }

    var status: WorkoutStatus {
        get { WorkoutStatus(rawValue: statusRaw) ?? .completed }
        set { statusRaw = newValue.rawValue }
    }

    var duration: TimeInterval {
        (endedAt ?? .now).timeIntervalSince(startedAt)
    }

    var durationMinutes: Int {
        max(1, Int(duration / 60))
    }

    var orderedSets: [WorkoutSetRecord] {
        sets.sorted {
            if $0.exerciseName == $1.exerciseName { return $0.setIndex < $1.setIndex }
            return $0.completedAt < $1.completedAt
        }
    }

    var completedSetsCount: Int {
        sets.count
    }

    var totalReps: Int {
        sets.reduce(0) { $0 + $1.reps }
    }

    var exerciseCount: Int {
        Set(sets.map(\.exerciseID)).count
    }

    var groupedSets: [(name: String, exerciseID: String, sets: [WorkoutSetRecord])] {
        var order: [String] = []
        var groups: [String: [WorkoutSetRecord]] = [:]
        for set in orderedSets {
            if groups[set.exerciseID] == nil {
                order.append(set.exerciseID)
                groups[set.exerciseID] = []
            }
            groups[set.exerciseID]?.append(set)
        }
        return order.compactMap { id in
            guard let sets = groups[id], let first = sets.first else { return nil }
            return (first.exerciseName, id, sets)
        }
    }

    var volumeTonnes: Double {
        totalVolumeKg / 1000
    }
}

@Model
final class WorkoutSetRecord {
    @Attribute(.unique) var id: UUID
    var exerciseID: String
    var exerciseName: String
    var muscleGroupRaw: String
    var setIndex: Int
    var reps: Int
    var weightKg: Double
    var completedAt: Date
    var session: WorkoutSession?

    init(
        id: UUID = UUID(),
        exerciseID: String,
        exerciseName: String,
        muscleGroup: MuscleGroup,
        setIndex: Int,
        reps: Int,
        weightKg: Double,
        completedAt: Date = .now
    ) {
        self.id = id
        self.exerciseID = exerciseID
        self.exerciseName = exerciseName
        self.muscleGroupRaw = muscleGroup.rawValue
        self.setIndex = setIndex
        self.reps = reps
        self.weightKg = weightKg
        self.completedAt = completedAt
    }

    var muscleGroup: MuscleGroup {
        MuscleGroup(rawValue: muscleGroupRaw) ?? .fullBody
    }

    var volumeKg: Double {
        Double(reps) * weightKg
    }
}

extension Array where Element: Hashable {
    func removingDuplicates() -> [Element] {
        var seen = Set<Element>()
        return filter { seen.insert($0).inserted }
    }
}
