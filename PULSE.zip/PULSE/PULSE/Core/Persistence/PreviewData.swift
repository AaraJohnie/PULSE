import Foundation
import SwiftData

/// Deterministic, clearly-labelled sample content used only for previews and simulator QA.
enum PreviewData {
    static var todaySnapshot: HealthSnapshot {
        HealthSnapshot(
            date: .now,
            steps: 8_924,
            activeEnergy: 512,
            exerciseMinutes: 28,
            distanceMeters: 6_720,
            standHours: 9
        )
    }

    static func dailyMetrics(days: Int, endingAt: Date = .now) -> [DailyHealthMetric] {
        let calendar = PulseDate.calendar
        let end = calendar.startOfDay(for: endingAt)
        var result: [DailyHealthMetric] = []
        let weekdayBase = [4_600.0, 8_100, 8_650, 7_900, 8_950, 9_400, 6_200]

        for offset in stride(from: max(days - 1, 0), through: 0, by: -1) {
            guard let date = calendar.date(byAdding: .day, value: -offset, to: end) else { continue }
            let weekday = calendar.component(.weekday, from: date)
            let base = weekdayBase[(weekday - 1) % weekdayBase.count]
            let wobble = Double((calendar.component(.day, from: date) * 137) % 900) - 450
            let steps = offset == 0 ? todaySnapshot.steps : base + wobble
            let energy = steps * 0.057 + 80
            let exercise = offset == 0 ? todaySnapshot.exerciseMinutes : 16 + Double((weekday * 5) % 20)
            let distance = steps * 0.00076
            let stand = offset == 0 ? todaySnapshot.standHours : Double(7 + weekday % 5)
            result.append(
                DailyHealthMetric(
                    date: date,
                    steps: steps,
                    activeEnergy: energy,
                    exerciseMinutes: exercise,
                    distanceMeters: distance,
                    standHours: stand
                )
            )
        }
        return result
    }

    static var hourlySteps: [HourlyStep] {
        let calendar = PulseDate.calendar
        let start = calendar.startOfDay(for: .now)
        let currentHour = calendar.component(.hour, from: .now)
        let shape: [Double] = [
            0, 0, 0, 0, 0, 25, 130, 460, 880, 240, 190, 330,
            720, 810, 220, 280, 1_650, 720, 240, 110, 680, 480, 160, 80
        ]
        let visible = Array(shape.prefix(max(currentHour + 1, 1)))
        let sum = visible.reduce(0, +)
        let scale = sum > 0 ? todaySnapshot.steps / sum : 0
        return visible.enumerated().compactMap { index, value in
            guard let date = calendar.date(byAdding: .hour, value: index, to: start) else { return nil }
            return HourlyStep(hour: date, steps: (value * scale).rounded())
        }
    }

    static func seed(in context: ModelContext, profile: UserProfile) {
        clearRecords(in: context)

        profile.weightKg = 72.4
        profile.usesPreviewData = true
        profile.recalculateTargets()

        seedRoutines(in: context)
        seedWorkouts(in: context, profile: profile)
        seedNutrition(in: context)
        seedHydration(in: context)
        seedWeights(in: context)

        try? context.save()
    }

    static func clearPreviewData(in context: ModelContext, profile: UserProfile?) {
        clearRecords(in: context)
        profile?.usesPreviewData = false
        try? context.save()
    }

    private static func clearRecords(in context: ModelContext) {
        deleteAll(WorkoutSetRecord.self, in: context)
        deleteAll(WorkoutSession.self, in: context)
        deleteAll(RoutineExercise.self, in: context)
        deleteAll(Routine.self, in: context)
        deleteAll(FoodEntry.self, in: context)
        deleteAll(HydrationEntry.self, in: context)
        deleteAll(WeightEntry.self, in: context)
    }

    private static func deleteAll<T: PersistentModel>(_ type: T.Type, in context: ModelContext) {
        guard let items = try? context.fetch(FetchDescriptor<T>()) else { return }
        for item in items {
            context.delete(item)
        }
    }

    private static func seedRoutines(in context: ModelContext) {
        let templates: [(String, String, WorkoutCategory, Int, [(String, Int, Int, Double, Int)])] = [
            (
                "Upper Body Reset",
                "Press, pull and shoulders. A clean session you can repeat all month.",
                .strength,
                40,
                [
                    ("dumbbell-bench-press", 3, 10, 16, 90),
                    ("dumbbell-row", 3, 10, 18, 75),
                    ("overhead-press", 3, 8, 12, 90),
                    ("face-pull", 3, 15, 12, 60)
                ]
            ),
            (
                "Lower & Core",
                "Hinge, squat and brace. Keep the ribs stacked and the tempo controlled.",
                .strength,
                42,
                [
                    ("goblet-squat", 3, 10, 24, 90),
                    ("romanian-deadlift", 3, 8, 40, 90),
                    ("walking-lunge", 3, 8, 12, 90),
                    ("dead-bug", 3, 8, 0, 60)
                ]
            ),
            (
                "Morning Mobility",
                "A short reset for your spine, hips and shoulders.",
                .mobility,
                14,
                [
                    ("cat-cow", 2, 8, 0, 20),
                    ("world-greatest-stretch", 2, 6, 0, 20),
                    ("thoracic-rotation", 2, 8, 0, 20),
                    ("childs-pose", 2, 5, 0, 20)
                ]
            )
        ]

        for (name, notes, category, minutes, exercises) in templates {
            let routine = Routine(name: name, notes: notes, category: category, estimatedMinutes: minutes)
            context.insert(routine)
            for (index, item) in exercises.enumerated() {
                guard let exercise = ExerciseCatalog.exercise(id: item.0) else { continue }
                let routineExercise = RoutineExercise(
                    exercise: exercise,
                    order: index,
                    sets: item.1,
                    reps: item.2,
                    weightKg: item.3,
                    restSeconds: item.4
                )
                context.insert(routineExercise)
                routineExercise.routine = routine
            }
        }
    }

    private static func seedWorkouts(in context: ModelContext, profile: UserProfile) {
        let daysAgo = [1, 2, 4, 5, 7, 8, 10, 12, 13, 15, 17, 18, 20, 21, 23, 25, 26, 28, 30, 32]
        let planDays = WorkoutPlans.foundation.days
        let calendar = PulseDate.calendar
        let today = calendar.startOfDay(for: .now)

        for (index, offset) in daysAgo.enumerated() {
            guard let day = calendar.date(byAdding: .day, value: -offset, to: today) else { continue }
            let dayPlan = planDays[index % planDays.count]
            let start = calendar.date(byAdding: .minute, value: 5 + (index % 3) * 12, to: day)!
                .addingTimeInterval(18 * 3600)
            let durationMinutes = dayPlan.estimatedMinutes + (index % 4) * 2
            let end = start.addingTimeInterval(Double(durationMinutes * 60))
            let progress = Double(max(32 - offset, 0)) / 7.0
            let calories = WorkoutAnalytics.estimatedCalories(
                category: .strength,
                minutes: Double(durationMinutes),
                weightKg: profile.weightKg
            )

            let session = WorkoutSession(
                title: dayPlan.title,
                category: .strength,
                startedAt: start,
                endedAt: end,
                estimatedCalories: calories
            )
            context.insert(session)

            var volume: Double = 0
            for (exerciseIndex, planExercise) in dayPlan.exercises.enumerated() {
                guard let exercise = ExerciseCatalog.exercise(id: planExercise.exerciseID) else { continue }
                let weight = baseWeight(for: exercise.equipment, progress: progress)
                for setIndex in 0..<planExercise.sets {
                    let completedAt = start.addingTimeInterval(
                        Double(300 + exerciseIndex * 420 + setIndex * 150)
                    )
                    let reps = max(planExercise.reps - (setIndex == planExercise.sets - 1 && index % 5 == 0 ? 1 : 0), 1)
                    let record = WorkoutSetRecord(
                        exerciseID: exercise.id,
                        exerciseName: exercise.name,
                        muscleGroup: exercise.primaryMuscle,
                        setIndex: setIndex,
                        reps: reps,
                        weightKg: weight,
                        completedAt: min(completedAt, end)
                    )
                    context.insert(record)
                    record.session = session
                    volume += Double(reps) * weight
                }
            }
            session.totalVolumeKg = volume

            if index == 0 {
                session.notes = "Felt strong through the squats. Kept the last set two reps shy of failure."
            }
        }

        let cardio: [(Int, String, WorkoutCategory, Int, Double)] = [
            (6, "Easy Run", .running, 30, 318),
            (14, "Easy Run", .running, 35, 356),
            (22, "Recovery Walk", .walking, 20, 96)
        ]
        for item in cardio {
            guard let day = calendar.date(byAdding: .day, value: -item.0, to: today) else { continue }
            let start = day.addingTimeInterval(7 * 3600 + 20 * 60)
            let session = WorkoutSession(
                title: item.1,
                category: item.2,
                startedAt: start,
                endedAt: start.addingTimeInterval(Double(item.3 * 60)),
                estimatedCalories: item.4,
                notes: "Steady and conversational."
            )
            context.insert(session)
        }
    }

    private static func baseWeight(for equipment: Equipment, progress: Double) -> Double {
        let value: Double
        switch equipment {
        case .barbell: value = 30 + progress * 2.5
        case .dumbbell: value = 8 + progress
        case .machine: value = 35 + progress * 4
        case .cable: value = 14 + progress * 2
        case .kettlebell: value = 12 + progress * 2
        case .band, .bodyweight, .none: value = 0
        }
        return (value * 2).rounded() / 2
    }

    private static func seedNutrition(in context: ModelContext) {
        let calendar = PulseDate.calendar
        let today = calendar.startOfDay(for: .now)

        let todayMeals: [(MealType, [(String, Double)])] = [
            (.breakfast, [("oats", 1), ("blueberries", 1), ("greek-yogurt", 1)]),
            (.lunch, [("chicken-breast", 1.5), ("brown-rice", 1.5), ("broccoli", 1)]),
            (.dinner, [("salmon", 1), ("sweet-potato", 1.5), ("spinach", 2)]),
            (.snacks, [("almonds", 1), ("protein-powder", 1), ("banana", 1)])
        ]
        addMeals(todayMeals, on: today, in: context, calendar: calendar)

        let previousMeals: [[(MealType, [(String, Double)])]] = [
            [(.breakfast, [("egg", 2), ("sourdough", 2), ("avocado", 1)]),
             (.lunch, [("turkey-sandwich", 1), ("mixed-salad", 1)]),
             (.dinner, [("ground-beef", 1), ("pasta", 1.5), ("broccoli", 1)]),
             (.snacks, [("protein-bar", 1), ("apple", 1)])],
            [(.breakfast, [("oats", 1), ("banana", 1), ("peanut-butter", 1)]),
             (.lunch, [("burrito-bowl", 1)]),
             (.dinner, [("tofu", 1), ("quinoa", 1), ("spinach", 2)]),
             (.snacks, [("almonds", 1), ("dark-chocolate", 1)])],
            [(.breakfast, [("greek-yogurt", 1), ("granola", 1), ("strawberries", 1)]),
             (.lunch, [("chicken-breast", 1), ("sweet-potato", 1), ("mixed-salad", 1)]),
             (.dinner, [("salmon", 1), ("brown-rice", 1), ("broccoli", 1)]),
             (.snacks, [("rice-cakes", 1), ("hummus", 1)])],
            [(.breakfast, [("egg", 3), ("whole-wheat-bread", 2)]),
             (.lunch, [("lentils", 1), ("quinoa", 1), ("spinach", 1)]),
             (.dinner, [("turkey", 1), ("pasta", 1), ("mixed-salad", 1)]),
             (.snacks, [("protein-powder", 1), ("banana", 1)])],
            [(.breakfast, [("oats", 1), ("protein-powder", 1), ("blueberries", 1)]),
             (.lunch, [("tuna", 1), ("sourdough", 2), ("carrots", 1)]),
             (.dinner, [("chickpeas", 1), ("sweet-potato", 1), ("broccoli", 1)]),
             (.snacks, [("cheddar", 1), ("apple", 1)])],
            [(.breakfast, [("greek-yogurt", 1), ("granola", 1), ("honey", 1)]),
             (.lunch, [("chicken-breast", 1), ("brown-rice", 1), ("broccoli", 1)]),
             (.dinner, [("pizza-slice", 2), ("mixed-salad", 1)]),
             (.snacks, [("ice-cream", 1)])]
        ]

        for (index, meals) in previousMeals.enumerated() {
            guard let day = calendar.date(byAdding: .day, value: -(index + 1), to: today) else { continue }
            addMeals(meals, on: day, in: context, calendar: calendar)
        }
    }

    private static func addMeals(
        _ meals: [(MealType, [(String, Double)])],
        on day: Date,
        in context: ModelContext,
        calendar: Calendar
    ) {
        let hours: [MealType: Int] = [.breakfast: 8, .lunch: 12, .dinner: 18, .snacks: 16]
        for (meal, items) in meals {
            for (itemIndex, item) in items.enumerated() {
                guard let food = FoodCatalog.item(id: item.0) else { continue }
                guard let date = calendar.date(
                    byAdding: .minute,
                    value: (hours[meal] ?? 12) * 60 + itemIndex * 7,
                    to: day
                ) else { continue }
                let servings = item.1
                let entry = FoodEntry(
                    date: date,
                    meal: meal,
                    name: food.name,
                    calories: food.calories * servings,
                    proteinG: food.proteinG * servings,
                    carbsG: food.carbsG * servings,
                    fatG: food.fatG * servings,
                    servings: servings,
                    servingDescription: food.servingDescription,
                    createdAt: date
                )
                context.insert(entry)
            }
        }
    }

    private static func seedHydration(in context: ModelContext) {
        let calendar = PulseDate.calendar
        let today = calendar.startOfDay(for: .now)

        let todayAmounts: [(Int, Double)] = [(7, 500), (11, 350), (15, 500)]
        for (hour, amount) in todayAmounts {
            let date = today.addingTimeInterval(Double(hour * 3600 + 25 * 60))
            context.insert(HydrationEntry(date: date, amountMl: amount, createdAt: date))
        }

        let past: [(Double, [Double])] = [
            (2_200, [400, 500, 600, 700]),
            (2_500, [500, 500, 750, 750]),
            (1_900, [350, 350, 600, 600]),
            (2_400, [500, 600, 600, 700]),
            (2_100, [400, 550, 550, 600]),
            (2_300, [500, 500, 650, 650])
        ]

        for (index, entry) in past.enumerated() {
            guard let day = calendar.date(byAdding: .day, value: -(index + 1), to: today) else { continue }
            for (drinkIndex, amount) in entry.1.enumerated() {
                let date = day.addingTimeInterval(Double(8 * 3600 + drinkIndex * 3 * 3600))
                context.insert(HydrationEntry(date: date, amountMl: amount, createdAt: date))
            }
        }
    }

    private static func seedWeights(in context: ModelContext) {
        let calendar = PulseDate.calendar
        let today = calendar.startOfDay(for: .now)

        for offset in stride(from: 28, through: 0, by: -2) {
            guard let day = calendar.date(byAdding: .day, value: -offset, to: today) else { continue }
            let wobble = Double((offset % 6) - 3) * 0.04
            let weight = 72.4 + Double(offset) * 0.075 + wobble
            let date = day.addingTimeInterval(7 * 3600 + 10 * 60)
            context.insert(WeightEntry(date: date, weightKg: weight, createdAt: date))
        }
    }
}
