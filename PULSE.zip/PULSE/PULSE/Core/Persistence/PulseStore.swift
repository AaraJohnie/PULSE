import Foundation
import SwiftData

enum PulseStore {
    static let schema = Schema([
        UserProfile.self,
        Routine.self,
        RoutineExercise.self,
        WorkoutSession.self,
        WorkoutSetRecord.self,
        FoodEntry.self,
        HydrationEntry.self,
        WeightEntry.self
    ])

    static func makeContainer() -> ModelContainer {
        let configuration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
        do {
            return try ModelContainer(for: schema, configurations: [configuration])
        } catch {
            assertionFailure("Failed to open persistent store: \(error)")
            let fallback = ModelConfiguration(schema: schema, isStoredInMemoryOnly: true)
            return try! ModelContainer(for: schema, configurations: [fallback])
        }
    }

    static func makePreviewContainer() -> ModelContainer {
        let configuration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: true)
        let container = try! ModelContainer(for: schema, configurations: [configuration])
        let context = ModelContext(container)
        let profile = UserProfile(
            name: "Alex Morgan",
            age: 31,
            heightCm: 178,
            weightKg: 72.4,
            level: .intermediate,
            goal: .buildStrength,
            activities: [.strength, .running, .walking],
            unitSystem: .metric,
            onboardingCompleted: true
        )
        profile.healthKitRequested = true
        context.insert(profile)
        PreviewData.seed(in: context, profile: profile)
        try? context.save()
        return container
    }
}
