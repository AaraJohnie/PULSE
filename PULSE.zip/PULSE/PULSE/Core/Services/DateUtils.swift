import Foundation

enum PulseDate {
    static var calendar: Calendar {
        var calendar = Calendar(identifier: .gregorian)
        calendar.firstWeekday = 2
        return calendar
    }

    static func startOfDay(_ date: Date = .now) -> Date {
        calendar.startOfDay(for: date)
    }

    static func isToday(_ date: Date) -> Bool {
        calendar.isDateInToday(date)
    }

    static func isSameDay(_ lhs: Date, _ rhs: Date) -> Bool {
        calendar.isDate(lhs, inSameDayAs: rhs)
    }

    static func days(endingAt date: Date = .now, count: Int) -> [Date] {
        let end = startOfDay(date)
        return (0..<max(count, 1)).reversed().compactMap {
            calendar.date(byAdding: .day, value: -$0, to: end)
        }
    }

    static func date(_ date: Date, addingDays days: Int) -> Date {
        calendar.date(byAdding: .day, value: days, to: date) ?? date
    }

    static func shortWeekday(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.calendar = calendar
        formatter.locale = .current
        formatter.dateFormat = "EEE"
        return formatter.string(from: date)
    }

    static func compactWeekday(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.calendar = calendar
        formatter.locale = .current
        formatter.dateFormat = "EEEEE"
        return formatter.string(from: date)
    }

    static func dayNumber(_ date: Date) -> String {
        date.formatted(.dateTime.day())
    }

    static func mediumDate(_ date: Date) -> String {
        date.formatted(.dateTime.weekday(.abbreviated).day().month(.abbreviated))
    }

    static func fullDate(_ date: Date) -> String {
        date.formatted(.dateTime.weekday(.wide).day().month(.wide))
    }

    static func fullDateUppercased(_ date: Date) -> String {
        fullDate(date).uppercased()
    }

    static func monthAndYear(_ date: Date) -> String {
        date.formatted(.dateTime.month(.wide).year())
    }

    static func greeting(_ date: Date = .now) -> String {
        switch calendar.component(.hour, from: date) {
        case 5..<12: "Good morning"
        case 12..<18: "Good afternoon"
        default: "Good evening"
        }
    }

    static func relativeDay(_ date: Date) -> String {
        if calendar.isDateInToday(date) { return "Today" }
        if calendar.isDateInYesterday(date) { return "Yesterday" }
        return mediumDate(date)
    }

    static func time(_ date: Date) -> String {
        date.formatted(date: .omitted, time: .shortened)
    }

    static func clock(_ interval: TimeInterval) -> String {
        let total = max(Int(interval.rounded()), 0)
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let seconds = total % 60
        if hours > 0 {
            return String(format: "%d:%02d:%02d", hours, minutes, seconds)
        }
        return String(format: "%02d:%02d", minutes, seconds)
    }

    static func restClock(_ interval: TimeInterval) -> String {
        let total = max(Int(interval.rounded(.up)), 0)
        return String(format: "%d:%02d", total / 60, total % 60)
    }

    static func minutesLabel(_ minutes: Double) -> String {
        let value = max(Int(minutes.rounded()), 0)
        return "\(value) min"
    }

    static func durationLabel(_ interval: TimeInterval) -> String {
        let minutes = max(Int((interval / 60).rounded()), 1)
        if minutes >= 60 {
            let hours = minutes / 60
            let remainder = minutes % 60
            return remainder == 0 ? "\(hours) hr" : "\(hours) hr \(remainder) min"
        }
        return "\(minutes) min"
    }

    static func weekRange(days dayCount: Int = 7) -> [Date] {
        days(endingAt: .now, count: dayCount)
    }

    static func startOfWeek(_ date: Date = .now) -> Date {
        calendar.dateInterval(of: .weekOfYear, for: date)?.start ?? startOfDay(date)
    }

    static func startOfMonth(_ date: Date = .now) -> Date {
        calendar.dateInterval(of: .month, for: date)?.start ?? startOfDay(date)
    }
}
