import Foundation

/// Resolves dashboard data from Apple Health or clearly-labelled preview samples.
@MainActor
struct HealthDataProvider {
    let profile: UserProfile?
    let health: HealthKitService

    var isPreview: Bool {
        profile?.usesPreviewData == true
    }

    var usesHealthKit: Bool {
        profile?.healthKitRequested == true
    }

    var hasLiveAccess: Bool {
        usesHealthKit && health.accessState == .requested
    }

    var isLoading: Bool {
        hasLiveAccess && health.isLoading && !health.hasDashboardData
    }

    var today: HealthSnapshot {
        if isPreview { return PreviewData.todaySnapshot }
        return health.today
    }

    var hourlySteps: [HourlyStep] {
        if isPreview { return PreviewData.hourlySteps }
        return health.hourlySteps
    }

    func dailyMetrics(days: Int) -> [DailyHealthMetric] {
        if isPreview { return PreviewData.dailyMetrics(days: days) }
        let available = health.dailyMetrics
        guard !available.isEmpty else { return [] }
        let cutoff = PulseDate.days(endingAt: .now, count: max(days, 1)).first ?? .now
        return available.filter { $0.date >= cutoff }.sorted { $0.date < $1.date }
    }

    var hasAnyData: Bool {
        isPreview || !health.dailyMetrics.isEmpty || !health.today.isEmpty
    }

    var needsConnection: Bool {
        !usesHealthKit && !isPreview
    }

    var connectedButEmpty: Bool {
        hasLiveAccess && !isPreview && !health.hasDashboardData
    }
}
