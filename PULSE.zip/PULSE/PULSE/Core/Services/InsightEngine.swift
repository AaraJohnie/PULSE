import Foundation

struct CoachInsight: Identifiable, Hashable {
    enum Tone: Hashable {
        case positive
        case neutral
        case attention
    }

    let id: String
    let title: String
    let message: String
    let symbol: String
    let tone: Tone

    init(title: String, message: String, symbol: String, tone: Tone) {
        self.id = title
        self.title = title
        self.message = message
        self.symbol = symbol
        self.tone = tone
    }
}

struct InsightContext {
    var stepsToday: Double
    var averageSteps: Double?
    var workoutsThisWeek: Int
    var streak: Int
    var hydrationMl: Double
    var hydrationGoalMl: Double
    var hour: Int
}

enum InsightEngine {
    static func insight(for context: InsightContext, units: UnitSystem) -> CoachInsight {
        let progress = context.hydrationGoalMl > 0 ? context.hydrationMl / context.hydrationGoalMl : 0
        if context.hour >= 13, progress < 0.45 {
            return CoachInsight(
                title: "A little more water",
                message: "You're at \(UnitFormatter.waterTotal(ml: context.hydrationMl, units: units)) of \(UnitFormatter.waterGoal(ml: context.hydrationGoalMl, units: units)). A glass now keeps your afternoon steady.",
                symbol: "drop.fill",
                tone: .attention
            )
        }

        if context.streak >= 3 {
            return CoachInsight(
                title: "\(context.streak)-day rhythm",
                message: "You've trained \(context.streak) days in a row. Keep today honest, not heroic — even a short session protects the streak.",
                symbol: "flame.fill",
                tone: .positive
            )
        }

        if let average = context.averageSteps, average > 0, context.stepsToday > average * 1.05 {
            let difference = (context.stepsToday / average - 1)
            return CoachInsight(
                title: "Ahead of your usual pace",
                message: "\(UnitFormatter.steps(context.stepsToday)) steps so far — \(UnitFormatter.percent(difference)) above your recent daily average.",
                symbol: "figure.walk.motion",
                tone: .positive
            )
        }

        if context.workoutsThisWeek >= 3 {
            return CoachInsight(
                title: "Consistency is compounding",
                message: "\(context.workoutsThisWeek) sessions logged this week. Recovery is part of the plan — prioritise sleep and protein today.",
                symbol: "chart.line.uptrend.xyaxis",
                tone: .positive
            )
        }

        if let average = context.averageSteps, context.stepsToday < average * 0.5, context.hour >= 16 {
            return CoachInsight(
                title: "A short walk still counts",
                message: "You're at \(UnitFormatter.steps(context.stepsToday)) steps today. Ten minutes outside is enough to reset the rhythm.",
                symbol: "figure.walk",
                tone: .neutral
            )
        }

        if context.workoutsThisWeek == 0 {
            return CoachInsight(
                title: "Your week is still open",
                message: "Nothing logged yet this week. A 20-minute session is enough to make this week count.",
                symbol: "calendar.badge.plus",
                tone: .neutral
            )
        }

        return CoachInsight(
            title: "Stay with your rhythm",
            message: "Small, repeatable choices win the week. Move often, eat with intention, and let your sleep do the repair.",
            symbol: "waveform.path.ecg",
            tone: .positive
        )
    }
}
