import Foundation
import UserNotifications

@MainActor
final class NotificationService {
    static let shared = NotificationService()

    private let center = UNUserNotificationCenter.current()
    private let restIdentifier = "pulse.rest.finished"
    private let reminderIdentifier = "pulse.reminder.daily"

    private init() {}

    func authorizationStatus() async -> UNAuthorizationStatus {
        await withCheckedContinuation { continuation in
            center.getNotificationSettings { settings in
                continuation.resume(returning: settings.authorizationStatus)
            }
        }
    }

    func requestAuthorization() async -> Bool {
        do {
            let granted = try await center.requestAuthorization(options: [.alert, .sound, .badge])
            return granted
        } catch {
            return false
        }
    }

    func scheduleRestFinished(after seconds: Int, title: String) async {
        guard seconds > 0 else { return }
        let status = await authorizationStatus()
        guard status == .authorized || status == .provisional else { return }

        let content = UNMutableNotificationContent()
        content.title = "Rest complete"
        content.body = "Next set is ready in \(title)."
        content.sound = .default
        content.interruptionLevel = .timeSensitive

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: TimeInterval(max(seconds, 1)), repeats: false)
        let request = UNNotificationRequest(identifier: restIdentifier, content: content, trigger: trigger)
        try? await center.add(request)
    }

    func cancelRestFinished() {
        center.removePendingNotificationRequests(withIdentifiers: [restIdentifier])
        center.removeDeliveredNotifications(withIdentifiers: [restIdentifier])
    }

    func setWorkoutReminders(enabled: Bool) async -> Bool {
        center.removePendingNotificationRequests(withIdentifiers: [reminderIdentifier])
        guard enabled else { return true }

        let status = await authorizationStatus()
        var granted = status == .authorized || status == .provisional
        if status == .notDetermined {
            granted = await requestAuthorization()
        }
        guard granted else { return false }

        let content = UNMutableNotificationContent()
        content.title = "Your PULSE session is waiting"
        content.body = "A short session today keeps your rhythm intact."
        content.sound = .default

        var components = DateComponents()
        components.hour = 18
        components.minute = 0
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: true)
        let request = UNNotificationRequest(identifier: reminderIdentifier, content: content, trigger: trigger)
        do {
            try await center.add(request)
            return true
        } catch {
            return false
        }
    }

    func sendWelcomeReminderInOneHour() async {
        let status = await authorizationStatus()
        guard status == .authorized || status == .provisional else { return }
        let content = UNMutableNotificationContent()
        content.title = "Your rhythm starts here"
        content.body = "Log your first meal or start a short session to begin building your week."
        content.sound = .default
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 3600, repeats: false)
        try? await center.add(UNNotificationRequest(identifier: "pulse.welcome", content: content, trigger: trigger))
    }
}
