import Foundation
import WatchConnectivity
import Observation

struct WatchWorkoutPayload: Codable, Identifiable, Equatable {
    var id: UUID
    var title: String
    var categoryRaw: String
    var startedAt: Date
    var endedAt: Date
    var activeEnergy: Double?
    var averageHeartRate: Double?
    var maxHeartRate: Double?
    var distanceMeters: Double?

    var category: WorkoutCategory {
        WorkoutCategory(rawValue: categoryRaw) ?? .strength
    }

    var durationMinutes: Int {
        max(1, Int(endedAt.timeIntervalSince(startedAt) / 60))
    }
}

@Observable
final class PhoneWatchSession: NSObject, WCSessionDelegate {
    static let shared = PhoneWatchSession()

    var isSupported = WCSession.isSupported()
    var isReachable = false
    var isPaired = false
    var isWatchAppInstalled = false
    var pendingWorkout: WatchWorkoutPayload?

    private var isActivated = false
    private var pendingPreferences: [String: Any]?

    private override init() {
        super.init()
    }

    func activate() {
        guard WCSession.isSupported(), !isActivated else { return }
        isActivated = true
        let session = WCSession.default
        session.delegate = self
        session.activate()
    }

    func publishPreferences(units: UnitSystem, moveGoal: Double) {
        pendingPreferences = [
            "units": units.rawValue,
            "moveGoal": moveGoal
        ]
        deliverPreferences()
    }

    private func deliverPreferences() {
        guard WCSession.isSupported(), let pendingPreferences else { return }
        guard WCSession.default.activationState == .activated else { return }
        try? WCSession.default.updateApplicationContext(pendingPreferences)
    }

    func session(
        _ session: WCSession,
        activationDidCompleteWith activationState: WCSessionActivationState,
        error: Error?
    ) {
        DispatchQueue.main.async {
            self.isPaired = session.isPaired
            self.isWatchAppInstalled = session.isWatchAppInstalled
            self.isReachable = session.isReachable
            self.deliverPreferences()
        }
    }

    func sessionReachabilityDidChange(_ session: WCSession) {
        DispatchQueue.main.async {
            self.isReachable = session.isReachable
            self.isPaired = session.isPaired
            self.isWatchAppInstalled = session.isWatchAppInstalled
            self.deliverPreferences()
        }
    }

    func sessionDidBecomeInactive(_ session: WCSession) {}

    func sessionDidDeactivate(_ session: WCSession) {
        session.activate()
    }

    func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {
        process(message)
    }

    func session(
        _ session: WCSession,
        didReceiveMessage message: [String: Any],
        replyHandler: @escaping ([String: Any]) -> Void
    ) {
        process(message)
        replyHandler(["received": true])
    }

    func session(_ session: WCSession, didReceiveUserInfo userInfo: [String: Any]) {
        process(userInfo)
    }

    private func process(_ payload: [String: Any]) {
        guard let data = payload["workout"] as? Data else { return }
        let decoder = JSONDecoder()
        guard let workout = try? decoder.decode(WatchWorkoutPayload.self, from: data) else { return }
        DispatchQueue.main.async {
            self.pendingWorkout = workout
        }
    }
}
