import Foundation

enum UnitFormatter {
    static func integer(_ value: Double) -> String {
        value.formatted(.number.precision(.fractionLength(0)))
    }

    static func integer(_ value: Int) -> String {
        value.formatted(.number)
    }

    static func decimal(_ value: Double, places: Int = 1) -> String {
        value.formatted(.number.precision(.fractionLength(places)))
    }

    static func steps(_ value: Double) -> String {
        integer(value)
    }

    static func energy(_ calories: Double) -> String {
        integer(calories)
    }

    static func exerciseMinutes(_ minutes: Double) -> String {
        integer(minutes)
    }

    static func macro(_ grams: Double) -> String {
        "\(integer(grams)) g"
    }

    static func weightValue(kg: Double, units: UnitSystem) -> Double {
        units == .metric ? kg : kg * 2.2046226218
    }

    static func weight(kg: Double, units: UnitSystem, places: Int = 1) -> String {
        let value = weightValue(kg: kg, units: units)
        return "\(decimal(value, places: places)) \(units.weightUnit)"
    }

    static func weightPlain(kg: Double, units: UnitSystem, places: Int = 1) -> String {
        decimal(weightValue(kg: kg, units: units), places: places)
    }

    static func kilograms(from value: Double, units: UnitSystem) -> Double {
        units == .metric ? value : value / 2.2046226218
    }

    static func heightParts(cm: Double, units: UnitSystem) -> (primary: Int, secondary: Int?) {
        guard units == .imperial else {
            return (Int(cm.rounded()), nil)
        }
        let totalInches = (cm / 2.54).rounded()
        let feet = Int(totalInches) / 12
        var inches = Int(totalInches) % 12
        if inches == 12 { inches = 0 }
        return (feet, inches)
    }

    static func height(cm: Double, units: UnitSystem) -> String {
        switch units {
        case .metric:
            return "\(integer(cm)) cm"
        case .imperial:
            let parts = heightParts(cm: cm, units: units)
            return "\(parts.primary)′ \(parts.secondary ?? 0)″"
        }
    }

    static func heightValue(cm: Double, units: UnitSystem) -> Double {
        units == .metric ? cm : cm / 2.54
    }

    static func centimetres(from value: Double, units: UnitSystem) -> Double {
        units == .metric ? value : value * 2.54
    }

    static func distance(meters: Double, units: UnitSystem, places: Int = 1) -> String {
        let value = units == .metric ? meters / 1000 : meters / 1609.344
        return "\(decimal(value, places: places)) \(units.distanceUnit)"
    }

    static func distancePlain(meters: Double, units: UnitSystem, places: Int = 1) -> String {
        let value = units == .metric ? meters / 1000 : meters / 1609.344
        return decimal(value, places: places)
    }

    static func waterTotal(ml: Double, units: UnitSystem) -> String {
        switch units {
        case .metric:
            if ml >= 1000 {
                return "\(decimal(ml / 1000, places: 2)) L"
            }
            return "\(integer(ml)) ml"
        case .imperial:
            let ounces = ml / 29.5735
            return "\(integer(ounces)) fl oz"
        }
    }

    static func waterAmount(ml: Double, units: UnitSystem) -> String {
        switch units {
        case .metric:
            return "\(integer(ml)) ml"
        case .imperial:
            return "\(integer(ml / 29.5735)) fl oz"
        }
    }

    static func waterGoal(ml: Double, units: UnitSystem) -> String {
        waterTotal(ml: ml, units: units)
    }

    static func waterValue(ml: Double, units: UnitSystem) -> Double {
        units == .metric ? ml : ml / 29.5735
    }

    static func millilitres(from value: Double, units: UnitSystem) -> Double {
        units == .metric ? value : value * 29.5735
    }

    static func volume(kg: Double, units: UnitSystem) -> String {
        if units == .metric {
            if kg >= 1000 {
                return "\(decimal(kg / 1000, places: 1)) t"
            }
            return "\(integer(kg)) kg"
        }
        let pounds = kg * 2.2046226218
        return "\(integer(pounds)) lb"
    }

    static func pace(secondsPerKilometre: Double, units: UnitSystem) -> String {
        guard secondsPerKilometre.isFinite, secondsPerKilometre > 0 else { return "—" }
        let seconds = units == .metric ? secondsPerKilometre : secondsPerKilometre * 1.609344
        let minutes = Int(seconds) / 60
        let remainder = Int(seconds) % 60
        return "\(minutes)′\(String(format: "%02d", remainder))″/\(units.distanceUnit)"
    }

    static func percent(_ value: Double) -> String {
        "\(Int((value * 100).rounded()))%"
    }
}
