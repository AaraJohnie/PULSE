import Foundation

struct PersonalRecord: Identifiable, Hashable {
    let id: String
    let exerciseID: String
    let exerciseName: String
    let weightKg: Double
    let reps: Int
    let date: Date
    let isFirst: Bool

    init(exerciseID: String, exerciseName: String, weightKg: Double, reps: Int, date: Date, isFirst: Bool = false) {
        self.id = "\(exerciseID)-\(date.timeIntervalSince1970)"
        self.exerciseID = exerciseID
        self.exerciseName = exerciseName
        self.weightKg = weightKg
        self.reps = reps
        self.date = date
        self.isFirst = isFirst
    }
}

struct WorkoutStats {
    var totalWorkouts: Int = 0
    var totalMinutes: Int = 0
    var totalVolumeKg: Double = 0
    var currentStreak: Int = 0
    var longestStreak: Int = 0
    var workoutsThisWeek: Int = 0
    var minutesThisWeek: Int = 0
    var lastWorkoutAt: Date?
    var averageDurationMinutes: Int = 0
}

struct StrengthPoint: Identifiable, Hashable {
    let id: String
    let date: Date
    let weightKg: Double
    let reps: Int
}

struct ExerciseFrequency: Identifiable, Hashable {
    let id: String
    let name: String
    let sessions: Int
    let muscleGroup: MuscleGroup
}

enum WorkoutAnalytics {
    static func completed(_ sessions: [WorkoutSession]) -> [WorkoutSession] {
        sessions.filter { $0.status == .completed }
    }

    static func stats(_ sessions: [WorkoutSession], calendar: Calendar = PulseDate.calendar) -> WorkoutStats {
        let completed = completed(sessions)
        var stats = WorkoutStats()
        stats.totalWorkouts = completed.count
        stats.totalMinutes = completed.reduce(0) { $0 + $1.durationMinutes }
        stats.totalVolumeKg = completed.reduce(0) { $0 + $1.totalVolumeKg }
        stats.averageDurationMinutes = completed.isEmpty ? 0 : stats.totalMinutes / completed.count
        stats.lastWorkoutAt = completed.map(\.startedAt).max()

        let weekStart = calendar.dateInterval(of: .weekOfYear, for: .now)?.start ?? PulseDate.startOfWeek()
        let thisWeek = completed.filter { $0.startedAt >= weekStart }
        stats.workoutsThisWeek = thisWeek.count
        stats.minutesThisWeek = thisWeek.reduce(0) { $0 + $1.durationMinutes }

        let days = Set(completed.map { calendar.startOfDay(for: $0.startedAt) })
        stats.currentStreak = currentStreak(workoutDays: days, calendar: calendar)
        stats.longestStreak = longestStreak(workoutDays: days, calendar: calendar)
        return stats
    }

    static func currentStreak(
        workoutDays: Set<Date>,
        today: Date = .now,
        calendar: Calendar = PulseDate.calendar
    ) -> Int {
        guard !workoutDays.isEmpty else { return 0 }
        let start = calendar.startOfDay(for: today)
        var cursor = start
        if !workoutDays.contains(cursor) {
            guard let yesterday = calendar.date(byAdding: .day, value: -1, to: start),
                  workoutDays.contains(yesterday) else {
                return 0
            }
            cursor = yesterday
        }

        var streak = 0
        while workoutDays.contains(cursor) {
            streak += 1
            guard let previous = calendar.date(byAdding: .day, value: -1, to: cursor) else { break }
            cursor = previous
        }
        return streak
    }

    static func longestStreak(
        workoutDays: Set<Date>,
        calendar: Calendar = PulseDate.calendar
    ) -> Int {
        guard !workoutDays.isEmpty else { return 0 }
        let sorted = workoutDays.sorted()
        var longest = 1
        var current = 1
        for index in 1..<sorted.count {
            let previous = sorted[index - 1]
            let day = sorted[index]
            let gap = calendar.dateComponents([.day], from: previous, to: day).day ?? 0
            if gap == 1 {
                current += 1
                longest = max(longest, current)
            } else {
                current = 1
            }
        }
        return longest
    }

    static func personalRecords(from sessions: [WorkoutSession]) -> [PersonalRecord] {
        var best: [String: PersonalRecord] = [:]
        for session in completed(sessions) {
            for set in session.sets where set.weightKg > 0 {
                let existing = best[set.exerciseID]
                if existing == nil
                    || set.weightKg > existing!.weightKg
                    || (set.weightKg == existing!.weightKg && set.reps > existing!.reps) {
                    best[set.exerciseID] = PersonalRecord(
                        exerciseID: set.exerciseID,
                        exerciseName: set.exerciseName,
                        weightKg: set.weightKg,
                        reps: set.reps,
                        date: set.completedAt
                    )
                }
            }
        }
        return best.values.sorted { $0.weightKg > $1.weightKg }
    }

    static func newRecords(
        in session: WorkoutSession,
        comparedTo previousSessions: [WorkoutSession]
    ) -> [PersonalRecord] {
        let previous = personalRecords(from: previousSessions)
        var previousByID: [String: PersonalRecord] = [:]
        for record in previous { previousByID[record.exerciseID] = record }

        var currentBest: [String: (name: String, weight: Double, reps: Int, date: Date)] = [:]
        for set in session.sets where set.weightKg > 0 {
            let existing = currentBest[set.exerciseID]
            if existing == nil
                || set.weightKg > existing!.weight
                || (set.weightKg == existing!.weight && set.reps > existing!.reps) {
                currentBest[set.exerciseID] = (set.exerciseName, set.weightKg, set.reps, set.completedAt)
            }
        }

        return currentBest.compactMap { id, value in
            if let old = previousByID[id] {
                guard value.weight > old.weightKg || (value.weight == old.weightKg && value.reps > old.reps) else {
                    return nil
                }
                return PersonalRecord(
                    exerciseID: id,
                    exerciseName: value.name,
                    weightKg: value.weight,
                    reps: value.reps,
                    date: value.date
                )
            }
            return PersonalRecord(
                exerciseID: id,
                exerciseName: value.name,
                weightKg: value.weight,
                reps: value.reps,
                date: value.date,
                isFirst: true
            )
        }
        .sorted { $0.weightKg > $1.weightKg }
    }

    static func strengthProgression(
        exerciseID: String,
        sessions: [WorkoutSession]
    ) -> [StrengthPoint] {
        completed(sessions)
            .sorted { $0.startedAt < $1.startedAt }
            .compactMap { session in
                let sets = session.sets.filter { $0.exerciseID == exerciseID && $0.weightKg > 0 }
                guard let best = sets.max(by: { lhs, rhs in
                    if lhs.weightKg == rhs.weightKg { return lhs.reps < rhs.reps }
                    return lhs.weightKg < rhs.weightKg
                }) else { return nil }
                return StrengthPoint(
                    id: "\(exerciseID)-\(session.id.uuidString)",
                    date: session.startedAt,
                    weightKg: best.weightKg,
                    reps: best.reps
                )
            }
    }

    static func exerciseFrequency(sessions: [WorkoutSession], limit: Int = 6) -> [ExerciseFrequency] {
        var counts: [String: (name: String, sessions: Int, muscle: MuscleGroup)] = [:]
        for session in completed(sessions) {
            let grouped = Dictionary(grouping: session.sets, by: \.exerciseID)
            for (id, sets) in grouped {
                guard let first = sets.first else { continue }
                let existing = counts[id]
                counts[id] = (first.exerciseName, (existing?.sessions ?? 0) + 1, first.muscleGroup)
            }
        }
        return counts
            .map { ExerciseFrequency(id: $0.key, name: $0.value.name, sessions: $0.value.sessions, muscleGroup: $0.value.muscle) }
            .sorted { $0.sessions > $1.sessions }
            .prefix(limit)
            .map { $0 }
    }

    static func estimatedCalories(
        category: WorkoutCategory,
        minutes: Double,
        weightKg: Double
    ) -> Double? {
        guard minutes > 0, weightKg > 0 else { return nil }
        let hours = minutes / 60
        return (category.met * weightKg * hours).rounded()
    }

    static func activityDays(_ sessions: [WorkoutSession]) -> [Date: Int] {
        var result: [Date: Int] = [:]
        for session in completed(sessions) {
            let day = PulseDate.startOfDay(session.startedAt)
            result[day, default: 0] += 1
        }
        return result
    }
}
