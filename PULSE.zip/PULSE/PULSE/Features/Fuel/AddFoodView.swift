import SwiftUI
import SwiftData

struct AddFoodView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Environment(AppState.self) private var app
    @Query(sort: \FoodEntry.date, order: .reverse) private var recentEntries: [FoodEntry]

    let meal: MealType
    let date: Date

    @State private var selectedMeal: MealType
    @State private var search = ""
    @State private var selectedFood: FoodItem?
    @State private var showCustom = false

    init(meal: MealType, date: Date) {
        self.meal = meal
        self.date = date
        _selectedMeal = State(initialValue: meal)
    }

    private var results: [FoodItem] {
        FoodCatalog.search(search)
    }

    private var recentFoods: [FoodItem] {
        var seen = Set<String>()
        var items: [FoodItem] = []
        for entry in recentEntries {
            guard let food = FoodCatalog.all.first(where: { $0.name == entry.name }) else { continue }
            guard seen.insert(food.id).inserted else { continue }
            items.append(food)
            if items.count == 4 { break }
        }
        return items
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    VStack(alignment: .leading, spacing: 9) {
                        Text("Meal")
                            .pulseOverline()
                            .foregroundStyle(PulseColor.textTertiary)
                        ScrollView(.horizontal) {
                            HStack(spacing: 8) {
                                ForEach(MealType.allCases) { type in
                                    PulseChip(
                                        title: type.label,
                                        symbol: type.symbol,
                                        isSelected: selectedMeal == type,
                                        action: {
                                            withAnimation(.snappy(duration: 0.2)) {
                                                selectedMeal = type
                                            }
                                        }
                                    )
                                }
                            }
                        }
                        .scrollIndicators(.hidden)
                    }

                    if search.isEmpty, !recentFoods.isEmpty {
                        VStack(alignment: .leading, spacing: 10) {
                            PulseSectionHeader("Recent", overline: "Logged before")
                            VStack(spacing: 0) {
                                ForEach(recentFoods) { food in
                                    foodRow(food)
                                    if food.id != recentFoods.last?.id {
                                        PulseDivider().padding(.leading, 16)
                                    }
                                }
                            }
                            .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                            .overlay {
                                RoundedRectangle(cornerRadius: 20, style: .continuous)
                                    .strokeBorder(PulseColor.hairline, lineWidth: 1)
                            }
                        }
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        PulseSectionHeader(
                            search.isEmpty ? "Food library" : "Results",
                            overline: search.isEmpty ? "\(FoodCatalog.all.count) foods" : nil
                        )

                        if results.isEmpty {
                            PulseEmptyState(
                                symbol: "magnifyingglass",
                                title: "No match",
                                message: "Try a shorter search, or create a custom food with your own nutrition values.",
                                actionTitle: "Create custom food",
                                action: { showCustom = true },
                                compact: true
                            )
                        } else {
                            VStack(spacing: 0) {
                                ForEach(results) { food in
                                    foodRow(food)
                                    if food.id != results.last?.id {
                                        PulseDivider().padding(.leading, 16)
                                    }
                                }
                            }
                            .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                            .overlay {
                                RoundedRectangle(cornerRadius: 20, style: .continuous)
                                    .strokeBorder(PulseColor.hairline, lineWidth: 1)
                            }
                        }
                    }
                }
                .padding(.horizontal, PulseMetrics.screenPadding)
                .padding(.top, 8)
                .padding(.bottom, 28)
            }
            .scrollIndicators(.hidden)
            .pulseScreen()
            .navigationTitle("Add food")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $search, placement: .navigationBarDrawer(displayMode: .always), prompt: "Search foods")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                        .foregroundStyle(PulseColor.textSecondary)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showCustom = true
                    } label: {
                        Image(systemName: "plus")
                    }
                    .accessibilityLabel("Create custom food")
                }
            }
            .navigationDestination(item: $selectedFood) { food in
                FoodComposerView(food: food, meal: selectedMeal, date: date)
            }
            .sheet(isPresented: $showCustom) {
                CustomFoodView(meal: selectedMeal, date: date)
            }
        }
        .tint(PulseColor.accent)
    }

    private func foodRow(_ food: FoodItem) -> some View {
        Button {
            selectedFood = food
            Haptics.selection()
        } label: {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(food.name)
                        .font(PulseFont.callout.weight(.medium))
                        .foregroundStyle(PulseColor.textPrimary)
                    Text(food.servingDescription)
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.textTertiary)
                }

                Spacer(minLength: 8)

                VStack(alignment: .trailing, spacing: 3) {
                    Text("\(UnitFormatter.integer(food.calories)) kcal")
                        .font(PulseFont.caption.weight(.semibold))
                        .foregroundStyle(PulseColor.textPrimary)
                    Text("P \(UnitFormatter.integer(food.proteinG)) · C \(UnitFormatter.integer(food.carbsG)) · F \(UnitFormatter.integer(food.fatG))")
                        .font(.system(size: 10, weight: .regular))
                        .foregroundStyle(PulseColor.textTertiary)
                }

                Image(systemName: "chevron.right")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(PulseColor.textTertiary)
            }
            .padding(16)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Composer

struct FoodComposerView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Environment(AppState.self) private var app

    let food: FoodItem
    let date: Date

    @State private var meal: MealType
    @State private var servings: Double = 1

    init(food: FoodItem, meal: MealType, date: Date) {
        self.food = food
        self.date = date
        _meal = State(initialValue: meal)
    }

    private var totalCalories: Double { food.calories * servings }
    private var totalProtein: Double { food.proteinG * servings }
    private var totalCarbs: Double { food.carbsG * servings }
    private var totalFat: Double { food.fatG * servings }

    private var servingText: String {
        UnitFormatter.decimal(servings, places: servings == servings.rounded() ? 0 : 1)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(food.name)
                            .font(PulseFont.title)
                            .foregroundStyle(PulseColor.textPrimary)
                        Text(food.servingDescription)
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)
                    }

                    PulseCard {
                        VStack(spacing: 16) {
                            Text("\(UnitFormatter.integer(totalCalories))")
                                .font(PulseFont.number(46, weight: .semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                                .contentTransition(.numericText())
                            Text("kcal")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                                .offset(y: -10)

                            PulseDivider()

                            HStack(spacing: 0) {
                                macroSummary("Protein", value: totalProtein, tint: PulseColor.ringMove)
                                macroSummary("Carbs", value: totalCarbs, tint: PulseColor.ringExercise)
                                macroSummary("Fat", value: totalFat, tint: PulseColor.ringStand)
                            }
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Servings")
                                .pulseOverline()
                                .foregroundStyle(PulseColor.textTertiary)
                            Spacer()
                            Text("\(servingText) × \(food.servingDescription)")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textSecondary)
                        }

                        HStack(spacing: 16) {
                            Button {
                                adjust(by: -0.5)
                            } label: {
                                Image(systemName: "minus")
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundStyle(servings > 0.5 ? PulseColor.textPrimary : PulseColor.textTertiary)
                                    .frame(width: 46, height: 46)
                                    .background(PulseColor.surfaceMuted, in: Circle())
                            }
                            .buttonStyle(.plain)
                            .disabled(servings <= 0.5)
                            .accessibilityLabel("Decrease servings")

                            Slider(value: $servings, in: 0.5...5, step: 0.5)
                                .tint(PulseColor.accent)
                                .accessibilityLabel("Servings")
                                .accessibilityValue("\(servingText) servings")

                            Button {
                                adjust(by: 0.5)
                            } label: {
                                Image(systemName: "plus")
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundStyle(servings < 5 ? PulseColor.textPrimary : PulseColor.textTertiary)
                                    .frame(width: 46, height: 46)
                                    .background(PulseColor.surfaceMuted, in: Circle())
                            }
                            .buttonStyle(.plain)
                            .disabled(servings >= 5)
                            .accessibilityLabel("Increase servings")
                        }
                    }

                    VStack(alignment: .leading, spacing: 9) {
                        Text("Meal")
                            .pulseOverline()
                            .foregroundStyle(PulseColor.textTertiary)
                        ScrollView(.horizontal) {
                            HStack(spacing: 8) {
                                ForEach(MealType.allCases) { type in
                                    PulseChip(
                                        title: type.label,
                                        symbol: type.symbol,
                                        isSelected: meal == type,
                                        action: {
                                            withAnimation(.snappy(duration: 0.2)) {
                                                meal = type
                                            }
                                        }
                                    )
                                }
                            }
                        }
                        .scrollIndicators(.hidden)
                    }
                }
                .padding(.horizontal, PulseMetrics.screenPadding)
                .padding(.top, 12)
                .padding(.bottom, 24)
            }
            .scrollIndicators(.hidden)

            Button("Add to \(meal.label.lowercased())") {
                save()
            }
            .buttonStyle(.pulsePrimary)
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.bottom, 16)
        }
        .pulseScreen()
        .navigationTitle("Serving")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func macroSummary(_ title: String, value: Double, tint: Color) -> some View {
        VStack(spacing: 3) {
            Text("\(UnitFormatter.integer(value)) g")
                .font(PulseFont.number(17, weight: .semibold))
                .foregroundStyle(PulseColor.textPrimary)
                .contentTransition(.numericText())
            Text(title)
                .font(PulseFont.caption)
                .foregroundStyle(tint)
        }
        .frame(maxWidth: .infinity)
    }

    private func adjust(by delta: Double) {
        let next = min(max(servings + delta, 0.5), 5)
        withAnimation(.snappy(duration: 0.2)) {
            servings = next
        }
        Haptics.selection()
    }

    private func save() {
        let entry = FoodEntry(
            date: entryDate(),
            meal: meal,
            name: food.name,
            calories: totalCalories,
            proteinG: totalProtein,
            carbsG: totalCarbs,
            fatG: totalFat,
            servings: servings,
            servingDescription: food.servingDescription,
            createdAt: .now
        )
        context.insert(entry)
        try? context.save()
        Haptics.success()
        app.showToast("\(food.name) added to \(meal.label.lowercased())", symbol: "checkmark.circle.fill")
        dismiss()
    }

    private func entryDate() -> Date {
        PulseDate.isToday(date) ? Date() : date.addingTimeInterval(12 * 3600)
    }
}

// MARK: - Custom food

struct CustomFoodView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Environment(AppState.self) private var app

    let date: Date

    @State private var meal: MealType
    @State private var name = ""
    @State private var servingDescription = "1 serving"
    @State private var caloriesText = ""
    @State private var proteinText = ""
    @State private var carbsText = ""
    @State private var fatText = ""
    @State private var servings: Double = 1
    @State private var showValidation = false

    init(meal: MealType, date: Date) {
        self.date = date
        _meal = State(initialValue: meal)
    }

    private var caloriesPerServing: Double { Double(caloriesText) ?? 0 }
    private var proteinPerServing: Double { Double(proteinText) ?? 0 }
    private var carbsPerServing: Double { Double(carbsText) ?? 0 }
    private var fatPerServing: Double { Double(fatText) ?? 0 }

    private var trimmedName: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var canSave: Bool {
        trimmedName.count >= 2 && caloriesPerServing > 0 && servings > 0
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    PulseField(
                        title: "Food name",
                        placeholder: "e.g. Homemade granola",
                        text: $name,
                        error: showValidation && trimmedName.count < 2 ? "Add a name with at least 2 characters." : nil
                    )

                    PulseField(
                        title: "Serving description",
                        placeholder: "e.g. 1 bowl",
                        text: $servingDescription
                    )

                    PulseCard {
                        VStack(alignment: .leading, spacing: 14) {
                            HStack {
                                Text("Nutrition per serving")
                                    .font(PulseFont.headline)
                                    .foregroundStyle(PulseColor.textPrimary)
                                Spacer()
                                Text("\(UnitFormatter.decimal(servings, places: servings == servings.rounded() ? 0 : 1)) × serving")
                                    .font(PulseFont.caption)
                                    .foregroundStyle(PulseColor.textTertiary)
                            }

                            numberField("Calories", text: $caloriesText, unit: "kcal", isRequired: true)
                            HStack(spacing: 10) {
                                numberField("Protein", text: $proteinText, unit: "g")
                                numberField("Carbs", text: $carbsText, unit: "g")
                                numberField("Fat", text: $fatText, unit: "g")
                            }

                            if showValidation && caloriesPerServing <= 0 {
                                Text("Calories must be greater than zero.")
                                    .font(PulseFont.caption)
                                    .foregroundStyle(PulseColor.danger)
                            }
                        }
                    }

                    VStack(alignment: .leading, spacing: 9) {
                        HStack {
                            Text("Servings")
                                .pulseOverline()
                                .foregroundStyle(PulseColor.textTertiary)
                            Spacer()
                            Text(UnitFormatter.decimal(servings, places: servings == servings.rounded() ? 0 : 1))
                                .font(PulseFont.headline)
                                .foregroundStyle(PulseColor.textPrimary)
                                .contentTransition(.numericText())
                        }

                        Slider(value: $servings, in: 0.5...5, step: 0.5)
                            .tint(PulseColor.accent)
                            .accessibilityLabel("Servings")

                        HStack {
                            Text("0.5")
                            Spacer()
                            Text("5")
                        }
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.textTertiary)
                    }

                    VStack(alignment: .leading, spacing: 9) {
                        Text("Meal")
                            .pulseOverline()
                            .foregroundStyle(PulseColor.textTertiary)
                        ScrollView(.horizontal) {
                            HStack(spacing: 8) {
                                ForEach(MealType.allCases) { type in
                                    PulseChip(
                                        title: type.label,
                                        symbol: type.symbol,
                                        isSelected: meal == type,
                                        action: {
                                            withAnimation(.snappy(duration: 0.2)) {
                                                meal = type
                                            }
                                        }
                                    )
                                }
                            }
                        }
                        .scrollIndicators(.hidden)
                    }

                    Text("Your entry is saved only in PULSE. Nutrition values are estimates you control.")
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.textTertiary)
                }
                .padding(.horizontal, PulseMetrics.screenPadding)
                .padding(.top, 8)
                .padding(.bottom, 24)
            }
            .scrollIndicators(.hidden)
            .scrollDismissesKeyboard(.interactively)
            .pulseScreen()
            .navigationTitle("Custom food")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                        .foregroundStyle(PulseColor.textSecondary)
                }
            }
            .safeAreaInset(edge: .bottom) {
                Button("Add custom food") {
                    showValidation = true
                    guard canSave else { return }
                    save()
                }
                .buttonStyle(.pulsePrimary)
                .padding(.horizontal, PulseMetrics.screenPadding)
                .padding(.vertical, 12)
                .background(.ultraThinMaterial)
            }
        }
        .tint(PulseColor.accent)
    }

    private func numberField(_ title: String, text: Binding<String>, unit: String, isRequired: Bool = false) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 2) {
                Text(title)
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
                if isRequired {
                    Text("*")
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.danger)
                }
            }

            HStack(spacing: 4) {
                TextField("0", text: text)
                    .font(PulseFont.number(17, weight: .medium))
                    .foregroundStyle(PulseColor.textPrimary)
                    .keyboardType(.decimalPad)
                    .accessibilityLabel(title)
                Text(unit)
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 9)
            .background(PulseColor.surfaceMuted, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func save() {
        let roundedServings = servings
        let foodName = trimmedName
        let description = servingDescription.trimmingCharacters(in: .whitespacesAndNewlines)
        let entry = FoodEntry(
            date: PulseDate.isToday(date) ? Date() : date.addingTimeInterval(12 * 3600),
            meal: meal,
            name: foodName,
            calories: caloriesPerServing * roundedServings,
            proteinG: proteinPerServing * roundedServings,
            carbsG: carbsPerServing * roundedServings,
            fatG: fatPerServing * roundedServings,
            servings: roundedServings,
            servingDescription: description.isEmpty ? "1 serving" : description,
            createdAt: .now
        )
        context.insert(entry)
        try? context.save()
        Haptics.success()
        app.showToast("\(foodName) added to \(meal.label.lowercased())", symbol: "checkmark.circle.fill")
        dismiss()
    }
}

// MARK: - Entry editor

struct FoodEntryEditorView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Environment(AppState.self) private var app

    let entry: FoodEntry

    @State private var meal: MealType
    @State private var servings: Double
    @State private var showDelete = false

    init(entry: FoodEntry) {
        self.entry = entry
        _meal = State(initialValue: entry.meal)
        _servings = State(initialValue: max(entry.servings, 0.5))
    }

    private var perServingCalories: Double {
        entry.servings > 0 ? entry.calories / entry.servings : entry.calories
    }
    private var perServingProtein: Double {
        entry.servings > 0 ? entry.proteinG / entry.servings : entry.proteinG
    }
    private var perServingCarbs: Double {
        entry.servings > 0 ? entry.carbsG / entry.servings : entry.carbsG
    }
    private var perServingFat: Double {
        entry.servings > 0 ? entry.fatG / entry.servings : entry.fatG
    }

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 22) {
                PulseSheetHeader(
                    title: entry.name,
                    subtitle: entry.servingDescription
                )

                VStack(spacing: 18) {
                    HStack(alignment: .firstTextBaseline, spacing: 5) {
                        Text(UnitFormatter.integer(perServingCalories * servings))
                            .font(PulseFont.number(44, weight: .semibold))
                            .foregroundStyle(PulseColor.textPrimary)
                            .contentTransition(.numericText())
                        Text("kcal")
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textTertiary)
                    }

                    HStack(spacing: 0) {
                        macroColumn("Protein", value: perServingProtein * servings, tint: PulseColor.ringMove)
                        macroColumn("Carbs", value: perServingCarbs * servings, tint: PulseColor.ringExercise)
                        macroColumn("Fat", value: perServingFat * servings, tint: PulseColor.ringStand)
                    }

                    HStack(spacing: 16) {
                        Button {
                            servings = max(0.5, servings - 0.5)
                            Haptics.selection()
                        } label: {
                            Image(systemName: "minus")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                                .frame(width: 46, height: 46)
                                .background(PulseColor.surfaceMuted, in: Circle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Decrease servings")

                        Slider(value: $servings, in: 0.5...5, step: 0.5)
                            .tint(PulseColor.accent)
                            .accessibilityLabel("Servings")

                        Button {
                            servings = min(5, servings + 0.5)
                            Haptics.selection()
                        } label: {
                            Image(systemName: "plus")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                                .frame(width: 46, height: 46)
                                .background(PulseColor.surfaceMuted, in: Circle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Increase servings")
                    }

                    VStack(alignment: .leading, spacing: 9) {
                        Text("Meal")
                            .pulseOverline()
                            .foregroundStyle(PulseColor.textTertiary)
                        ScrollView(.horizontal) {
                            HStack(spacing: 8) {
                                ForEach(MealType.allCases) { type in
                                    PulseChip(
                                        title: type.label,
                                        symbol: type.symbol,
                                        isSelected: meal == type,
                                        action: {
                                            withAnimation(.snappy(duration: 0.2)) {
                                                meal = type
                                            }
                                        }
                                    )
                                }
                            }
                        }
                        .scrollIndicators(.hidden)
                    }
                }
                .padding(.horizontal, PulseMetrics.screenPadding)

                Spacer(minLength: 0)

                VStack(spacing: 10) {
                    Button("Save changes") {
                        save()
                    }
                    .buttonStyle(.pulsePrimary)

                    Button(role: .destructive) {
                        showDelete = true
                    } label: {
                        Text("Remove entry")
                            .font(PulseFont.footnote.weight(.semibold))
                            .foregroundStyle(PulseColor.danger)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, PulseMetrics.screenPadding)
                .padding(.bottom, 16)
            }
            .background(PulseColor.background)
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
            .confirmationDialog("Remove this entry?", isPresented: $showDelete, titleVisibility: .visible) {
                Button("Remove", role: .destructive) {
                    deleteEntry()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("\(entry.name) will be removed from your daily totals.")
            }
        }
        .tint(PulseColor.accent)
    }

    private func macroColumn(_ title: String, value: Double, tint: Color) -> some View {
        VStack(spacing: 3) {
            Text("\(UnitFormatter.integer(value)) g")
                .font(PulseFont.number(16, weight: .semibold))
                .foregroundStyle(PulseColor.textPrimary)
            Text(title)
                .font(PulseFont.caption)
                .foregroundStyle(tint)
        }
        .frame(maxWidth: .infinity)
    }

    private func save() {
        entry.meal = meal
        entry.servings = servings
        entry.calories = perServingCalories * servings
        entry.proteinG = perServingProtein * servings
        entry.carbsG = perServingCarbs * servings
        entry.fatG = perServingFat * servings
        try? context.save()
        Haptics.success()
        app.showToast("Serving updated", symbol: "checkmark.circle.fill")
        dismiss()
    }

    private func deleteEntry() {
        context.delete(entry)
        try? context.save()
        Haptics.tap()
        app.showToast("Entry removed", symbol: "trash")
        dismiss()
    }
}
