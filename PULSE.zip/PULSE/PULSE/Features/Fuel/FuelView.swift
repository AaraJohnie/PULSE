import SwiftUI
import SwiftData
import Charts

struct FuelView: View {
    @Environment(AppState.self) private var app
    @Environment(\.modelContext) private var context
    @Query(sort: \FoodEntry.date, order: .reverse) private var entries: [FoodEntry]
    @Query(sort: \HydrationEntry.date, order: .reverse) private var hydration: [HydrationEntry]

    let profile: UserProfile

    @State private var selectedDate = PulseDate.startOfDay()
    @State private var addMeal: MealType?
    @State private var editingEntry: FoodEntry?
    @State private var pendingDelete: FoodEntry?
    @State private var showDeleteConfirm = false
    @State private var showCustomWater = false
    @State private var showHydrationGoal = false

    private var dayEntries: [FoodEntry] {
        entries.filter { PulseDate.isSameDay($0.date, selectedDate) }
    }

    private var totals: NutritionTotals {
        NutritionTotals(entries: dayEntries)
    }

    private var waterTotal: Double {
        hydration
            .filter { PulseDate.isSameDay($0.date, selectedDate) }
            .reduce(0) { $0 + $1.amountMl }
    }

    private var isToday: Bool {
        PulseDate.isToday(selectedDate)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                PulsePageTitle(
                    "Fuel",
                    eyebrow: "Nutrition",
                    subtitle: "Energy in, balanced across the day."
                )

                if profile.usesPreviewData {
                    PreviewDataBanner(compact: true)
                }

                dateNavigator
                summaryCard
                hydrationCard

                ForEach(MealType.allCases) { meal in
                    mealCard(meal)
                }

                historyLink
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 8)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .toolbar(.hidden, for: .navigationBar)
        .sheet(item: $addMeal) { meal in
            AddFoodView(meal: meal, date: selectedDate)
        }
        .sheet(item: $editingEntry) { entry in
            FoodEntryEditorView(entry: entry)
        }
        .sheet(isPresented: $showCustomWater) {
            QuickAddWaterSheet(goalMl: profile.hydrationGoalMl, units: profile.unitSystem) { amount in
                addWater(amount)
            }
        }
        .sheet(isPresented: $showHydrationGoal) {
            HydrationGoalSheet(currentGoalMl: profile.hydrationGoalMl, units: profile.unitSystem) { goal in
                profile.hydrationGoalMl = goal
                profile.updatedAt = .now
                try? context.save()
                app.showToast("Hydration goal updated", symbol: "drop.fill")
            }
        }
        .alert("Remove entry?", isPresented: $showDeleteConfirm, presenting: pendingDelete) { entry in
            Button("Remove", role: .destructive) {
                delete(entry)
            }
            Button("Cancel", role: .cancel) {}
        } message: { entry in
            Text("\(entry.name) will be removed from \(entry.meal.label.lowercased()).")
        }
    }

    // MARK: - Date

    private var dateNavigator: some View {
        HStack(spacing: 12) {
            Button {
                moveDay(by: -1)
            } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(PulseColor.textPrimary)
                    .frame(width: 42, height: 42)
                    .background(PulseColor.surface, in: Circle())
                    .overlay(Circle().strokeBorder(PulseColor.hairline, lineWidth: 1))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Previous day")

            Button {
                withAnimation(.snappy(duration: 0.25)) {
                    selectedDate = PulseDate.startOfDay()
                }
            } label: {
                VStack(spacing: 2) {
                    Text(PulseDate.relativeDay(selectedDate))
                        .font(PulseFont.headline)
                        .foregroundStyle(PulseColor.textPrimary)
                    Text(PulseDate.fullDate(selectedDate))
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.textTertiary)
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.plain)
            .accessibilityLabel(isToday ? "Today" : "Jump to today")

            Button {
                moveDay(by: 1)
            } label: {
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(canMoveForward ? PulseColor.textPrimary : PulseColor.textTertiary)
                    .frame(width: 42, height: 42)
                    .background(PulseColor.surface, in: Circle())
                    .overlay(Circle().strokeBorder(PulseColor.hairline, lineWidth: 1))
            }
            .buttonStyle(.plain)
            .disabled(!canMoveForward)
            .accessibilityLabel("Next day")
        }
    }

    private var canMoveForward: Bool {
        selectedDate < PulseDate.startOfDay()
    }

    private func moveDay(by offset: Int) {
        let next = PulseDate.date(selectedDate, addingDays: offset)
        guard next <= PulseDate.startOfDay() else { return }
        withAnimation(.snappy(duration: 0.25)) {
            selectedDate = next
        }
        Haptics.selection()
    }

    // MARK: - Summary

    private var summaryCard: some View {
        PulseCard {
            VStack(spacing: 18) {
                HStack(alignment: .center, spacing: 18) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Energy")
                            .pulseOverline()
                            .foregroundStyle(PulseColor.textTertiary)

                        HStack(alignment: .firstTextBaseline, spacing: 5) {
                            Text(UnitFormatter.integer(totals.calories))
                                .font(PulseFont.number(38, weight: .semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                                .contentTransition(.numericText())
                            Text("of \(UnitFormatter.integer(Double(profile.calorieGoal))) kcal")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }

                        if remaining >= 0 {
                            Text("\(UnitFormatter.integer(remaining)) kcal remaining")
                                .font(PulseFont.footnote)
                                .foregroundStyle(PulseColor.textSecondary)
                        } else {
                            Text("\(UnitFormatter.integer(abs(remaining))) kcal over target")
                                .font(PulseFont.footnote.weight(.medium))
                                .foregroundStyle(PulseColor.warning)
                        }
                    }

                    Spacer(minLength: 0)

                    ZStack {
                        PulseRing(
                            progress: calorieProgress,
                            color: calorieProgress > 1 ? PulseColor.warning : PulseColor.accent,
                            lineWidth: 9
                        )
                        VStack(spacing: 1) {
                            Text("\(Int((calorieProgress * 100).rounded()))")
                                .font(PulseFont.number(20, weight: .semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                            Text("%")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                    }
                    .frame(width: 86, height: 86)
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("Calories consumed")
                    .accessibilityValue("\(Int((calorieProgress * 100).rounded())) percent of goal")
                }

                PulseDivider()

                VStack(spacing: 12) {
                    macroRow("Protein", value: totals.protein, goal: Double(profile.proteinGoalG), tint: PulseColor.ringMove)
                    macroRow("Carbs", value: totals.carbs, goal: Double(profile.carbsGoalG), tint: PulseColor.ringExercise)
                    macroRow("Fat", value: totals.fat, goal: Double(profile.fatGoalG), tint: PulseColor.ringStand)
                }
            }
        }
    }

    private var calorieProgress: Double {
        guard profile.calorieGoal > 0 else { return 0 }
        return totals.calories / Double(profile.calorieGoal)
    }

    private var remaining: Int {
        profile.calorieGoal - Int(totals.calories.rounded())
    }

    private func macroRow(_ label: String, value: Double, goal: Double, tint: Color) -> some View {
        VStack(spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text(label)
                    .font(PulseFont.footnote.weight(.medium))
                    .foregroundStyle(PulseColor.textSecondary)
                Spacer()
                Text("\(UnitFormatter.integer(value)) / \(UnitFormatter.integer(goal)) g")
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
                    .monospacedDigit()
            }
            PulseProgressBar(value: goal > 0 ? value / goal : 0, tint: tint, height: 7)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(label)
        .accessibilityValue("\(UnitFormatter.integer(value)) of \(UnitFormatter.integer(goal)) grams")
    }

    // MARK: - Hydration

    private var hydrationCard: some View {
        HydrationCardView(
            totalMl: waterTotal,
            goalMl: profile.hydrationGoalMl,
            units: profile.unitSystem,
            isInteractive: true,
            onAdd: { amount in addWater(amount) },
            onCustom: { showCustomWater = true },
            onEditGoal: { showHydrationGoal = true }
        )
    }

    private func addWater(_ amount: Double) {
        let date = isToday ? Date() : selectedDate.addingTimeInterval(12 * 3600)
        context.insert(HydrationEntry(date: date, amountMl: amount, createdAt: .now))
        try? context.save()
        Haptics.success()
        app.showToast("\(UnitFormatter.waterAmount(ml: amount, units: profile.unitSystem)) logged", symbol: "drop.fill")
    }

    // MARK: - Meals

    private func mealCard(_ meal: MealType) -> some View {
        let mealEntries = dayEntries
            .filter { $0.meal == meal }
            .sorted { $0.createdAt < $1.createdAt }
        let calories = mealEntries.reduce(0) { $0 + $1.calories }

        return PulseCard(padding: 0) {
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    PulseIconTile(symbol: meal.symbol, tint: mealTint(meal), size: 36)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(meal.label)
                            .font(PulseFont.headline)
                            .foregroundStyle(PulseColor.textPrimary)
                        Text(mealEntries.isEmpty ? meal.defaultTimeHint : "\(UnitFormatter.integer(calories)) kcal")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                            .contentTransition(.numericText())
                    }

                    Spacer()

                    Button {
                        addMeal = meal
                        Haptics.selection()
                    } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(PulseColor.accent)
                            .frame(width: 34, height: 34)
                            .background(PulseColor.accent.opacity(0.12), in: Circle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Add food to \(meal.label)")
                }
                .padding(16)

                if mealEntries.isEmpty {
                    HStack(spacing: 8) {
                        Text("No food logged yet.")
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textTertiary)
                        Button("Add food") {
                            addMeal = meal
                        }
                        .font(PulseFont.footnote.weight(.semibold))
                        .foregroundStyle(PulseColor.accent)
                        .buttonStyle(.plain)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
                } else {
                    VStack(spacing: 0) {
                        ForEach(mealEntries) { entry in
                            foodRow(entry)

                            if entry.id != mealEntries.last?.id {
                                PulseDivider().padding(.leading, 16)
                            }
                        }
                    }
                    .padding(.bottom, 6)
                }
            }
            .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: PulseMetrics.cardRadius, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: PulseMetrics.cardRadius, style: .continuous)
                    .strokeBorder(PulseColor.hairline, lineWidth: 1)
            }
        }
    }

    private func mealTint(_ meal: MealType) -> Color {
        switch meal {
        case .breakfast: PulseColor.warning
        case .lunch: PulseColor.accent
        case .dinner: PulseColor.ringStand
        case .snacks: PulseColor.ringExercise
        }
    }

    private func foodRow(_ entry: FoodEntry) -> some View {
        Button {
            editingEntry = entry
        } label: {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(entry.name)
                        .font(PulseFont.callout.weight(.medium))
                        .foregroundStyle(PulseColor.textPrimary)
                        .lineLimit(1)
                    Text(servingLabel(entry))
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.textTertiary)
                        .lineLimit(1)
                    Text("P \(UnitFormatter.integer(entry.proteinG)) · C \(UnitFormatter.integer(entry.carbsG)) · F \(UnitFormatter.integer(entry.fatG))")
                        .font(.system(size: 11, weight: .regular))
                        .foregroundStyle(PulseColor.textTertiary.opacity(0.9))
                }

                Spacer(minLength: 8)

                Text("\(UnitFormatter.integer(entry.calories))")
                    .font(PulseFont.number(15, weight: .semibold))
                    .foregroundStyle(PulseColor.textPrimary)
                Text("kcal")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(PulseColor.textTertiary)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button {
                editingEntry = entry
            } label: {
                Label("Edit serving", systemImage: "slider.horizontal.3")
            }
            Button(role: .destructive) {
                pendingDelete = entry
                showDeleteConfirm = true
            } label: {
                Label("Remove", systemImage: "trash")
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(entry.name), \(UnitFormatter.integer(entry.calories)) calories")
        .accessibilityHint("Double tap to edit serving")
    }

    private func servingLabel(_ entry: FoodEntry) -> String {
        let servings = UnitFormatter.decimal(entry.servings, places: entry.servings == entry.servings.rounded() ? 0 : 1)
        if entry.servingDescription.isEmpty {
            return "\(servings) × serving"
        }
        return "\(servings) × \(entry.servingDescription)"
    }

    private func delete(_ entry: FoodEntry) {
        context.delete(entry)
        try? context.save()
        Haptics.tap()
        app.showToast("Entry removed", symbol: "trash")
        pendingDelete = nil
    }

    // MARK: - History

    private var historyLink: some View {
        NavigationLink {
            NutritionHistoryView(profile: profile)
        } label: {
            PulseCard {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Nutrition history")
                                .font(PulseFont.headline)
                                .foregroundStyle(PulseColor.textPrimary)
                            Text("Calories and macros across the week")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(PulseColor.textTertiary)
                    }

                    weekBars
                }
            }
        }
        .buttonStyle(.plain)
    }

    private var weekBars: some View {
        let days = PulseDate.days(endingAt: selectedDate, count: 7)
        let values = days.map { day in
            entries
                .filter { PulseDate.isSameDay($0.date, day) }
                .reduce(0) { $0 + $1.calories }
        }

        return HStack(alignment: .bottom, spacing: 8) {
            ForEach(Array(days.enumerated()), id: \.element) { index, day in
                VStack(spacing: 5) {
                    RoundedRectangle(cornerRadius: 5, style: .continuous)
                        .fill(PulseDate.isSameDay(day, selectedDate) ? PulseColor.accent : PulseColor.accent.opacity(0.28))
                        .frame(height: max(4, 42 * (values[index] / max(values.max() ?? 1, 1))))
                    Text(PulseDate.compactWeekday(day))
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(PulseColor.textTertiary)
                }
                .frame(maxWidth: .infinity)
            }
        }
        .frame(height: 60, alignment: .bottom)
        .accessibilityHidden(true)
    }
}

// MARK: - Totals

struct NutritionTotals {
    var calories: Double = 0
    var protein: Double = 0
    var carbs: Double = 0
    var fat: Double = 0

    init(entries: [FoodEntry]) {
        for entry in entries {
            calories += entry.calories
            protein += entry.proteinG
            carbs += entry.carbsG
            fat += entry.fatG
        }
    }
}

// MARK: - History

struct NutritionHistoryView: View {
    @Environment(AppState.self) private var app
    @Query(sort: \FoodEntry.date, order: .reverse) private var entries: [FoodEntry]

    let profile: UserProfile

    @State private var range: InsightRange = .week

    private var days: [Date] {
        PulseDate.days(endingAt: .now, count: range.days)
    }

    private var dailyCalories: [(date: Date, calories: Double)] {
        days.map { day in
            let total = entries
                .filter { PulseDate.isSameDay($0.date, day) }
                .reduce(0) { $0 + $1.calories }
            return (day, total)
        }
    }

    private var loggedDays: [Date] {
        dailyCalories.filter { $0.calories > 0 }.map(\.date)
    }

    private var averageCalories: Double {
        guard !dailyCalories.isEmpty else { return 0 }
        let total = dailyCalories.reduce(0) { $0 + $1.calories }
        return total / Double(dailyCalories.count)
    }

    private var averageProtein: Double {
        let relevant = entries.filter { entry in
            days.contains { PulseDate.isSameDay($0, entry.date) }
        }
        guard !days.isEmpty else { return 0 }
        return relevant.reduce(0) { $0 + $1.proteinG } / Double(days.count)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                PulseCard {
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            VStack(alignment: .leading, spacing: 3) {
                                Text("Daily calories")
                                    .font(PulseFont.headline)
                                    .foregroundStyle(PulseColor.textPrimary)
                                Text("Target \(UnitFormatter.integer(Double(profile.calorieGoal))) kcal")
                                    .font(PulseFont.caption)
                                    .foregroundStyle(PulseColor.textTertiary)
                            }
                            Spacer()
                            PulsePillBadge(
                                text: "\(loggedDays.count)/\(range.days) logged",
                                tint: loggedDays.isEmpty ? PulseColor.textTertiary : PulseColor.accent
                            )
                        }

                        if loggedDays.isEmpty {
                            PulseEmptyState(
                                symbol: "fork.knife",
                                title: "No meals logged",
                                message: "Log food from the Fuel tab and your history builds here.",
                                compact: true
                            )
                        } else {
                            Chart {
                                ForEach(dailyCalories, id: \.date) { item in
                                    BarMark(
                                        x: .value("Day", item.date, unit: .day),
                                        y: .value("Calories", item.calories)
                                    )
                                    .foregroundStyle(
                                        PulseDate.isToday(item.date)
                                            ? PulseColor.accent.gradient
                                            : PulseColor.accent.opacity(0.45).gradient
                                    )
                                    .cornerRadius(5)
                                }

                                RuleMark(y: .value("Goal", Double(profile.calorieGoal)))
                                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [4, 4]))
                                    .foregroundStyle(PulseColor.textTertiary.opacity(0.6))
                            }
                            .chartXAxis {
                                AxisMarks(values: .stride(by: .day, count: range == .month ? 7 : 1)) { _ in
                                    AxisValueLabel(format: .dateTime.weekday(.narrow))
                                        .foregroundStyle(PulseColor.textTertiary)
                                }
                            }
                            .chartYAxis {
                                AxisMarks(position: .leading, values: .automatic(desiredCount: 4)) { value in
                                    AxisValueLabel {
                                        if let number = value.as(Double.self) {
                                            Text(UnitFormatter.integer(number))
                                                .font(PulseFont.caption)
                                                .foregroundStyle(PulseColor.textTertiary)
                                        }
                                    }
                                }
                            }
                            .frame(height: 190)

                            HStack(spacing: 0) {
                                PulseMiniStat(value: "\(UnitFormatter.integer(averageCalories))", label: "Avg kcal")
                                PulseMiniStat(value: "\(UnitFormatter.integer(averageProtein)) g", label: "Avg protein")
                                PulseMiniStat(value: "\(loggedDays.count)", label: "Days logged")
                            }
                        }
                    }
                }

                PulseSegmentedControl(
                    items: InsightRange.allCases,
                    label: \.label,
                    selection: $range
                )

                VStack(alignment: .leading, spacing: 12) {
                    PulseSectionHeader("Daily log", overline: range == .week ? "Last 7 days" : "Last 30 days")

                    ForEach(dailyCalories.reversed(), id: \.date) { item in
                        dayRow(item.date, calories: item.calories)
                    }
                }
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 8)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .navigationTitle("Nutrition history")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func dayRow(_ date: Date, calories: Double) -> some View {
        let dayEntries = entries.filter { PulseDate.isSameDay($0.date, date) }
        let totals = NutritionTotals(entries: dayEntries)
        let progress = profile.calorieGoal > 0 ? min(calories / Double(profile.calorieGoal), 1) : 0

        return PulseCard(padding: 14) {
            VStack(spacing: 10) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(PulseDate.relativeDay(date))
                            .font(PulseFont.callout.weight(.medium))
                            .foregroundStyle(PulseColor.textPrimary)
                        Text("\(dayEntries.count) item\(dayEntries.count == 1 ? "" : "s") · P \(UnitFormatter.integer(totals.protein)) · C \(UnitFormatter.integer(totals.carbs)) · F \(UnitFormatter.integer(totals.fat))")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                    }
                    Spacer()
                    HStack(alignment: .firstTextBaseline, spacing: 3) {
                        Text(UnitFormatter.integer(calories))
                            .font(PulseFont.number(17, weight: .semibold))
                            .foregroundStyle(calories == 0 ? PulseColor.textTertiary : PulseColor.textPrimary)
                        Text("kcal")
                            .font(.system(size: 10, weight: .medium))
                            .foregroundStyle(PulseColor.textTertiary)
                    }
                }

                PulseProgressBar(
                    value: progress,
                    tint: calories > Double(profile.calorieGoal) ? PulseColor.warning : PulseColor.accent,
                    height: 5
                )
            }
        }
        .accessibilityElement(children: .combine)
    }
}
