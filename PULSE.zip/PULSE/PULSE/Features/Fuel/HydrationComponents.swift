import SwiftUI

struct HydrationCardView: View {
    let totalMl: Double
    let goalMl: Int
    let units: UnitSystem
    var isInteractive: Bool = true
    var onAdd: ((Double) -> Void)?
    var onCustom: (() -> Void)?
    var onEditGoal: (() -> Void)?

    private var progress: Double {
        guard goalMl > 0 else { return 0 }
        return min(max(totalMl / Double(goalMl), 0), 1)
    }

    private var quickAmounts: [Double] {
        units == .metric ? [250, 500] : [250, 500]
    }

    var body: some View {
        PulseCard {
            VStack(spacing: 16) {
                HStack(alignment: .top) {
                    HStack(spacing: 12) {
                        PulseIconTile(symbol: "drop.fill", tint: PulseColor.ringStand, size: 40)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Hydration")
                                .font(PulseFont.headline)
                                .foregroundStyle(PulseColor.textPrimary)
                            Text("\(UnitFormatter.waterTotal(ml: totalMl, units: units)) of \(UnitFormatter.waterGoal(ml: Double(goalMl), units: units))")
                                .font(PulseFont.footnote)
                                .foregroundStyle(PulseColor.textSecondary)
                                .contentTransition(.numericText())
                        }
                    }

                    Spacer(minLength: 8)

                    if let onEditGoal {
                        Button(action: onEditGoal) {
                            Text("Goal")
                                .font(PulseFont.caption.weight(.semibold))
                                .foregroundStyle(PulseColor.textSecondary)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(PulseColor.surfaceMuted, in: Capsule())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Edit hydration goal")
                    }
                }

                VStack(spacing: 7) {
                    PulseProgressBar(value: progress, tint: PulseColor.ringStand, height: 10)
                    HStack {
                        Text("\(Int((progress * 100).rounded()))%")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                        Spacer()
                        Text(remainingLabel)
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                    }
                }

                if isInteractive {
                    HStack(spacing: 10) {
                        ForEach(quickAmounts, id: \.self) { amount in
                            Button {
                                onAdd?(amount)
                            } label: {
                                HStack(spacing: 6) {
                                    Image(systemName: "plus")
                                        .font(.system(size: 10, weight: .bold))
                                    Text("\(UnitFormatter.waterAmount(ml: amount, units: units))")
                                        .font(PulseFont.footnote.weight(.semibold))
                                }
                                .foregroundStyle(PulseColor.ringStand)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 11)
                                .background(PulseColor.ringStand.opacity(0.12), in: Capsule())
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("Add \(UnitFormatter.waterAmount(ml: amount, units: units)) of water")
                        }

                        Button {
                            onCustom?()
                        } label: {
                            Image(systemName: "slider.horizontal.3")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundStyle(PulseColor.textSecondary)
                                .frame(width: 44, height: 40)
                                .background(PulseColor.surfaceMuted, in: Capsule())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Custom water amount")
                    }
                }
            }
        }
    }

    private var remainingLabel: String {
        let remaining = max(Double(goalMl) - totalMl, 0)
        if remaining <= 0 { return "Goal reached" }
        return "\(UnitFormatter.waterTotal(ml: remaining, units: units)) to go"
    }
}

struct QuickAddWaterSheet: View {
    let goalMl: Int
    let units: UnitSystem
    let onAdd: (Double) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var amountMl: Double = 250

    private let presets: [Double] = [200, 250, 350, 500, 750]

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 22) {
                PulseSheetHeader(
                    title: "Add water",
                    subtitle: "Daily goal \(UnitFormatter.waterGoal(ml: Double(goalMl), units: units))"
                )

                VStack(spacing: 18) {
                    Text(UnitFormatter.waterAmount(ml: amountMl, units: units))
                        .font(PulseFont.number(44, weight: .semibold))
                        .foregroundStyle(PulseColor.textPrimary)
                        .contentTransition(.numericText())
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)

                    HStack(spacing: 8) {
                        ForEach(presets, id: \.self) { preset in
                            PulseChip(
                                title: UnitFormatter.waterAmount(ml: preset, units: units).replacingOccurrences(of: " ", with: ""),
                                isSelected: amountMl == preset,
                                action: {
                                    withAnimation(.snappy(duration: 0.2)) { amountMl = preset }
                                }
                            )
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .center)

                    HStack(spacing: 16) {
                        Button {
                            amountMl = max(50, amountMl - 50)
                            Haptics.selection()
                        } label: {
                            Image(systemName: "minus")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                                .frame(width: 50, height: 50)
                                .background(PulseColor.surfaceMuted, in: Circle())
                        }
                        .buttonStyle(.plain)

                        Slider(value: $amountMl, in: 50...1000, step: 50)
                            .tint(PulseColor.ringStand)
                            .accessibilityLabel("Water amount")
                            .accessibilityValue(UnitFormatter.waterAmount(ml: amountMl, units: units))

                        Button {
                            amountMl = min(1000, amountMl + 50)
                            Haptics.selection()
                        } label: {
                            Image(systemName: "plus")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                                .frame(width: 50, height: 50)
                                .background(PulseColor.surfaceMuted, in: Circle())
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, PulseMetrics.screenPadding)

                Spacer(minLength: 0)

                Button("Add water") {
                    onAdd(amountMl)
                    dismiss()
                }
                .buttonStyle(PulsePrimaryButtonStyle(tint: PulseColor.ringStand, foreground: PulseColor.midnight))
                .padding(.horizontal, PulseMetrics.screenPadding)
                .padding(.bottom, 16)
            }
            .background(PulseColor.background)
            .presentationDetents([.medium])
            .presentationDragIndicator(.visible)
        }
    }
}

struct HydrationGoalSheet: View {
    let currentGoalMl: Int
    let units: UnitSystem
    let onSave: (Int) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var goalMl: Double

    init(currentGoalMl: Int, units: UnitSystem, onSave: @escaping (Int) -> Void) {
        self.currentGoalMl = currentGoalMl
        self.units = units
        self.onSave = onSave
        _goalMl = State(initialValue: Double(currentGoalMl))
    }

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 22) {
                PulseSheetHeader(title: "Hydration goal", subtitle: "Set a target that fits your day.")

                VStack(spacing: 16) {
                    Text(UnitFormatter.waterGoal(ml: goalMl, units: units))
                        .font(PulseFont.number(40, weight: .semibold))
                        .foregroundStyle(PulseColor.textPrimary)
                        .contentTransition(.numericText())

                    Slider(value: $goalMl, in: 1500...4500, step: 50)
                        .tint(PulseColor.ringStand)
                        .accessibilityLabel("Hydration goal")
                        .accessibilityValue(UnitFormatter.waterGoal(ml: goalMl, units: units))

                    HStack {
                        Text(UnitFormatter.waterGoal(ml: 1500, units: units))
                        Spacer()
                        Text(UnitFormatter.waterGoal(ml: 4500, units: units))
                    }
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)

                    Text("A common starting point is 35 ml per kilogram of body weight. Adjust with heat, training and your own thirst.")
                        .font(PulseFont.footnote)
                        .foregroundStyle(PulseColor.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.horizontal, PulseMetrics.screenPadding)

                Spacer(minLength: 0)

                Button("Save goal") {
                    onSave(Int(goalMl))
                    dismiss()
                }
                .buttonStyle(.pulsePrimary)
                .padding(.horizontal, PulseMetrics.screenPadding)
                .padding(.bottom, 16)
            }
            .background(PulseColor.background)
            .presentationDetents([.medium])
            .presentationDragIndicator(.visible)
        }
    }
}
