import SwiftUI
import SwiftData
import UIKit

struct HomeView: View {
    @Environment(AppState.self) private var app
    @Environment(\.modelContext) private var context

    let profile: UserProfile

    @Query private var sessions: [WorkoutSession]
    @Query private var routines: [Routine]
    @Query private var hydrationEntries: [HydrationEntry]

    @State private var showWaterSheet = false
    @State private var showGoalSheet = false
    @State private var isConnectingHealth = false

    private var provider: HealthDataProvider {
        HealthDataProvider(profile: profile, health: app.health)
    }

    private var snapshot: HealthSnapshot { provider.today }

    private var moveGoal: Double {
        max(320, (Double(profile.calorieGoal) * 0.12).rounded())
    }

    private var todayWaterMl: Double {
        hydrationEntries
            .filter { PulseDate.isSameDay($0.date, .now) }
            .reduce(0) { $0 + $1.amountMl }
    }

    private var completedToday: WorkoutSession? {
        WorkoutAnalytics.completed(sessions).first {
            PulseDate.isSameDay($0.startedAt, .now)
        }
    }

    private var stats: WorkoutStats {
        WorkoutAnalytics.stats(sessions)
    }

    private var insight: CoachInsight {
        let metrics = provider.dailyMetrics(days: 8)
        let previousDays = metrics.dropLast()
        let average = previousDays.isEmpty
            ? nil
            : previousDays.reduce(0) { $0 + $1.steps } / Double(previousDays.count)
        return InsightEngine.insight(
            for: InsightContext(
                stepsToday: snapshot.steps,
                averageSteps: average,
                workoutsThisWeek: stats.workoutsThisWeek,
                streak: stats.currentStreak,
                hydrationMl: todayWaterMl,
                hydrationGoalMl: Double(profile.hydrationGoalMl),
                hour: PulseDate.calendar.component(.hour, from: .now)
            ),
            units: profile.unitSystem
        )
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                HomeHeader(profile: profile) {
                    app.selectedTab = .you
                }

                if profile.usesPreviewData {
                    PreviewDataBanner(onManage: { app.selectedTab = .you })
                }

                if provider.needsConnection {
                    HealthConnectionCard(
                        isConnecting: isConnectingHealth,
                        action: connectHealth
                    )
                } else if provider.connectedButEmpty {
                    HealthEmptyCard(
                        onRefresh: { Task { await app.health.refresh(days: 30, force: true) } }
                    )
                }

                ActivityHeroCard(
                    snapshot: snapshot,
                    moveGoal: moveGoal,
                    exerciseGoal: 30,
                    standGoal: 12,
                    isLoading: provider.isLoading,
                    isPreview: provider.isPreview
                )

                if provider.isLoading {
                    PulseLoadingLabel()
                }

                LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                    PulseMetricTile(
                        symbol: "figure.walk",
                        value: UnitFormatter.steps(snapshot.steps),
                        label: "Steps",
                        tint: PulseColor.accent,
                        isLoading: provider.isLoading
                    )
                    PulseMetricTile(
                        symbol: "flame.fill",
                        value: UnitFormatter.energy(snapshot.activeEnergy),
                        unit: "kcal",
                        label: "Active energy",
                        tint: PulseColor.ringExercise,
                        isLoading: provider.isLoading
                    )
                    PulseMetricTile(
                        symbol: "stopwatch",
                        value: UnitFormatter.exerciseMinutes(snapshot.exerciseMinutes),
                        unit: "min",
                        label: "Exercise",
                        tint: PulseColor.ringMove,
                        isLoading: provider.isLoading
                    )
                    PulseMetricTile(
                        symbol: "location.fill",
                        value: UnitFormatter.distancePlain(meters: snapshot.distanceMeters, units: profile.unitSystem),
                        unit: profile.unitSystem.distanceUnit,
                        label: "Distance",
                        tint: PulseColor.ringStand,
                        isLoading: provider.isLoading
                    )
                }

                TodayWorkoutCard(
                    profile: profile,
                    completed: completedToday,
                    recommended: recommendedLaunch,
                    onStart: { launch in app.activeWorkout = launch },
                    onBrowse: { app.selectedTab = .train }
                )

                HydrationCardView(
                    totalMl: todayWaterMl,
                    goalMl: profile.hydrationGoalMl,
                    units: profile.unitSystem,
                    onAdd: addWater,
                    onCustom: { showWaterSheet = true },
                    onEditGoal: { showGoalSheet = true }
                )

                WeeklyRhythmCard(
                    metrics: provider.dailyMetrics(days: 7),
                    units: profile.unitSystem,
                    isLoading: provider.isLoading,
                    onOpenInsights: { app.selectedTab = .insights }
                )

                InsightCard(insight: insight)
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 8)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .toolbar(.hidden, for: .navigationBar)
        .sheet(isPresented: $showWaterSheet) {
            QuickAddWaterSheet(
                goalMl: profile.hydrationGoalMl,
                units: profile.unitSystem,
                onAdd: addWater
            )
        }
        .sheet(isPresented: $showGoalSheet) {
            HydrationGoalSheet(
                currentGoalMl: profile.hydrationGoalMl,
                units: profile.unitSystem
            ) { goal in
                profile.hydrationGoalMl = goal
                profile.updatedAt = .now
                try? context.save()
                app.showToast("Hydration goal updated")
            }
        }
    }

    private var recommendedLaunch: WorkoutLaunch? {
        if let routine = routines.min(by: {
            ($0.lastUsedAt ?? .distantPast) < ($1.lastUsedAt ?? .distantPast)
        }), !routine.orderedExercises.isEmpty {
            return WorkoutLaunch(routine: routine)
        }
        let plan = WorkoutPlans.foundation
        let weekday = PulseDate.calendar.component(.weekday, from: .now)
        let index = (weekday + 5) % max(plan.days.count, 1)
        guard plan.days.indices.contains(index) else { return nil }
        return WorkoutLaunch(plan: plan, day: plan.days[index])
    }

    private func addWater(_ amount: Double) {
        let entry = HydrationEntry(date: .now, amountMl: amount)
        context.insert(entry)
        try? context.save()
        Haptics.success()
    }

    private func connectHealth() {
        guard !isConnectingHealth else { return }
        isConnectingHealth = true
        Task {
            let granted = await app.health.requestAuthorization()
            profile.healthKitRequested = true
            profile.updatedAt = .now
            try? context.save()
            isConnectingHealth = false
            if granted {
                app.showToast("Apple Health connected", symbol: "heart.fill")
            } else {
                app.showToast(
                    "Health access wasn't granted. You can enable it in Settings.",
                    symbol: "exclamationmark.triangle.fill",
                    tone: .error
                )
            }
        }
    }
}

// MARK: - Header

private struct HomeHeader: View {
    let profile: UserProfile
    let onTapProfile: () -> Void

    var body: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 6) {
                Text(PulseDate.fullDateUppercased(.now))
                    .pulseOverline()
                    .foregroundStyle(PulseColor.textTertiary)
                Text("\(PulseDate.greeting()), \(profile.firstName).")
                    .font(PulseFont.largeTitle)
                    .foregroundStyle(PulseColor.textPrimary)
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)
            }

            Spacer(minLength: 12)

            Button(action: onTapProfile) {
                Text(profile.initials)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(PulseColor.sageFixed)
                    .frame(width: 44, height: 44)
                    .background(PulseColor.graphite, in: Circle())
                    .overlay(Circle().strokeBorder(PulseColor.sage.opacity(0.28), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Open your profile")
        }
    }
}

// MARK: - Hero

private struct ActivityHeroCard: View {
    let snapshot: HealthSnapshot
    let moveGoal: Double
    let exerciseGoal: Double
    let standGoal: Double
    let isLoading: Bool
    var isPreview: Bool = false

    private var moveProgress: Double { moveGoal > 0 ? snapshot.activeEnergy / moveGoal : 0 }
    private var exerciseProgress: Double { exerciseGoal > 0 ? snapshot.exerciseMinutes / exerciseGoal : 0 }
    private var standProgress: Double { standGoal > 0 ? snapshot.standHours / standGoal : 0 }

    var body: some View {
        PulseCard(padding: 22) {
            VStack(spacing: 20) {
                HStack {
                    Text("Today's rhythm")
                        .pulseOverline()
                        .foregroundStyle(PulseColor.textTertiary)
                    Spacer()
                    PulsePillBadge(
                        text: isLoading ? "Syncing" : (isPreview ? "Preview" : "Live"),
                        symbol: isLoading ? "arrow.triangle.2.circlepath" : (isPreview ? "sparkles" : "circle.fill"),
                        tint: isLoading ? PulseColor.textTertiary : (isPreview ? PulseColor.warning : PulseColor.accent)
                    )
                }

                ZStack {
                    ActivityRings(
                        move: min(moveProgress, 1),
                        exercise: min(exerciseProgress, 1),
                        stand: min(standProgress, 1),
                        size: 200,
                        lineWidth: 15
                    )

                    VStack(spacing: 2) {
                        Text(isLoading ? "—" : UnitFormatter.steps(snapshot.steps))
                            .font(PulseFont.number(28, weight: .semibold))
                            .foregroundStyle(PulseColor.textPrimary)
                            .contentTransition(.numericText())
                        Text("steps")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                    }
                }
                .padding(.vertical, 2)

                HStack(spacing: 0) {
                    RingStat(
                        color: PulseColor.ringMove,
                        value: UnitFormatter.energy(snapshot.activeEnergy),
                        unit: "kcal",
                        label: "Move",
                        progress: moveProgress
                    )
                    Divider().frame(height: 34).overlay(PulseColor.hairline)
                    RingStat(
                        color: PulseColor.ringExercise,
                        value: UnitFormatter.exerciseMinutes(snapshot.exerciseMinutes),
                        unit: "min",
                        label: "Exercise",
                        progress: exerciseProgress
                    )
                    Divider().frame(height: 34).overlay(PulseColor.hairline)
                    RingStat(
                        color: PulseColor.ringStand,
                        value: UnitFormatter.exerciseMinutes(snapshot.standHours),
                        unit: "hr",
                        label: "Stand",
                        progress: standProgress
                    )
                }
            }
        }
    }
}

private struct RingStat: View {
    let color: Color
    let value: String
    let unit: String
    let label: String
    let progress: Double

    var body: some View {
        VStack(spacing: 4) {
            HStack(spacing: 5) {
                Circle()
                    .fill(color)
                    .frame(width: 6, height: 6)
                Text(label)
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
            }
            HStack(alignment: .firstTextBaseline, spacing: 2) {
                Text(value)
                    .font(PulseFont.number(19, weight: .semibold))
                    .foregroundStyle(PulseColor.textPrimary)
                    .contentTransition(.numericText())
                Text(unit)
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
            }
        }
        .frame(maxWidth: .infinity)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(label)
        .accessibilityValue("\(value) \(unit), \(Int(min(progress, 1) * 100)) percent of goal")
    }
}

// MARK: - Today's workout

private struct TodayWorkoutCard: View {
    let profile: UserProfile
    let completed: WorkoutSession?
    let recommended: WorkoutLaunch?
    let onStart: (WorkoutLaunch) -> Void
    let onBrowse: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            PulseSectionHeader("Today's workout", overline: "Move")
                .padding(.horizontal, 2)

            if let completed {
                NavigationLink {
                    WorkoutDetailView(session: completed)
                } label: {
                    PulseCard {
                        HStack(spacing: 14) {
                            Image(systemName: "checkmark")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundStyle(PulseColor.midnight)
                                .frame(width: 44, height: 44)
                                .background(PulseColor.sage, in: Circle())

                            VStack(alignment: .leading, spacing: 4) {
                                Text("Session complete")
                                    .font(PulseFont.overline)
                                    .tracking(1.1)
                                    .textCase(.uppercase)
                                    .foregroundStyle(PulseColor.accent)
                                Text(completed.title)
                                    .font(PulseFont.headline)
                                    .foregroundStyle(PulseColor.textPrimary)
                                Text("\(completed.durationMinutes) min · \(completed.completedSetsCount) sets · \(UnitFormatter.volume(kg: completed.totalVolumeKg, units: profile.unitSystem))")
                                    .font(PulseFont.footnote)
                                    .foregroundStyle(PulseColor.textSecondary)
                            }

                            Spacer(minLength: 8)

                            Image(systemName: "chevron.right")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                    }
                }
                .buttonStyle(.plain)
            } else if let recommended {
                PulseCard(padding: 0) {
                    VStack(alignment: .leading, spacing: 18) {
                        ZStack(alignment: .topTrailing) {
                            LinearGradient(
                                colors: [PulseColor.graphite, Color(hex: 0x161B18)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                            .frame(height: 118)
                            .overlay(alignment: .bottomLeading) {
                                VStack(alignment: .leading, spacing: 5) {
                                    HStack(spacing: 6) {
                                        Image(systemName: recommended.category.symbol)
                                        Text(recommended.category.label.uppercased())
                                    }
                                    .font(PulseFont.overline)
                                    .tracking(1.2)
                                    .foregroundStyle(PulseColor.sage)

                                    Text(recommended.title)
                                        .font(PulseFont.title)
                                        .foregroundStyle(PulseColor.ivory)
                                        .lineLimit(2)
                                }
                                .padding(18)
                            }
                            .overlay(alignment: .topTrailing) {
                                PulseLogo(size: 30, ringColor: PulseColor.sage, waveColor: PulseColor.ivory)
                                    .padding(16)
                                    .opacity(0.8)
                            }
                            .clipShape(
                                UnevenRoundedRectangle(
                                    topLeadingRadius: PulseMetrics.cardRadius,
                                    bottomLeadingRadius: 0,
                                    bottomTrailingRadius: 0,
                                    topTrailingRadius: PulseMetrics.cardRadius,
                                    style: .continuous
                                )
                            )
                        }

                        VStack(alignment: .leading, spacing: 14) {
                            HStack(spacing: 16) {
                                Label("\(recommended.estimatedMinutes) min", systemImage: "clock")
                                Label("\(recommended.exercises.count) exercises", systemImage: "list.bullet")
                            }
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)

                            HStack(spacing: 10) {
                                Button {
                                    onStart(recommended)
                                } label: {
                                    Label("Start workout", systemImage: "play.fill")
                                }
                                .buttonStyle(.pulsePrimary)

                                Button("Browse", action: onBrowse)
                                    .buttonStyle(PulseSecondaryButtonStyle(fullWidth: false))
                                    .layoutPriority(1)
                            }
                        }
                        .padding(.horizontal, 18)
                        .padding(.bottom, 18)
                    }
                }
            } else {
                PulseCard {
                    PulseEmptyState(
                        symbol: "dumbbell",
                        title: "Build your library",
                        message: "Create a routine or pick a plan and your next session will appear here.",
                        actionTitle: "Browse training",
                        action: onBrowse,
                        compact: true
                    )
                }
            }
        }
    }
}

// MARK: - Weekly rhythm

private struct WeeklyRhythmCard: View {
    let metrics: [DailyHealthMetric]
    let units: UnitSystem
    let isLoading: Bool
    let onOpenInsights: () -> Void

    private var totalSteps: Double {
        metrics.reduce(0) { $0 + $1.steps }
    }

    private var totalExercise: Double {
        metrics.reduce(0) { $0 + $1.exerciseMinutes }
    }

    private var maxSteps: Double {
        max(metrics.map(\.steps).max() ?? 0, 1)
    }

    var body: some View {
        PulseCard {
            VStack(alignment: .leading, spacing: 18) {
                PulseSectionHeader(
                    "This week",
                    overline: "Movement",
                    actionTitle: "Insights",
                    action: onOpenInsights
                )

                if isLoading {
                    PulseLoadingLabel(text: "Reading Apple Health")
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.vertical, 30)
                } else if metrics.isEmpty {
                    PulseEmptyState(
                        symbol: "chart.bar",
                        title: "No movement recorded",
                        message: "Once Apple Health has data, your weekly rhythm appears here.",
                        compact: true
                    )
                } else {
                    HStack(alignment: .bottom, spacing: 8) {
                        ForEach(metrics) { metric in
                            VStack(spacing: 8) {
                                Capsule()
                                    .fill(
                                        PulseDate.isToday(metric.date)
                                            ? PulseColor.accent
                                            : PulseColor.accent.opacity(0.28)
                                    )
                                    .frame(height: barHeight(for: metric))
                                    .frame(maxWidth: .infinity)
                                    .overlay(alignment: .top) {
                                        if PulseDate.isToday(metric.date) {
                                            Circle()
                                                .fill(PulseColor.accent)
                                                .frame(width: 4, height: 4)
                                                .offset(y: -6)
                                        }
                                    }

                                Text(PulseDate.compactWeekday(metric.date))
                                    .font(PulseFont.caption)
                                    .foregroundStyle(
                                        PulseDate.isToday(metric.date)
                                            ? PulseColor.textPrimary
                                            : PulseColor.textTertiary
                                    )
                            }
                            .accessibilityElement(children: .ignore)
                            .accessibilityLabel(PulseDate.shortWeekday(metric.date))
                            .accessibilityValue("\(UnitFormatter.steps(metric.steps)) steps")
                        }
                    }
                    .frame(height: 100, alignment: .bottom)

                    HStack(spacing: 0) {
                        PulseMiniStat(value: UnitFormatter.steps(totalSteps), label: "Steps this week")
                        Divider().frame(height: 28).overlay(PulseColor.hairline)
                            .padding(.horizontal, 16)
                        PulseMiniStat(
                            value: "\(UnitFormatter.exerciseMinutes(totalExercise)) min",
                            label: "Active minutes"
                        )
                    }
                }
            }
        }
    }

    private func barHeight(for metric: DailyHealthMetric) -> CGFloat {
        let fraction = metric.steps / maxSteps
        return max(6, CGFloat(fraction) * 74)
    }
}

// MARK: - Insight

private struct InsightCard: View {
    let insight: CoachInsight

    private var tint: Color {
        switch insight.tone {
        case .positive: PulseColor.accent
        case .neutral: PulseColor.ringStand
        case .attention: PulseColor.warning
        }
    }

    var body: some View {
        PulseCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 10) {
                    Image(systemName: insight.symbol)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(tint)
                        .frame(width: 32, height: 32)
                        .background(tint.opacity(0.13), in: Circle())
                    Text("Daily insight")
                        .pulseOverline()
                        .foregroundStyle(PulseColor.textTertiary)
                    Spacer()
                    PulsePillBadge(text: "PULSE", tint: tint)
                }

                Text(insight.title)
                    .font(PulseFont.headline)
                    .foregroundStyle(PulseColor.textPrimary)

                Text(insight.message)
                    .font(PulseFont.callout)
                    .foregroundStyle(PulseColor.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

// MARK: - Health permission states

private struct HealthConnectionCard: View {
    let isConnecting: Bool
    let action: () -> Void

    var body: some View {
        PulseCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 10) {
                    PulseIconTile(symbol: "heart.text.square.fill", tint: PulseColor.danger, size: 38)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Bring your rhythm together")
                            .font(PulseFont.headline)
                            .foregroundStyle(PulseColor.textPrimary)
                        Text("PULSE reads steps, energy and workouts from Apple Health. Your data stays on this device.")
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }

                HStack(spacing: 10) {
                    Button(action: action) {
                        if isConnecting {
                            HStack(spacing: 8) {
                                ProgressView().controlSize(.small).tint(PulseColor.midnight)
                                Text("Connecting")
                            }
                        } else {
                            Text("Connect Apple Health")
                        }
                    }
                    .buttonStyle(PulseSecondaryButtonStyle(fullWidth: false))
                    .disabled(isConnecting)
                }
            }
        }
    }
}

private struct HealthEmptyCard: View {
    let onRefresh: () -> Void

    var body: some View {
        PulseCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 10) {
                    PulseIconTile(symbol: "heart.slash", tint: PulseColor.warning, size: 38)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("No Health data yet")
                            .font(PulseFont.headline)
                            .foregroundStyle(PulseColor.textPrimary)
                        Text("Health access may be limited, or this device has no recent samples. You can review permissions in Settings.")
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }

                HStack(spacing: 10) {
                    Button("Refresh", action: onRefresh)
                        .buttonStyle(PulseSecondaryButtonStyle(fullWidth: false))

                    Link(destination: URL(string: UIApplication.openSettingsURLString)!) {
                        Text("Open Settings")
                            .font(PulseFont.footnote.weight(.semibold))
                            .foregroundStyle(PulseColor.accent)
                            .padding(.vertical, 10)
                    }
                }
            }
        }
    }
}
