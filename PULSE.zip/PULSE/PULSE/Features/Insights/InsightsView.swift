import SwiftUI
import SwiftData
import Charts

private enum ActivityMetric: String, CaseIterable, Identifiable {
    case steps
    case energy
    case minutes

    var id: String { rawValue }

    var label: String {
        switch self {
        case .steps: "Steps"
        case .energy: "Energy"
        case .minutes: "Minutes"
        }
    }

    var unit: String {
        switch self {
        case .steps: "steps"
        case .energy: "kcal"
        case .minutes: "min"
        }
    }

    func value(from metric: DailyHealthMetric) -> Double {
        switch self {
        case .steps: metric.steps
        case .energy: metric.activeEnergy
        case .minutes: metric.exerciseMinutes
        }
    }
}

struct InsightsView: View {
    @Environment(AppState.self) private var app
    @Query(sort: \WorkoutSession.startedAt, order: .reverse) private var sessions: [WorkoutSession]
    @Query(sort: \WeightEntry.date, order: .forward) private var weights: [WeightEntry]

    let profile: UserProfile

    @State private var range: InsightRange = .week
    @State private var activityMetric: ActivityMetric = .steps
    @State private var showLogWeight = false
    @State private var selectedStrengthID: String = ""

    private var provider: HealthDataProvider {
        HealthDataProvider(profile: profile, health: app.health)
    }

    private var completedSessions: [WorkoutSession] {
        WorkoutAnalytics.completed(sessions)
    }

    private var stats: WorkoutStats {
        WorkoutAnalytics.stats(sessions)
    }

    private var records: [PersonalRecord] {
        WorkoutAnalytics.personalRecords(from: sessions)
    }

    private var strengthOptions: [PersonalRecord] {
        records
    }

    private var effectiveStrengthID: String {
        if records.contains(where: { $0.exerciseID == selectedStrengthID }) {
            return selectedStrengthID
        }
        return records.first?.exerciseID ?? ""
    }

    private var strengthPoints: [StrengthPoint] {
        guard !effectiveStrengthID.isEmpty else { return [] }
        return WorkoutAnalytics.strengthProgression(exerciseID: effectiveStrengthID, sessions: sessions)
    }

    private var strengthName: String {
        records.first(where: { $0.exerciseID == effectiveStrengthID })?.exerciseName ?? "Exercise"
    }

    private var recentWeights: [WeightEntry] {
        let cutoff = PulseDate.date(.now, addingDays: -90)
        return weights.filter { $0.date >= cutoff }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                PulsePageTitle(
                    "Insights",
                    eyebrow: "Patterns",
                    subtitle: "What your training is telling you, one signal at a time."
                )

                if profile.usesPreviewData {
                    PreviewDataBanner(compact: true)
                }

                PulseSegmentedControl(
                    items: InsightRange.allCases,
                    label: \.label,
                    selection: $range
                )

                activitySection
                consistencySection
                weightSection
                strengthSection
                frequencySection
                recordsSection
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 8)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .toolbar(.hidden, for: .navigationBar)
        .sheet(isPresented: $showLogWeight) {
            LogWeightSheet(profile: profile) {
                app.showToast("Weight logged")
            }
        }
    }

    // MARK: - Activity

    private var activitySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            PulseSectionHeader("Activity", overline: "Movement trend")

            PulseCard {
                VStack(alignment: .leading, spacing: 16) {
                    if range == .day {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Steps by hour")
                                    .font(PulseFont.headline)
                                    .foregroundStyle(PulseColor.textPrimary)
                                Text("Today · \(UnitFormatter.steps(provider.today.steps)) total")
                                    .font(PulseFont.caption)
                                    .foregroundStyle(PulseColor.textTertiary)
                            }
                            Spacer()
                            Image(systemName: "chart.bar.xaxis")
                                .foregroundStyle(PulseColor.accent)
                        }

                        if provider.hourlySteps.isEmpty {
                            activityEmptyState
                        } else {
                            Chart(provider.hourlySteps) { hour in
                                BarMark(
                                    x: .value("Hour", hour.hour, unit: .hour),
                                    y: .value("Steps", hour.steps)
                                )
                                .foregroundStyle(PulseColor.accent.gradient)
                                .cornerRadius(3)
                            }
                            .chartXAxis {
                                AxisMarks(values: .stride(by: .hour, count: 4)) { _ in
                                    AxisGridLine().foregroundStyle(PulseColor.hairline)
                                    AxisValueLabel(format: .dateTime.hour(.defaultDigits(amPM: .narrow)))
                                        .foregroundStyle(PulseColor.textTertiary)
                                }
                            }
                            .chartYAxis {
                                AxisMarks(position: .leading, values: .automatic(desiredCount: 4)) { value in
                                    AxisValueLabel {
                                        if let number = value.as(Double.self) {
                                            Text(compact(number))
                                                .font(PulseFont.caption)
                                                .foregroundStyle(PulseColor.textTertiary)
                                        }
                                    }
                                }
                            }
                            .frame(height: 170)
                        }

                        HStack(spacing: 0) {
                            miniStat(value: "\(UnitFormatter.exerciseMinutes(provider.today.exerciseMinutes))", label: "Exercise min")
                            Spacer()
                            miniStat(value: UnitFormatter.energy(provider.today.activeEnergy), label: "Active kcal")
                            Spacer()
                            miniStat(value: "\(Int(provider.today.standHours))", label: "Stand hours")
                        }
                        .padding(.top, 2)
                    } else {
                        let metrics = provider.dailyMetrics(days: range.days)

                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(metrics.isEmpty ? "No activity yet" : "\(activityMetric.label) by day")
                                    .font(PulseFont.headline)
                                    .foregroundStyle(PulseColor.textPrimary)
                                if !metrics.isEmpty {
                                    Text(activitySummary(metrics))
                                        .font(PulseFont.caption)
                                        .foregroundStyle(PulseColor.textTertiary)
                                }
                            }
                            Spacer()
                        }

                        PulseSegmentedControl(
                            items: ActivityMetric.allCases,
                            label: \.label,
                            selection: $activityMetric
                        )

                        if metrics.isEmpty {
                            activityEmptyState
                        } else {
                            Chart(metrics) { metric in
                                BarMark(
                                    x: .value("Day", metric.date, unit: .day),
                                    y: .value(activityMetric.label, activityMetric.value(from: metric))
                                )
                                .foregroundStyle(barColor(for: metric).gradient)
                                .cornerRadius(4)
                            }
                            .chartXAxis {
                                AxisMarks(values: .stride(by: .day, count: range == .month ? 7 : 1)) { _ in
                                    AxisGridLine().foregroundStyle(PulseColor.hairline)
                                    AxisValueLabel(format: .dateTime.weekday(.narrow))
                                        .foregroundStyle(PulseColor.textTertiary)
                                }
                            }
                            .chartYAxis {
                                AxisMarks(position: .leading, values: .automatic(desiredCount: 4)) { value in
                                    AxisValueLabel {
                                        if let number = value.as(Double.self) {
                                            Text(compact(number))
                                                .font(PulseFont.caption)
                                                .foregroundStyle(PulseColor.textTertiary)
                                        }
                                    }
                                }
                            }
                            .frame(height: 180)
                        }
                    }
                }
            }
        }
    }

    private var activityEmptyState: some View {
        VStack(spacing: 12) {
            PulseEmptyState(
                symbol: "heart.text.square",
                title: "Movement needs a source",
                message: "Connect Apple Health or switch on preview data in You to see activity trends.",
                actionTitle: "Open settings",
                action: { app.selectedTab = .you },
                compact: true
            )
        }
    }

    private func barColor(for metric: DailyHealthMetric) -> Color {
        PulseDate.isToday(metric.date) ? PulseColor.accent : PulseColor.accent.opacity(0.55)
    }

    private func activitySummary(_ metrics: [DailyHealthMetric]) -> String {
        let total = metrics.reduce(0) { $0 + activityMetric.value(from: $1) }
        let average = total / Double(max(metrics.count, 1))
        return "\(compact(total)) total · \(compact(average)) daily average"
    }

    // MARK: - Consistency

    private var consistencySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            PulseSectionHeader("Consistency", overline: "Last 5 weeks")

            PulseCard {
                VStack(alignment: .leading, spacing: 14) {
                    HStack(spacing: 16) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(stats.currentStreak)")
                                .font(PulseFont.number(28, weight: .semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                            Text("day streak")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }

                        Divider().frame(height: 32).overlay(PulseColor.hairline)

                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(stats.longestStreak)")
                                .font(PulseFont.number(28, weight: .semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                            Text("longest streak")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }

                        Spacer()

                        VStack(alignment: .trailing, spacing: 2) {
                            Text("\(stats.workoutsThisWeek)")
                                .font(PulseFont.number(20, weight: .semibold))
                                .foregroundStyle(PulseColor.accent)
                            Text("this week")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                    }

                    consistencyGrid
                }
            }
        }
    }

    private var consistencyGrid: some View {
        let days = consistencyDays()
        let counts = WorkoutAnalytics.activityDays(sessions)
        let columns = Array(repeating: GridItem(.flexible(), spacing: 5), count: 7)

        return VStack(spacing: 6) {
            HStack(spacing: 5) {
                ForEach(["M", "T", "W", "T", "F", "S", "S"], id: \.self) { label in
                    Text(label)
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(PulseColor.textTertiary)
                        .frame(maxWidth: .infinity)
                }
            }

            LazyVGrid(columns: columns, spacing: 5) {
                ForEach(days, id: \.self) { day in
                    let count = counts[PulseDate.startOfDay(day)] ?? 0
                    RoundedRectangle(cornerRadius: 5, style: .continuous)
                        .fill(cellColor(count: count, day: day))
                        .frame(height: 29)
                        .accessibilityLabel(PulseDate.mediumDate(day))
                        .accessibilityValue(count == 0 ? "Rest day" : "\(count) workout\(count == 1 ? "" : "s")")
                }
            }
        }
    }

    private func consistencyDays() -> [Date] {
        let calendar = PulseDate.calendar
        let today = PulseDate.startOfDay()
        let weekday = calendar.component(.weekday, from: today)
        let mondayIndex = (weekday + 5) % 7
        guard let start = calendar.date(byAdding: .day, value: -(mondayIndex + 28), to: today) else {
            return PulseDate.days(endingAt: .now, count: 35)
        }
        return (0..<35).compactMap { calendar.date(byAdding: .day, value: $0, to: start) }
    }

    private func cellColor(count: Int, day: Date) -> Color {
        if day > PulseDate.startOfDay() {
            return PulseColor.surfaceMuted.opacity(0.35)
        }
        switch count {
        case 0: return PulseColor.surfaceMuted
        case 1: return PulseColor.accent.opacity(0.35)
        case 2: return PulseColor.accent.opacity(0.62)
        default: return PulseColor.accent
        }
    }

    // MARK: - Weight

    private var weightSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            PulseSectionHeader(
                "Weight",
                overline: "Body trend",
                actionTitle: "Log",
                action: { showLogWeight = true }
            )

            PulseCard {
                VStack(alignment: .leading, spacing: 14) {
                    if let latest = recentWeights.last {
                        HStack(alignment: .firstTextBaseline, spacing: 8) {
                            Text(UnitFormatter.weight(kg: latest.weightKg, units: profile.unitSystem))
                                .font(PulseFont.number(30, weight: .semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                            if let change = weightChange {
                                PulsePillBadge(
                                    text: change,
                                    symbol: change.hasPrefix("-") ? "arrow.down.right" : "arrow.up.right",
                                    tint: change.hasPrefix("-") ? PulseColor.accent : PulseColor.warning
                                )
                            }
                            Spacer()
                            Text("BMI \(UnitFormatter.decimal(profile.bmi, places: 1)) · \(profile.bmiLabel)")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }

                        if recentWeights.count > 1 {
                            Chart(recentWeights) { entry in
                                AreaMark(
                                    x: .value("Date", entry.date),
                                    y: .value("Weight", UnitFormatter.weightValue(kg: entry.weightKg, units: profile.unitSystem))
                                )
                                .foregroundStyle(
                                    LinearGradient(
                                        colors: [PulseColor.accent.opacity(0.24), PulseColor.accent.opacity(0)],
                                        startPoint: .top,
                                        endPoint: .bottom
                                    )
                                )

                                LineMark(
                                    x: .value("Date", entry.date),
                                    y: .value("Weight", UnitFormatter.weightValue(kg: entry.weightKg, units: profile.unitSystem))
                                )
                                .foregroundStyle(PulseColor.accent)
                                .lineStyle(StrokeStyle(lineWidth: 2.5, lineCap: .round))
                                .interpolationMethod(.catmullRom)

                                PointMark(
                                    x: .value("Date", entry.date),
                                    y: .value("Weight", UnitFormatter.weightValue(kg: entry.weightKg, units: profile.unitSystem))
                                )
                                .foregroundStyle(PulseColor.accent)
                                .symbolSize(18)
                            }
                            .chartXAxis {
                                AxisMarks(values: .automatic(desiredCount: 3)) { _ in
                                    AxisGridLine().foregroundStyle(PulseColor.hairline)
                                    AxisValueLabel(format: .dateTime.month(.abbreviated).day())
                                        .foregroundStyle(PulseColor.textTertiary)
                                }
                            }
                            .chartYAxis {
                                AxisMarks(position: .leading, values: .automatic(desiredCount: 3)) { value in
                                    AxisValueLabel {
                                        if let number = value.as(Double.self) {
                                            Text(UnitFormatter.decimal(number, places: 1))
                                                .font(PulseFont.caption)
                                                .foregroundStyle(PulseColor.textTertiary)
                                        }
                                    }
                                }
                            }
                            .chartYScale(domain: weightDomain)
                            .frame(height: 160)
                        } else {
                            Text("Log again in a few days to see your trend line.")
                                .font(PulseFont.footnote)
                                .foregroundStyle(PulseColor.textSecondary)
                        }
                    } else {
                        PulseEmptyState(
                            symbol: "scalemass",
                            title: "No weight history",
                            message: "Log your weight to see how it moves alongside your training.",
                            actionTitle: "Log weight",
                            action: { showLogWeight = true },
                            compact: true
                        )
                    }
                }
            }
        }
    }

    private var weightChange: String? {
        guard let first = recentWeights.first, let last = recentWeights.last, recentWeights.count > 1 else {
            return nil
        }
        let delta = UnitFormatter.weightValue(kg: last.weightKg - first.weightKg, units: profile.unitSystem)
        guard abs(delta) >= 0.05 else { return "Steady" }
        let sign = delta < 0 ? "−" : "+"
        return "\(sign)\(UnitFormatter.decimal(abs(delta), places: 1)) \(profile.unitSystem.weightUnit)"
    }

    private var weightDomain: ClosedRange<Double> {
        let values = recentWeights.map {
            UnitFormatter.weightValue(kg: $0.weightKg, units: profile.unitSystem)
        }
        guard let low = values.min(), let high = values.max() else { return 60...80 }
        let padding = max((high - low) * 0.22, 0.8)
        return (low - padding)...(high + padding)
    }

    // MARK: - Strength

    private var strengthSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            PulseSectionHeader("Strength", overline: "Progression")

            PulseCard {
                VStack(alignment: .leading, spacing: 14) {
                    if records.isEmpty {
                        PulseEmptyState(
                            symbol: "dumbbell",
                            title: "No strength data yet",
                            message: "Complete a weighted strength session to start tracking your progression.",
                            compact: true
                        )
                    } else {
                        Menu {
                            ForEach(records) { record in
                                Button {
                                    selectedStrengthID = record.exerciseID
                                } label: {
                                    if record.exerciseID == effectiveStrengthID {
                                        Label(record.exerciseName, systemImage: "checkmark")
                                    } else {
                                        Text(record.exerciseName)
                                    }
                                }
                            }
                        } label: {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(strengthName)
                                        .font(PulseFont.headline)
                                        .foregroundStyle(PulseColor.textPrimary)
                                    Text("\(strengthPoints.count) logged sessions")
                                        .font(PulseFont.caption)
                                        .foregroundStyle(PulseColor.textTertiary)
                                }
                                Spacer()
                                HStack(spacing: 4) {
                                    Text("Change")
                                        .font(PulseFont.caption)
                                    Image(systemName: "chevron.up.chevron.down")
                                        .font(.system(size: 9, weight: .semibold))
                                }
                                .foregroundStyle(PulseColor.accent)
                            }
                        }

                        if strengthPoints.count >= 2 {
                            Chart(strengthPoints) { point in
                                LineMark(
                                    x: .value("Date", point.date),
                                    y: .value("Weight", UnitFormatter.weightValue(kg: point.weightKg, units: profile.unitSystem))
                                )
                                .foregroundStyle(PulseColor.chartSecondary)
                                .lineStyle(StrokeStyle(lineWidth: 2.5, lineCap: .round))
                                .interpolationMethod(.catmullRom)

                                PointMark(
                                    x: .value("Date", point.date),
                                    y: .value("Weight", UnitFormatter.weightValue(kg: point.weightKg, units: profile.unitSystem))
                                )
                                .foregroundStyle(PulseColor.chartSecondary)
                                .symbolSize(26)
                            }
                            .chartXAxis {
                                AxisMarks(values: .automatic(desiredCount: 3)) { _ in
                                    AxisGridLine().foregroundStyle(PulseColor.hairline)
                                    AxisValueLabel(format: .dateTime.month(.abbreviated).day())
                                        .foregroundStyle(PulseColor.textTertiary)
                                }
                            }
                            .chartYAxis {
                                AxisMarks(position: .leading, values: .automatic(desiredCount: 3)) { value in
                                    AxisValueLabel {
                                        if let number = value.as(Double.self) {
                                            Text(UnitFormatter.decimal(number, places: 1))
                                                .font(PulseFont.caption)
                                                .foregroundStyle(PulseColor.textTertiary)
                                        }
                                    }
                                }
                            }
                            .frame(height: 150)

                            if let first = strengthPoints.first, let last = strengthPoints.last {
                                let delta = UnitFormatter.weightValue(
                                    kg: last.weightKg - first.weightKg,
                                    units: profile.unitSystem
                                )
                                HStack(spacing: 5) {
                                    Image(systemName: delta >= 0 ? "arrow.up.right" : "arrow.down.right")
                                    Text(
                                        delta >= 0
                                            ? "\(UnitFormatter.decimal(abs(delta), places: 1)) \(profile.unitSystem.weightUnit) added since \(PulseDate.mediumDate(first.date))"
                                            : "\(UnitFormatter.decimal(abs(delta), places: 1)) \(profile.unitSystem.weightUnit) change since \(PulseDate.mediumDate(first.date))"
                                    )
                                    .font(PulseFont.caption)
                                }
                                .foregroundStyle(delta >= 0 ? PulseColor.accent : PulseColor.textSecondary)
                            }
                        } else {
                            Text("Two or more logged sessions reveal a trend for this exercise.")
                                .font(PulseFont.footnote)
                                .foregroundStyle(PulseColor.textSecondary)
                        }
                    }
                }
            }
        }
    }

    // MARK: - Frequency

    private var frequencySection: some View {
        let frequency = WorkoutAnalytics.exerciseFrequency(sessions: sessions, limit: 6)

        return VStack(alignment: .leading, spacing: 12) {
            PulseSectionHeader("Exercise frequency", overline: "Last 90 days")

            PulseCard {
                if frequency.isEmpty {
                    PulseEmptyState(
                        symbol: "chart.bar.doc.horizontal",
                        title: "No exercise history",
                        message: "Frequency appears after your first completed strength session.",
                        compact: true
                    )
                } else {
                    Chart(frequency) { item in
                        BarMark(
                            x: .value("Sessions", item.sessions),
                            y: .value("Exercise", item.name)
                        )
                        .foregroundStyle(PulseColor.accent.opacity(0.85).gradient)
                        .cornerRadius(4)
                        .annotation(position: .trailing, alignment: .leading) {
                            Text("\(item.sessions)")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                    }
                    .chartXAxis(.hidden)
                    .chartYAxis {
                        AxisMarks(position: .leading) { _ in
                            AxisValueLabel()
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textSecondary)
                        }
                    }
                    .chartXScale(domain: 0...(frequency.map(\.sessions).max() ?? 1) + 2)
                    .frame(height: CGFloat(frequency.count) * 34 + 16)
                }
            }
        }
    }

    // MARK: - Records

    private var recordsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            PulseSectionHeader("Personal records", overline: "All time")

            if records.isEmpty {
                PulseCard {
                    PulseEmptyState(
                        symbol: "trophy",
                        title: "No records yet",
                        message: "Log a weighted set and your strongest lifts will collect here.",
                        compact: true
                    )
                }
            } else {
                PulseCard(padding: 6) {
                    VStack(spacing: 0) {
                        ForEach(Array(records.prefix(6).enumerated()), id: \.element.id) { index, record in
                            HStack(spacing: 12) {
                                Text("\(index + 1)")
                                    .font(PulseFont.number(12, weight: .semibold))
                                    .foregroundStyle(index == 0 ? PulseColor.warning : PulseColor.textTertiary)
                                    .frame(width: 22)

                                VStack(alignment: .leading, spacing: 2) {
                                    Text(record.exerciseName)
                                        .font(PulseFont.callout.weight(.medium))
                                        .foregroundStyle(PulseColor.textPrimary)
                                    Text(PulseDate.mediumDate(record.date))
                                        .font(PulseFont.caption)
                                        .foregroundStyle(PulseColor.textTertiary)
                                }

                                Spacer()

                                Text("\(UnitFormatter.weight(kg: record.weightKg, units: profile.unitSystem)) × \(record.reps)")
                                    .font(PulseFont.footnote.weight(.semibold))
                                    .foregroundStyle(PulseColor.textSecondary)
                            }
                            .padding(12)

                            if index < min(records.count, 6) - 1 {
                                PulseDivider().padding(.leading, 46)
                            }
                        }
                    }
                }
            }
        }
    }

    private func miniStat(value: String, label: String) -> some View {
        VStack(spacing: 3) {
            Text(value)
                .font(PulseFont.number(16, weight: .semibold))
                .foregroundStyle(PulseColor.textPrimary)
            Text(label)
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)
        }
        .frame(maxWidth: .infinity)
    }

    private func compact(_ value: Double) -> String {
        if value >= 10_000 {
            return "\(UnitFormatter.decimal(value / 1_000, places: 0))k"
        }
        return UnitFormatter.integer(value)
    }
}

// MARK: - Log weight

struct LogWeightSheet: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    let profile: UserProfile
    let onSave: () -> Void

    @State private var displayWeight: Double

    init(profile: UserProfile, onSave: @escaping () -> Void) {
        self.profile = profile
        self.onSave = onSave
        _displayWeight = State(
            initialValue: UnitFormatter.weightValue(kg: profile.weightKg, units: profile.unitSystem)
        )
    }

    private var range: ClosedRange<Double> {
        profile.unitSystem == .metric ? 35...200 : 77...440
    }

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 22) {
                PulseSheetHeader(
                    title: "Log weight",
                    subtitle: "Use the same scale and time of day for the cleanest trend."
                )

                VStack(spacing: 16) {
                    HStack(alignment: .firstTextBaseline, spacing: 4) {
                        Text(UnitFormatter.decimal(displayWeight, places: 1))
                            .font(PulseFont.number(46, weight: .semibold))
                            .foregroundStyle(PulseColor.textPrimary)
                            .contentTransition(.numericText())
                        Text(profile.unitSystem.weightUnit)
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textTertiary)
                    }

                    Slider(value: $displayWeight, in: range, step: 0.1)
                        .tint(PulseColor.accent)
                        .accessibilityLabel("Weight")
                        .accessibilityValue("\(UnitFormatter.decimal(displayWeight, places: 1)) \(profile.unitSystem.weightUnit)")

                    HStack {
                        Text("\(Int(range.lowerBound)) \(profile.unitSystem.weightUnit)")
                        Spacer()
                        Text("\(Int(range.upperBound)) \(profile.unitSystem.weightUnit)")
                    }
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)

                    Text("Your daily targets are recalculated from your new weight. You can review them in You.")
                        .font(PulseFont.footnote)
                        .foregroundStyle(PulseColor.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.horizontal, PulseMetrics.screenPadding)

                Spacer(minLength: 0)

                Button("Save weight") {
                    save()
                }
                .buttonStyle(.pulsePrimary)
                .padding(.horizontal, PulseMetrics.screenPadding)
                .padding(.bottom, 16)
            }
            .background(PulseColor.background)
            .presentationDetents([.medium])
            .presentationDragIndicator(.visible)
        }
    }

    private func save() {
        let kg = UnitFormatter.kilograms(from: displayWeight, units: profile.unitSystem)
        let entry = WeightEntry(date: .now, weightKg: kg)
        context.insert(entry)
        profile.weightKg = kg
        profile.recalculateTargets()
        try? context.save()
        Haptics.success()
        onSave()
        dismiss()
    }
}
