import SwiftUI
import SwiftData

struct OnboardingFlowView: View {
    @Environment(\.modelContext) private var context
    @Environment(AppState.self) private var appState
    let existingProfile: UserProfile?

    @State private var step: OnboardingStep = .welcome
    @State private var isMovingForward = true
    @State private var draft = OnboardingDraft()
    @State private var isConnectingHealth = false
    @State private var isSaving = false

    init(profile: UserProfile? = nil) {
        self.existingProfile = profile
    }

    private var canContinue: Bool {
        switch step {
        case .welcome, .units, .health:
            return true
        case .profile:
            return draft.name.trimmingCharacters(in: .whitespacesAndNewlines).count >= 2
        case .level:
            return draft.level != nil
        case .goal:
            return draft.goal != nil
        case .activities:
            return !draft.activities.isEmpty
        }
    }

    private var actionTitle: String {
        switch step {
        case .welcome: "Begin"
        case .health: "Connect Apple Health"
        default: "Continue"
        }
    }

    var body: some View {
        ZStack {
            OnboardingBackground()

            VStack(spacing: 0) {
                if step != .welcome {
                    header
                }

                ScrollView {
                    stepContent
                        .id(step)
                        .transition(
                            .asymmetric(
                                insertion: .opacity.combined(with: .move(edge: isMovingForward ? .trailing : .leading)),
                                removal: .opacity.combined(with: .move(edge: isMovingForward ? .leading : .trailing))
                            )
                        )
                        .padding(.horizontal, 24)
                        .padding(.top, step == .welcome ? 12 : 20)
                        .padding(.bottom, 28)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .scrollIndicators(.hidden)
                .scrollDismissesKeyboard(.interactively)

                footer
            }
        }
        .preferredColorScheme(.dark)
        .tint(PulseColor.sage)
        .onAppear {
            if let profile = existingProfile {
                draft.name = profile.name
                draft.age = profile.age
                draft.heightCm = profile.heightCm
                draft.weightKg = profile.weightKg
                draft.level = profile.level
                draft.goal = profile.goal
                draft.activities = Set(profile.activities)
                draft.unitSystem = profile.unitSystem
            }
        }
    }

    // MARK: - Header

    private var header: some View {
        VStack(spacing: 16) {
            HStack {
                Button {
                    goBack()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(PulseColor.ivory)
                        .frame(width: 38, height: 38)
                        .background(Color.white.opacity(0.06), in: Circle())
                        .overlay(Circle().strokeBorder(Color.white.opacity(0.08), lineWidth: 1))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Back")

                Spacer()

                HStack(spacing: 7) {
                    PulseLogo(size: 18, ringColor: PulseColor.sage, waveColor: PulseColor.ivory)
                    Text("PULSE")
                        .font(.system(size: 12, weight: .semibold))
                        .tracking(3)
                        .foregroundStyle(PulseColor.ivory)
                }

                Spacer()

                Text("\(String(format: "%02d", step.rawValue)) / 06")
                    .font(PulseFont.caption.monospacedDigit())
                    .foregroundStyle(PulseColor.ivory.opacity(0.45))
                    .frame(width: 54, alignment: .trailing)
            }

            HStack(spacing: 5) {
                ForEach(1...6, id: \.self) { index in
                    Capsule()
                        .fill(index <= step.rawValue ? PulseColor.sage : Color.white.opacity(0.10))
                        .frame(height: 3)
                }
            }
        }
        .padding(.horizontal, 24)
        .padding(.top, 8)
        .padding(.bottom, 4)
    }

    // MARK: - Steps

    @ViewBuilder
    private var stepContent: some View {
        switch step {
        case .welcome: welcomeStep
        case .units: unitsStep
        case .profile: profileStep
        case .level: levelStep
        case .goal: goalStep
        case .activities: activitiesStep
        case .health: healthStep
        }
    }

    private var welcomeStep: some View {
        VStack(alignment: .leading, spacing: 0) {
            ZStack {
                Circle()
                    .stroke(PulseColor.ivory.opacity(0.06), lineWidth: 1)
                    .frame(width: 330, height: 330)
                Circle()
                    .trim(from: 0.08, to: 0.82)
                    .stroke(PulseColor.sage.opacity(0.35), style: StrokeStyle(lineWidth: 1.5, lineCap: .round))
                    .rotationEffect(.degrees(120))
                    .frame(width: 290, height: 290)
                Circle()
                    .fill(RadialGradient(colors: [PulseColor.sage.opacity(0.22), .clear], center: .center, startRadius: 0, endRadius: 170))
                    .frame(width: 340, height: 340)
                PulseLogo(size: 128, ringColor: PulseColor.sage, waveColor: PulseColor.ivory)
                    .shadow(color: PulseColor.sage.opacity(0.25), radius: 30)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 330)
            .padding(.top, 10)
            .accessibilityHidden(true)

            VStack(alignment: .leading, spacing: 18) {
                Text("Your health.\nYour rhythm.\nYour progress.")
                    .font(.system(size: 40, weight: .semibold, design: .default))
                    .tracking(-0.8)
                    .lineSpacing(1)
                    .foregroundStyle(PulseColor.ivory)
                    .fixedSize(horizontal: false, vertical: true)

                Text("One considered space for training, everyday movement, nutrition and recovery.")
                    .font(PulseFont.body)
                    .foregroundStyle(PulseColor.ivory.opacity(0.62))
                    .lineSpacing(3)
                    .fixedSize(horizontal: false, vertical: true)

                HStack(spacing: 10) {
                    welcomeTag("figure.strengthtraining.traditional", "TRAIN")
                    welcomeTag("fork.knife", "FUEL")
                    welcomeTag("waveform.path.ecg", "RECOVER")
                }
                .padding(.top, 4)

                HStack(spacing: 8) {
                    Image(systemName: "applewatch")
                    Image(systemName: "iphone")
                    Text("Designed for iPhone and Apple Watch")
                }
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.sage.opacity(0.8))
                .padding(.top, 10)
            }
        }
    }

    private func welcomeTag(_ symbol: String, _ label: String) -> some View {
        HStack(spacing: 6) {
            Image(systemName: symbol)
                .font(.system(size: 10, weight: .semibold))
            Text(label)
                .font(.system(size: 10, weight: .semibold))
                .tracking(1.1)
        }
        .foregroundStyle(PulseColor.ivory.opacity(0.7))
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.white.opacity(0.05), in: Capsule())
        .overlay(Capsule().strokeBorder(Color.white.opacity(0.08), lineWidth: 1))
    }

    private var unitsStep: some View {
        VStack(alignment: .leading, spacing: 26) {
            StepTitle(
                eyebrow: "Preferences",
                title: "Choose your units.",
                subtitle: "You can change this at any time in your profile."
            )

            VStack(spacing: 12) {
                ForEach(UnitSystem.allCases) { system in
                    SelectionCard(
                        symbol: system == .metric ? "ruler" : "ruler.fill",
                        title: system.label,
                        detail: system.detail,
                        footnote: system == .metric ? "178 cm · 72.4 kg · 5.2 km" : "5′ 10″ · 159.6 lb · 3.2 mi",
                        isSelected: draft.unitSystem == system
                    ) {
                        draft.unitSystem = system
                        Haptics.selection()
                    }
                }
            }
        }
    }

    private var profileStep: some View {
        VStack(alignment: .leading, spacing: 26) {
            StepTitle(
                eyebrow: "About you",
                title: "Let's set your baseline.",
                subtitle: "These details shape your energy, protein and hydration targets. They stay on this device."
            )

            PulseField(
                title: "Name",
                placeholder: "How should we greet you?",
                text: $draft.name,
                capitalization: .words,
                hint: "At least two characters."
            )

            PulseCounter(
                title: "Age",
                value: $draft.age,
                range: 13...100,
                step: 1,
                unit: "years"
            )

            PulseValueSlider(
                title: "Height",
                valueText: UnitFormatter.height(cm: draft.heightCm, units: draft.unitSystem),
                value: $draft.heightCm,
                range: 120...220,
                step: 1,
                minimumLabel: UnitFormatter.height(cm: 120, units: draft.unitSystem),
                maximumLabel: UnitFormatter.height(cm: 220, units: draft.unitSystem)
            )

            PulseValueSlider(
                title: "Weight",
                valueText: UnitFormatter.weight(kg: draft.weightKg, units: draft.unitSystem),
                value: $draft.weightKg,
                range: 35...200,
                step: 0.5,
                minimumLabel: UnitFormatter.weight(kg: 35, units: draft.unitSystem),
                maximumLabel: UnitFormatter.weight(kg: 200, units: draft.unitSystem)
            )
        }
    }

    private var levelStep: some View {
        VStack(alignment: .leading, spacing: 26) {
            StepTitle(
                eyebrow: "Training",
                title: "Where are you now?",
                subtitle: "We'll use this to set the pace of your plans, not to judge it."
            )

            VStack(spacing: 12) {
                ForEach(FitnessLevel.allCases) { level in
                    SelectionCard(
                        symbol: level.symbol,
                        title: level.label,
                        detail: level.detail,
                        isSelected: draft.level == level
                    ) {
                        draft.level = level
                        Haptics.selection()
                    }
                }
            }
        }
    }

    private var goalStep: some View {
        VStack(alignment: .leading, spacing: 26) {
            StepTitle(
                eyebrow: "Direction",
                title: "What matters most?",
                subtitle: "Pick the goal you want this season to move. You can refine it later."
            )

            VStack(spacing: 12) {
                ForEach(FitnessGoal.allCases) { goal in
                    SelectionCard(
                        symbol: goal.symbol,
                        title: goal.label,
                        detail: goal.detail,
                        isSelected: draft.goal == goal
                    ) {
                        draft.goal = goal
                        Haptics.selection()
                    }
                }
            }
        }
    }

    private var activitiesStep: some View {
        VStack(alignment: .leading, spacing: 26) {
            StepTitle(
                eyebrow: "Movement",
                title: "What moves you?",
                subtitle: "Choose everything you enjoy. We'll shape your rhythm around it."
            )

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                ForEach(ActivityPreference.allCases) { activity in
                    let selected = draft.activities.contains(activity)
                    Button {
                        if selected {
                            draft.activities.remove(activity)
                        } else {
                            draft.activities.insert(activity)
                        }
                        Haptics.selection()
                    } label: {
                        VStack(alignment: .leading, spacing: 12) {
                            Image(systemName: activity.symbol)
                                .font(.system(size: 18, weight: .medium))
                                .foregroundStyle(selected ? PulseColor.midnight : PulseColor.sage)
                                .frame(width: 38, height: 38)
                                .background(
                                    selected ? PulseColor.sage : Color.white.opacity(0.06),
                                    in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                                )
                            HStack {
                                Text(activity.label)
                                    .font(PulseFont.headline)
                                    .foregroundStyle(PulseColor.ivory)
                                Spacer()
                                if selected {
                                    Image(systemName: "checkmark.circle.fill")
                                        .font(.system(size: 14))
                                        .foregroundStyle(PulseColor.sage)
                                }
                            }
                        }
                        .padding(14)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .fill(selected ? PulseColor.sage.opacity(0.12) : Color.white.opacity(0.035))
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                .strokeBorder(selected ? PulseColor.sage.opacity(0.7) : Color.white.opacity(0.08), lineWidth: 1)
                        )
                    }
                    .buttonStyle(.plain)
                    .animation(.snappy(duration: 0.22), value: selected)
                    .accessibilityAddTraits(selected ? .isSelected : [])
                }
            }
        }
    }

    private var healthStep: some View {
        VStack(alignment: .leading, spacing: 24) {
            StepTitle(
                eyebrow: "Apple Health",
                title: "Bring your rhythm together.",
                subtitle: "PULSE reads the activity you already record and saves the workouts you complete."
            )

            VStack(spacing: 0) {
                healthRow("figure.walk.motion", "Daily movement", "Steps, walking and running distance")
                divider
                healthRow("flame.fill", "Active energy", "Calories burned throughout the day")
                divider
                healthRow("heart.fill", "Exercise & stand", "Exercise minutes and stand hours")
                divider
                healthRow("figure.strengthtraining.traditional", "Workouts", "Save completed sessions back to Health")
            }
            .padding(6)
            .background(Color.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.08), lineWidth: 1)
            )

            HStack(alignment: .top, spacing: 12) {
                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(PulseColor.sage)
                Text("You decide what to share. Health data is read on device and is never sold or used for advertising.")
                    .font(PulseFont.footnote)
                    .foregroundStyle(PulseColor.ivory.opacity(0.55))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.horizontal, 4)

            Text("You can change access at any time in You → Apple Health.")
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.ivory.opacity(0.38))
                .padding(.horizontal, 4)
        }
    }

    private var divider: some View {
        Rectangle()
            .fill(Color.white.opacity(0.06))
            .frame(height: 1)
            .padding(.leading, 60)
    }

    private func healthRow(_ symbol: String, _ title: String, _ detail: String) -> some View {
        HStack(spacing: 14) {
            Image(systemName: symbol)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(PulseColor.sage)
                .frame(width: 34, height: 34)
                .background(PulseColor.sage.opacity(0.1), in: RoundedRectangle(cornerRadius: 10, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(PulseFont.callout.weight(.medium))
                    .foregroundStyle(PulseColor.ivory)
                Text(detail)
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.ivory.opacity(0.45))
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 10)
    }

    // MARK: - Footer

    private var footer: some View {
        VStack(spacing: 14) {
            Button {
                handlePrimary()
            } label: {
                HStack(spacing: 8) {
                    if isConnectingHealth || isSaving {
                        ProgressView()
                            .tint(PulseColor.midnight)
                    }
                    Text(isConnectingHealth ? "Connecting…" : actionTitle)
                }
            }
            .buttonStyle(PulsePrimaryButtonStyle())
            .disabled(!canContinue || isConnectingHealth || isSaving)
            .opacity(canContinue ? 1 : 0.45)

            if step == .health {
                Button {
                    finish(connectHealth: false)
                } label: {
                    Text("Not now")
                }
                .buttonStyle(PulseTertiaryButtonStyle())
                .foregroundStyle(PulseColor.ivory.opacity(0.55))
                .disabled(isConnectingHealth || isSaving)
            }
        }
        .padding(.horizontal, 24)
        .padding(.top, 10)
        .padding(.bottom, 8)
        .background(
            LinearGradient(
                colors: [Color(hex: 0x0C0F0E).opacity(0), Color(hex: 0x0C0F0E)],
                startPoint: .top,
                endPoint: .center
            )
            .ignoresSafeArea()
        )
    }

    // MARK: - Actions

    private func handlePrimary() {
        switch step {
        case .welcome:
            advance()
        case .units, .profile, .level, .goal, .activities:
            advance()
        case .health:
            connectHealth()
        }
    }

    private func advance() {
        guard let next = OnboardingStep(rawValue: step.rawValue + 1) else { return }
        isMovingForward = true
        withAnimation(.spring(response: 0.42, dampingFraction: 0.88)) {
            step = next
        }
        Haptics.tap()
    }

    private func goBack() {
        guard let previous = OnboardingStep(rawValue: step.rawValue - 1) else { return }
        isMovingForward = false
        withAnimation(.spring(response: 0.42, dampingFraction: 0.88)) {
            step = previous
        }
        Haptics.tap()
    }

    private func connectHealth() {
        guard !isConnectingHealth else { return }
        isConnectingHealth = true
        Task {
            let connected = await appState.health.requestAuthorization()
            isConnectingHealth = false
            if connected {
                finish(connectHealth: true)
            } else {
                appState.showToast(
                    appState.health.lastError ?? "You can connect Apple Health later in You.",
                    symbol: "heart.slash",
                    tone: .error
                )
                finish(connectHealth: false)
            }
        }
    }

    private func finish(connectHealth: Bool) {
        guard !isSaving else { return }
        isSaving = true

        let profile = existingProfile ?? UserProfile()
        let trimmedName = draft.name.trimmingCharacters(in: .whitespacesAndNewlines)
        profile.name = trimmedName.isEmpty ? "Athlete" : trimmedName
        profile.age = draft.age
        profile.heightCm = draft.heightCm
        profile.weightKg = draft.weightKg
        profile.level = draft.level ?? .intermediate
        profile.goal = draft.goal ?? .stayConsistent
        profile.activities = Array(draft.activities)
        profile.unitSystem = draft.unitSystem
        profile.healthKitRequested = connectHealth
        profile.onboardingCompleted = true
        profile.recalculateTargets()
        profile.updatedAt = .now

        if existingProfile == nil {
            context.insert(profile)
        }
        do {
            try context.save()
            Haptics.success()
        } catch {
            appState.showToast("Couldn't save your profile. Please try again.", symbol: "exclamationmark.triangle.fill", tone: .error)
        }
        isSaving = false
    }
}

// MARK: - Supporting views

private enum OnboardingStep: Int {
    case welcome = 0
    case units = 1
    case profile = 2
    case level = 3
    case goal = 4
    case activities = 5
    case health = 6
}

private struct OnboardingDraft {
    var name = ""
    var age = 30
    var heightCm = 175.0
    var weightKg = 72.0
    var level: FitnessLevel?
    var goal: FitnessGoal?
    var activities: Set<ActivityPreference> = []
    var unitSystem: UnitSystem = .metric
}

private struct OnboardingBackground: View {
    var body: some View {
        ZStack {
            Color(hex: 0x0C0F0E)

            RadialGradient(
                colors: [PulseColor.sage.opacity(0.20), .clear],
                center: .topTrailing,
                startRadius: 20,
                endRadius: 460
            )

            RadialGradient(
                colors: [Color(hex: 0x5E8A6C).opacity(0.12), .clear],
                center: .bottomLeading,
                startRadius: 20,
                endRadius: 420
            )

            LinearGradient(
                colors: [.clear, Color(hex: 0x0C0F0E).opacity(0.7)],
                startPoint: .center,
                endPoint: .bottom
            )
        }
        .ignoresSafeArea()
    }
}

private struct StepTitle: View {
    let eyebrow: String
    let title: String
    let subtitle: String

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(eyebrow)
                .pulseOverline()
                .foregroundStyle(PulseColor.sage.opacity(0.75))

            Text(title)
                .font(.system(size: 32, weight: .semibold))
                .tracking(-0.5)
                .foregroundStyle(PulseColor.ivory)
                .fixedSize(horizontal: false, vertical: true)

            Text(subtitle)
                .font(PulseFont.callout)
                .foregroundStyle(PulseColor.ivory.opacity(0.5))
                .lineSpacing(3)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

private struct SelectionCard: View {
    let symbol: String
    let title: String
    let detail: String
    var footnote: String?
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: symbol)
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(isSelected ? PulseColor.midnight : PulseColor.sage)
                    .frame(width: 44, height: 44)
                    .background(
                        isSelected ? PulseColor.sage : Color.white.opacity(0.06),
                        in: RoundedRectangle(cornerRadius: 13, style: .continuous)
                    )

                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(PulseFont.headline)
                        .foregroundStyle(PulseColor.ivory)
                    Text(detail)
                        .font(PulseFont.footnote)
                        .foregroundStyle(PulseColor.ivory.opacity(0.48))
                        .fixedSize(horizontal: false, vertical: true)
                    if let footnote {
                        Text(footnote)
                            .font(PulseFont.caption.monospacedDigit())
                            .foregroundStyle(PulseColor.sage.opacity(0.75))
                            .padding(.top, 2)
                    }
                }

                Spacer(minLength: 8)

                ZStack {
                    Circle()
                        .strokeBorder(isSelected ? PulseColor.sage : Color.white.opacity(0.18), lineWidth: 1.5)
                        .frame(width: 22, height: 22)
                    if isSelected {
                        Circle()
                            .fill(PulseColor.sage)
                            .frame(width: 12, height: 12)
                    }
                }
            }
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(isSelected ? PulseColor.sage.opacity(0.09) : Color.white.opacity(0.035))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .strokeBorder(isSelected ? PulseColor.sage.opacity(0.65) : Color.white.opacity(0.08), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .animation(.snappy(duration: 0.22), value: isSelected)
        .accessibilityAddTraits(isSelected ? .isSelected : [])
    }
}
