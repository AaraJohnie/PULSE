import Foundation
import SwiftData
import Observation

enum HealthSaveState: Equatable {
    case idle
    case saving
    case saved
    case failed
    case notRequested
}

struct WorkoutCompletion: Identifiable {
    let id = UUID()
    let session: WorkoutSession
    let newRecords: [PersonalRecord]
}

@MainActor
@Observable
final class ActiveWorkoutController {
    struct CompletedSet: Identifiable, Equatable {
        let id = UUID()
        let index: Int
        let reps: Int
        let weightKg: Double
        let date: Date
    }

    struct ExerciseState: Identifiable {
        let id = UUID()
        let exercise: Exercise
        let restSeconds: Int
        var plannedSets: Int
        var targetReps: Int
        var targetWeightKg: Double
        var completedSets: [CompletedSet]

        var isComplete: Bool {
            completedSets.count >= plannedSets
        }

        var nextSetNumber: Int {
            min(completedSets.count + 1, plannedSets)
        }
    }

    let launch: WorkoutLaunch
    let startedAt: Date
    var exercises: [ExerciseState]
    var currentExerciseIndex: Int = 0
    var restEndsAt: Date?
    var restDuration: TimeInterval = 0
    var isPaused = false
    var endedAt: Date?
    var distanceMeters: Double?
    var completion: WorkoutCompletion?
    var healthSaveState: HealthSaveState = .idle
    var setCompletionCount = 0
    var restCompletionCount = 0
    var restExtensionCount = 0

    @ObservationIgnored private var pausedAccumulated: TimeInterval = 0
    @ObservationIgnored private var pauseStartedAt: Date?
    @ObservationIgnored private var restRemainingOnPause: TimeInterval?

    init(launch: WorkoutLaunch, startedAt: Date = .now) {
        self.launch = launch
        self.startedAt = startedAt
        self.exercises = launch.exercises.map { item in
            ExerciseState(
                exercise: item.exercise,
                restSeconds: item.restSeconds,
                plannedSets: item.sets,
                targetReps: item.reps,
                targetWeightKg: item.weightKg,
                completedSets: []
            )
        }
        if exercises.isEmpty {
            self.completion = nil
        }
    }

    var title: String { launch.title }
    var category: WorkoutCategory { launch.category }

    var currentExercise: ExerciseState {
        guard !exercises.isEmpty else {
            return ExerciseState(
                exercise: Exercise.synthesized(id: "empty", name: "Session", muscle: .fullBody),
                restSeconds: 60,
                plannedSets: 1,
                targetReps: 1,
                targetWeightKg: 0,
                completedSets: []
            )
        }
        return exercises[min(max(currentExerciseIndex, 0), exercises.count - 1)]
    }

    var totalPlannedSets: Int {
        exercises.reduce(0) { $0 + $1.plannedSets }
    }

    var completedSetCount: Int {
        exercises.reduce(0) { $0 + $1.completedSets.count }
    }

    var totalCompletedReps: Int {
        exercises.reduce(0) { partial, exercise in
            partial + exercise.completedSets.reduce(0) { $0 + $1.reps }
        }
    }

    var progress: Double {
        guard totalPlannedSets > 0 else { return 0 }
        return min(Double(completedSetCount) / Double(totalPlannedSets), 1)
    }

    var isLastExercise: Bool {
        currentExerciseIndex >= exercises.count - 1
    }

    var isCurrentExerciseComplete: Bool {
        currentExercise.isComplete
    }

    var allExercisesComplete: Bool {
        !exercises.isEmpty && exercises.allSatisfy(\.isComplete)
    }

    var nextExercise: ExerciseState? {
        guard currentExerciseIndex + 1 < exercises.count else { return nil }
        return exercises[currentExerciseIndex + 1]
    }

    var hasCompletedSet: Bool {
        completedSetCount > 0
    }

    var isResting: Bool {
        restEndsAt != nil
    }

    func elapsed(at date: Date = .now) -> TimeInterval {
        let end = endedAt ?? date
        var total = end.timeIntervalSince(startedAt) - pausedAccumulated
        if isPaused, let pauseStartedAt {
            total -= date.timeIntervalSince(pauseStartedAt)
        }
        return max(total, 0)
    }

    func setNumberLabel() -> String {
        guard !exercises.isEmpty else { return "No sets" }
        if currentExercise.isComplete {
            return "\(currentExercise.plannedSets) of \(currentExercise.plannedSets) sets"
        }
        return "Set \(currentExercise.nextSetNumber) of \(currentExercise.plannedSets)"
    }

    // MARK: - Adjustments

    func adjustWeight(by delta: Double) {
        guard !isPaused else { return }
        var next = currentExercise.targetWeightKg + delta
        next = max(0, (next * 2).rounded() / 2)
        exercises[currentExerciseIndex].targetWeightKg = min(next, 500)
    }

    func adjustReps(by delta: Int) {
        guard !isPaused else { return }
        exercises[currentExerciseIndex].targetReps = max(1, min(currentExercise.targetReps + delta, 100))
    }

    func addSet() {
        guard !isPaused else { return }
        exercises[currentExerciseIndex].plannedSets = min(currentExercise.plannedSets + 1, 20)
    }

    func completeCurrentSet(at date: Date = .now) {
        guard !isPaused, !exercises.isEmpty, !currentExercise.isComplete else { return }
        let index = currentExerciseIndex
        let set = CompletedSet(
            index: currentExercise.completedSets.count + 1,
            reps: currentExercise.targetReps,
            weightKg: currentExercise.targetWeightKg,
            date: date
        )
        exercises[index].completedSets.append(set)
        setCompletionCount += 1

        let isFinalSetOfSession = exercises[index].isComplete && index == exercises.count - 1
        if isFinalSetOfSession {
            restEndsAt = nil
            restDuration = 0
        } else {
            let rest = max(exercises[index].restSeconds, 10)
            restDuration = TimeInterval(rest)
            restEndsAt = date.addingTimeInterval(restDuration)
        }
    }

    func goToExercise(_ index: Int) {
        guard exercises.indices.contains(index) else { return }
        withAnimationIfAvailable {
            currentExerciseIndex = index
        }
    }

    func advanceToNextExercise() {
        guard !isLastExercise else { return }
        withAnimationIfAvailable {
            currentExerciseIndex += 1
        }
        restEndsAt = nil
        restRemainingOnPause = nil
    }

    func previousExercise() {
        guard currentExerciseIndex > 0 else { return }
        withAnimationIfAvailable {
            currentExerciseIndex -= 1
        }
    }

    // MARK: - Rest

    func skipRest() {
        restEndsAt = nil
        restRemainingOnPause = nil
        restDuration = 0
    }

    func extendRest(by seconds: TimeInterval) {
        guard let end = restEndsAt else { return }
        restEndsAt = end.addingTimeInterval(seconds)
        restDuration += seconds
        restExtensionCount += 1
    }

    func completeRest() {
        guard restEndsAt != nil else { return }
        restEndsAt = nil
        restDuration = 0
        restCompletionCount += 1
    }

    // MARK: - Pause

    func togglePause(at date: Date = .now) {
        if isPaused {
            resume(at: date)
        } else {
            pause(at: date)
        }
    }

    func pause(at date: Date = .now) {
        guard !isPaused else { return }
        if let end = restEndsAt {
            restRemainingOnPause = max(end.timeIntervalSince(date), 0)
            restEndsAt = nil
        }
        isPaused = true
        pauseStartedAt = date
    }

    func resume(at date: Date = .now) {
        guard isPaused else { return }
        if let pauseStartedAt {
            pausedAccumulated += date.timeIntervalSince(pauseStartedAt)
        }
        pauseStartedAt = nil
        isPaused = false
        if let remaining = restRemainingOnPause, remaining > 0 {
            restDuration = remaining
            restEndsAt = date.addingTimeInterval(remaining)
        }
        restRemainingOnPause = nil
    }

    // MARK: - Completion

    @discardableResult
    func finish(
        in context: ModelContext,
        profile: UserProfile?,
        health: HealthKitService
    ) -> WorkoutCompletion? {
        if let completion { return completion }

        let now = Date()
        if isPaused {
            resume(at: now)
        }
        endedAt = now

        let activeSeconds = elapsed(at: now)
        let minutes = max(activeSeconds / 60, 1)
        let calories = WorkoutAnalytics.estimatedCalories(
            category: category,
            minutes: minutes,
            weightKg: profile?.weightKg ?? 0
        )

        let previousSessions = (try? context.fetch(FetchDescriptor<WorkoutSession>())) ?? []
        let previousCompleted = previousSessions.filter { $0.status == .completed }

        let session = WorkoutSession(
            title: launch.title,
            category: category,
            startedAt: startedAt,
            endedAt: now,
            status: .completed,
            estimatedCalories: calories,
            distanceMeters: distanceMeters,
            routineID: launch.routineID
        )
        context.insert(session)

        var volume: Double = 0
        for exercise in exercises {
            for set in exercise.completedSets {
                let record = WorkoutSetRecord(
                    exerciseID: exercise.exercise.id,
                    exerciseName: exercise.exercise.name,
                    muscleGroup: exercise.exercise.primaryMuscle,
                    setIndex: set.index - 1,
                    reps: set.reps,
                    weightKg: set.weightKg,
                    completedAt: set.date
                )
                context.insert(record)
                record.session = session
                volume += Double(set.reps) * set.weightKg
            }
        }
        session.totalVolumeKg = volume

        if let routineID = launch.routineID,
           let routines = try? context.fetch(FetchDescriptor<Routine>()),
           let routine = routines.first(where: { $0.id == routineID }) {
            routine.lastUsedAt = now
        }

        let records = WorkoutAnalytics.newRecords(in: session, comparedTo: previousCompleted)
        try? context.save()

        let result = WorkoutCompletion(session: session, newRecords: records)
        completion = result

        if health.accessState == .requested {
            healthSaveState = .saving
            Task { [weak self] in
                let saved = await health.saveWorkout(session)
                self?.healthSaveState = saved ? .saved : .failed
            }
        } else {
            healthSaveState = .notRequested
        }

        return result
    }

    private func withAnimationIfAvailable(_ changes: () -> Void) {
        changes()
    }
}
