import SwiftUI
import SwiftData
import UIKit

struct ActiveWorkoutView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Environment(AppState.self) private var app

    @Query private var profiles: [UserProfile]
    @State private var controller: ActiveWorkoutController

    init(launch: WorkoutLaunch) {
        _controller = State(initialValue: ActiveWorkoutController(launch: launch))
    }

    private var profile: UserProfile? { profiles.first }

    var body: some View {
        Group {
            if let completion = controller.completion {
                WorkoutSummaryView(
                    completion: completion,
                    healthState: controller.healthSaveState
                ) {
                    app.lastCompletion = completion
                    dismiss()
                }
            } else if controller.launch.exercises.isEmpty {
                CardioWorkoutScreen(controller: controller, profile: profile)
            } else {
                StrengthWorkoutScreen(controller: controller, profile: profile)
            }
        }
        .interactiveDismissDisabled()
        .onAppear {
            UIApplication.shared.isIdleTimerDisabled = true
        }
        .onDisappear {
            UIApplication.shared.isIdleTimerDisabled = false
            NotificationService.shared.cancelRestFinished()
        }
    }
}

struct StrengthWorkoutScreen: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Environment(AppState.self) private var app

    let controller: ActiveWorkoutController
    let profile: UserProfile?

    @State private var showFinishConfirmation = false
    @State private var showDiscardConfirmation = false

    private var units: UnitSystem { profile?.unitSystem ?? .metric }
    private var exercise: ActiveWorkoutController.ExerciseState { controller.currentExercise }

    var body: some View {
        ZStack {
            PulseScreenBackground()

            VStack(spacing: 0) {
                header
                    .padding(.horizontal, PulseMetrics.screenPadding)
                    .padding(.top, 6)
                    .padding(.bottom, 12)

                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        timerStrip
                        sessionPlan
                        exerciseCard

                        if controller.isResting && !controller.isPaused {
                            RestTimerCard(controller: controller)
                                .transition(.opacity.combined(with: .move(edge: .top)))
                        }

                        if !controller.hasCompletedSet {
                            HStack(alignment: .top, spacing: 9) {
                                Image(systemName: "info.circle")
                                    .font(.system(size: 12, weight: .semibold))
                                    .foregroundStyle(PulseColor.accent)
                                Text("Adjust the weight and reps before completing each set. Your rest timer starts automatically.")
                                    .font(PulseFont.footnote)
                                    .foregroundStyle(PulseColor.textSecondary)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                            .padding(14)
                            .background(PulseColor.accent.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                    }
                    .padding(.horizontal, PulseMetrics.screenPadding)
                    .padding(.bottom, 22)
                }
                .scrollIndicators(.hidden)

                controls
            }
        }
        .task(id: controller.restEndsAt) {
            guard let end = controller.restEndsAt else { return }
            let remaining = end.timeIntervalSinceNow
            if remaining > 0 {
                try? await Task.sleep(for: .seconds(remaining))
            }
            guard !Task.isCancelled, controller.restEndsAt != nil, !controller.isPaused else { return }
            controller.completeRest()
            Haptics.success()
            NotificationService.shared.cancelRestFinished()
        }
        .confirmationDialog("Finish this workout?", isPresented: $showFinishConfirmation, titleVisibility: .visible) {
            Button("Finish and save") { finish() }
            Button("Keep training", role: .cancel) {}
        } message: {
            Text("\(controller.completedSetCount) of \(controller.totalPlannedSets) sets · \(PulseDate.clock(controller.elapsed()))")
        }
        .alert("Discard this workout?", isPresented: $showDiscardConfirmation) {
            Button("Keep going", role: .cancel) {}
            Button("Discard", role: .destructive) {
                NotificationService.shared.cancelRestFinished()
                dismiss()
            }
        } message: {
            Text("Completed sets from this session will not be saved.")
        }
    }

    // MARK: - Header

    private var header: some View {
        HStack(spacing: 12) {
            PulseIconButton(
                symbol: "xmark",
                size: 38,
                tint: PulseColor.textSecondary,
                background: PulseColor.surfaceMuted.opacity(0.65),
                accessibilityLabel: "Close workout"
            ) {
                showDiscardConfirmation = true
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(controller.title)
                    .font(PulseFont.headline)
                    .foregroundStyle(PulseColor.textPrimary)
                    .lineLimit(1)
                HStack(spacing: 5) {
                    Image(systemName: controller.category.symbol)
                    Text(controller.category.label)
                    if controller.isPaused {
                        Text("· Paused")
                            .foregroundStyle(PulseColor.warning)
                    }
                }
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)
            }

            Spacer(minLength: 6)

            PulseIconButton(
                symbol: controller.isPaused ? "play.fill" : "pause.fill",
                size: 38,
                tint: controller.isPaused ? PulseColor.accent : PulseColor.textPrimary,
                background: PulseColor.surfaceMuted.opacity(0.65),
                accessibilityLabel: controller.isPaused ? "Resume workout" : "Pause workout"
            ) {
                togglePause()
            }
        }
    }

    // MARK: - Timer

    private var timerStrip: some View {
        VStack(spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                TimelineView(.periodic(from: .now, by: 1)) { timeline in
                    Text(PulseDate.clock(controller.elapsed(at: timeline.date)))
                        .font(PulseFont.number(34, weight: .semibold))
                        .foregroundStyle(PulseColor.textPrimary)
                        .contentTransition(.numericText())
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 2) {
                    Text("\(controller.completedSetCount) / \(controller.totalPlannedSets)")
                        .font(PulseFont.number(15, weight: .semibold))
                        .foregroundStyle(PulseColor.textSecondary)
                    Text("sets complete")
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.textTertiary)
                }
            }

            PulseProgressBar(value: controller.progress, tint: PulseColor.accent, height: 6)
        }
        .padding(.vertical, 4)
    }

    // MARK: - Session plan

    private var sessionPlan: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(Array(controller.exercises.enumerated()), id: \.element.id) { index, item in
                    Button {
                        controller.goToExercise(index)
                        Haptics.selection()
                    } label: {
                        HStack(spacing: 6) {
                            if item.isComplete {
                                Image(systemName: "checkmark")
                                    .font(.system(size: 9, weight: .bold))
                            }
                            Text(item.exercise.name)
                                .font(PulseFont.caption.weight(.semibold))
                                .lineLimit(1)
                        }
                        .foregroundStyle(index == controller.currentExerciseIndex ? PulseColor.midnight : PulseColor.textSecondary)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(
                            Capsule().fill(index == controller.currentExerciseIndex ? PulseColor.sage : PulseColor.surface)
                        )
                        .overlay(Capsule().strokeBorder(index == controller.currentExerciseIndex ? Color.clear : PulseColor.hairline, lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(index == controller.currentExerciseIndex ? .isSelected : [])
                }
            }
            .padding(.vertical, 2)
        }
    }

    // MARK: - Exercise card

    private var exerciseCard: some View {
        PulseCard {
            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Exercise \(controller.currentExerciseIndex + 1) of \(controller.exercises.count)")
                            .pulseOverline()
                            .foregroundStyle(PulseColor.textTertiary)
                        Text(exercise.exercise.name)
                            .font(PulseFont.title)
                            .foregroundStyle(PulseColor.textPrimary)
                            .fixedSize(horizontal: false, vertical: true)
                        Text("\(exercise.exercise.primaryMuscle.label) · \(exercise.exercise.equipment.label)")
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)
                    }

                    Spacer(minLength: 8)

                    HStack(spacing: 6) {
                        exerciseNavigationButton(
                            symbol: "chevron.left",
                            enabled: controller.currentExerciseIndex > 0
                        ) {
                            controller.previousExercise()
                        }
                        exerciseNavigationButton(
                            symbol: "chevron.right",
                            enabled: controller.currentExerciseIndex < controller.exercises.count - 1
                        ) {
                            controller.advanceToNextExercise()
                        }
                    }
                }

                HStack(spacing: 10) {
                    PulsePillBadge(text: controller.setNumberLabel(), tint: PulseColor.accent)
                    if exercise.isComplete {
                        PulsePillBadge(text: "Complete", symbol: "checkmark", tint: PulseColor.accent, filled: true)
                    }
                    Spacer()
                    if !exercise.isComplete {
                        Button {
                            controller.addSet()
                            Haptics.tap()
                        } label: {
                            Text("Add set")
                                .font(PulseFont.caption.weight(.semibold))
                                .foregroundStyle(PulseColor.textSecondary)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(PulseColor.surfaceMuted, in: Capsule())
                        }
                        .buttonStyle(.plain)
                        .disabled(controller.isPaused)
                    }
                }

                HStack(spacing: 12) {
                    AdjustmentControl(
                        title: "Weight",
                        value: exercise.targetWeightKg > 0
                            ? UnitFormatter.weight(kg: exercise.targetWeightKg, units: units)
                            : "Bodyweight",
                        onDecrease: { controller.adjustWeight(by: -weightStep) },
                        onIncrease: { controller.adjustWeight(by: weightStep) },
                        isEnabled: !controller.isPaused && !exercise.isComplete
                    )

                    AdjustmentControl(
                        title: "Reps",
                        value: "\(exercise.targetReps)",
                        onDecrease: { controller.adjustReps(by: -1) },
                        onIncrease: { controller.adjustReps(by: 1) },
                        isEnabled: !controller.isPaused && !exercise.isComplete
                    )
                }

                HStack(spacing: 8) {
                    ForEach(0..<exercise.plannedSets, id: \.self) { index in
                        Capsule()
                            .fill(index < exercise.completedSets.count ? PulseColor.accent : PulseColor.surfaceMuted)
                            .frame(height: 5)
                    }
                }
                .accessibilityHidden(true)

                if !controller.isPaused, let next = controller.nextExercise, exercise.isComplete {
                    HStack(spacing: 10) {
                        Image(systemName: "arrow.right.circle")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(PulseColor.accent)
                        Text("Up next: \(next.exercise.name) · \(next.plannedSets) × \(next.targetReps)")
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)
                            .lineLimit(1)
                    }
                }
            }
        }
        .animation(.snappy(duration: 0.28), value: exercise.completedSets.count)
    }

    private var weightStep: Double {
        units == .metric ? 2.5 : 2.5
    }

    private func exerciseNavigationButton(symbol: String, enabled: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(enabled ? PulseColor.textPrimary : PulseColor.textTertiary)
                .frame(width: 32, height: 32)
                .background(PulseColor.surfaceMuted, in: Circle())
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
        .accessibilityLabel(symbol == "chevron.left" ? "Previous exercise" : "Next exercise")
    }

    // MARK: - Controls

    private var controls: some View {
        VStack(spacing: 10) {
            if controller.isPaused {
                Button {
                    togglePause()
                } label: {
                    Label("Resume workout", systemImage: "play.fill")
                }
                .buttonStyle(.pulsePrimary)
            } else if controller.isResting {
                HStack(spacing: 10) {
                    Button {
                        skipRest()
                    } label: {
                        Text("Skip rest")
                    }
                    .buttonStyle(.pulseSecondary)

                    Button {
                        extendRest()
                    } label: {
                        Text("+15s")
                    }
                    .buttonStyle(PulsePrimaryButtonStyle(tint: PulseColor.surfaceRaised, foreground: PulseColor.textPrimary))
                }
            } else if exercise.isComplete && !controller.isLastExercise {
                Button {
                    advanceExercise()
                } label: {
                    Label("Next exercise", systemImage: "arrow.right")
                }
                .buttonStyle(.pulsePrimary)
            } else if controller.allExercisesComplete {
                Button {
                    showFinishConfirmation = true
                } label: {
                    Label("Finish workout", systemImage: "checkmark")
                }
                .buttonStyle(PulsePrimaryButtonStyle(tint: PulseColor.sage, foreground: PulseColor.midnight))
            } else if exercise.isComplete {
                Button {
                    showFinishConfirmation = true
                } label: {
                    Label("Finish workout", systemImage: "checkmark")
                }
                .buttonStyle(.pulsePrimary)
            } else {
                Button {
                    completeSet()
                } label: {
                    Label("Complete set", systemImage: "checkmark")
                }
                .buttonStyle(.pulsePrimary)
                .opacity(exercise.isComplete ? 0.4 : 1)
                .disabled(exercise.isComplete)
            }

            if !controller.allExercisesComplete {
                Button("Finish workout early") {
                    showFinishConfirmation = true
                }
                .buttonStyle(.pulseTertiary)
                .padding(.vertical, 2)
            }
        }
        .padding(.horizontal, PulseMetrics.screenPadding)
        .padding(.top, 10)
        .padding(.bottom, 8)
        .background(PulseColor.background.opacity(0.98))
        .overlay(alignment: .top) {
            PulseDivider()
        }
    }

    // MARK: - Actions

    private func completeSet() {
        guard !controller.isPaused, !exercise.isComplete else { return }
        withAnimation(.snappy(duration: 0.25)) {
            controller.completeCurrentSet()
        }
        Haptics.success()

        if controller.restEndsAt != nil {
            scheduleRestNotification()
        } else {
            NotificationService.shared.cancelRestFinished()
        }
    }

    private func skipRest() {
        controller.skipRest()
        NotificationService.shared.cancelRestFinished()
        Haptics.tap()
    }

    private func extendRest() {
        controller.extendRest(by: 15)
        Haptics.tap()
        scheduleRestNotification()
    }

    private func advanceExercise() {
        withAnimation(.snappy(duration: 0.25)) {
            controller.advanceToNextExercise()
        }
        NotificationService.shared.cancelRestFinished()
        Haptics.tap()
    }

    private func togglePause() {
        controller.togglePause()
        Haptics.medium()
        if controller.isPaused {
            NotificationService.shared.cancelRestFinished()
        } else if controller.isResting {
            scheduleRestNotification()
        }
    }

    private func scheduleRestNotification() {
        guard profile?.notificationsEnabled == true,
              profile?.restTimerNotificationsEnabled == true,
              controller.isResting else { return }
        let next = controller.restEndsAt.flatMap { _ in
            controller.nextExercise?.exercise.name ?? exercise.exercise.name
        } ?? exercise.exercise.name
        let seconds = max(Int(controller.restEndsAt?.timeIntervalSinceNow ?? 0), 1)
        Task {
            await NotificationService.shared.scheduleRestFinished(after: seconds, title: next)
        }
    }

    private func finish() {
        NotificationService.shared.cancelRestFinished()
        _ = controller.finish(in: context, profile: profile, health: app.health)
        Haptics.success()
    }
}

// MARK: - Adjustment control

private struct AdjustmentControl: View {
    let title: String
    let value: String
    let onDecrease: () -> Void
    let onIncrease: () -> Void
    var isEnabled: Bool = true

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(title)
                .pulseOverline()
                .foregroundStyle(PulseColor.textTertiary)

            HStack(spacing: 8) {
                stepButton(symbol: "minus", action: onDecrease)

                Text(value)
                    .font(PulseFont.number(17, weight: .semibold))
                    .foregroundStyle(PulseColor.textPrimary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                    .frame(maxWidth: .infinity)
                    .contentTransition(.numericText())

                stepButton(symbol: "plus", action: onIncrease)
            }
            .padding(.horizontal, 6)
            .padding(.vertical, 6)
            .background(PulseColor.surfaceMuted.opacity(0.7), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
        }
        .opacity(isEnabled ? 1 : 0.55)
    }

    private func stepButton(symbol: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(PulseColor.textPrimary)
                .frame(width: 30, height: 30)
                .background(PulseColor.surfaceRaised, in: Circle())
        }
        .buttonStyle(.plain)
        .disabled(!isEnabled)
        .accessibilityLabel("\(symbol == "minus" ? "Decrease" : "Increase") \(title)")
    }
}

// MARK: - Rest card

private struct RestTimerCard: View {
    let controller: ActiveWorkoutController

    var body: some View {
        TimelineView(.periodic(from: .now, by: 0.5)) { timeline in
            let remaining = max(controller.restEndsAt?.timeIntervalSince(timeline.date) ?? 0, 0)
            let progress = controller.restDuration > 0 ? remaining / controller.restDuration : 0

            PulseCard {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        HStack(spacing: 8) {
                            Image(systemName: "timer")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundStyle(PulseColor.accent)
                            Text("Rest")
                                .font(PulseFont.overline)
                                .tracking(1.1)
                                .textCase(.uppercase)
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                        Spacer()
                        if let next = controller.nextExercise {
                            Text("Next: \(next.exercise.name)")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                                .lineLimit(1)
                        }
                    }

                    HStack(alignment: .firstTextBaseline) {
                        Text(PulseDate.restClock(remaining))
                            .font(PulseFont.number(40, weight: .semibold))
                            .foregroundStyle(PulseColor.textPrimary)
                            .contentTransition(.numericText())
                        Spacer()
                        Text("of \(PulseDate.restClock(controller.restDuration))")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                    }

                    PulseProgressBar(value: progress, tint: PulseColor.accent, height: 6)
                }
            }
        }
    }
}
