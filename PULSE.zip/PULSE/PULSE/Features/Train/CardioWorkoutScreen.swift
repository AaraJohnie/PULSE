import SwiftUI
import SwiftData
import UIKit

struct CardioWorkoutScreen: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Environment(AppState.self) private var app

    let controller: ActiveWorkoutController
    let profile: UserProfile?

    @State private var distanceText = ""
    @State private var showFinishConfirmation = false
    @State private var showDiscardConfirmation = false

    private var units: UnitSystem { profile?.unitSystem ?? .metric }

    private var supportsDistance: Bool {
        [.running, .walking, .cycling].contains(controller.category)
    }

    var body: some View {
        ZStack {
            PulseScreenBackground()

            VStack(spacing: 0) {
                header
                    .padding(.horizontal, PulseMetrics.screenPadding)
                    .padding(.top, 6)
                    .padding(.bottom, 10)

                ScrollView {
                    VStack(spacing: 24) {
                        timelineRing
                        liveStats
                        distanceSection
                        guidanceCard
                    }
                    .padding(.horizontal, PulseMetrics.screenPadding)
                    .padding(.top, 8)
                    .padding(.bottom, 24)
                }
                .scrollIndicators(.hidden)
                .scrollDismissesKeyboard(.interactively)

                controls
            }
        }
        .confirmationDialog("Finish this session?", isPresented: $showFinishConfirmation, titleVisibility: .visible) {
            Button("Finish and save") { finish() }
            Button("Keep moving", role: .cancel) {}
        } message: {
            TimelineView(.periodic(from: .now, by: 1)) { timeline in
                Text("\(PulseDate.clock(controller.elapsed(at: timeline.date))) of movement will be saved.")
            }
        }
        .alert("Discard this session?", isPresented: $showDiscardConfirmation) {
            Button("Keep going", role: .cancel) {}
            Button("Discard", role: .destructive) {
                dismiss()
            }
        } message: {
            Text("This session will not appear in your history.")
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            PulseIconButton(
                symbol: "xmark",
                size: 38,
                tint: PulseColor.textSecondary,
                background: PulseColor.surfaceMuted.opacity(0.65),
                accessibilityLabel: "Close workout"
            ) {
                showDiscardConfirmation = true
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(controller.title)
                    .font(PulseFont.headline)
                    .foregroundStyle(PulseColor.textPrimary)
                    .lineLimit(1)
                HStack(spacing: 5) {
                    Image(systemName: controller.category.symbol)
                    Text(controller.category.label)
                    Text("· \(controller.launch.estimatedMinutes) min target")
                }
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)
            }

            Spacer(minLength: 6)

            if controller.isPaused {
                PulsePillBadge(text: "Paused", symbol: "pause.fill", tint: PulseColor.warning)
            }
        }
    }

    private var timelineRing: some View {
        TimelineView(.periodic(from: .now, by: 1)) { timeline in
            let elapsed = controller.elapsed(at: timeline.date)
            let target = TimeInterval(controller.launch.estimatedMinutes * 60)
            let progress = target > 0 ? min(elapsed / target, 1) : 0

            ZStack {
                Circle()
                    .stroke(PulseColor.accent.opacity(0.13), lineWidth: 13)

                Circle()
                    .trim(from: 0, to: progress)
                    .stroke(
                        AngularGradient(
                            colors: [PulseColor.accent.opacity(0.5), PulseColor.accent],
                            center: .center
                        ),
                        style: StrokeStyle(lineWidth: 13, lineCap: .round)
                    )
                    .rotationEffect(.degrees(-90))
                    .animation(.linear(duration: 1), value: progress)

                VStack(spacing: 6) {
                    Text(controller.isPaused ? "PAUSED" : controller.category.label.uppercased())
                        .font(PulseFont.overline)
                        .tracking(1.4)
                        .foregroundStyle(controller.isPaused ? PulseColor.warning : PulseColor.textTertiary)

                    Text(PulseDate.clock(elapsed))
                        .font(PulseFont.number(46, weight: .semibold))
                        .foregroundStyle(PulseColor.textPrimary)
                        .contentTransition(.numericText())

                    Text("target \(controller.launch.estimatedMinutes) min")
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.textTertiary)
                }
            }
            .frame(width: 260, height: 260)
            .padding(.top, 10)
            .accessibilityElement(children: .combine)
            .accessibilityLabel("Elapsed time")
            .accessibilityValue(PulseDate.clock(elapsed))
        }
    }

    private var liveStats: some View {
        TimelineView(.periodic(from: .now, by: 1)) { timeline in
            let minutes = controller.elapsed(at: timeline.date) / 60
            let calories = WorkoutAnalytics.estimatedCalories(
                category: controller.category,
                minutes: minutes,
                weightKg: profile?.weightKg ?? 0
            )

            HStack(spacing: 12) {
                liveStat(
                    symbol: "flame.fill",
                    value: calories.map(UnitFormatter.energy) ?? "—",
                    unit: "kcal",
                    label: "Active energy",
                    tint: PulseColor.ringExercise
                )

                if supportsDistance {
                    liveStat(
                        symbol: "location.fill",
                        value: controller.distanceMeters.map {
                            UnitFormatter.distancePlain(meters: $0, units: units, places: 2)
                        } ?? "—",
                        unit: units.distanceUnit,
                        label: "Distance",
                        tint: PulseColor.ringStand
                    )
                } else {
                    liveStat(
                        symbol: "wind",
                        value: "\(controller.launch.estimatedMinutes)",
                        unit: "min",
                        label: "Session",
                        tint: PulseColor.accent
                    )
                }
            }
        }
    }

    private var distanceSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            if supportsDistance {
                HStack(alignment: .center, spacing: 12) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Distance")
                            .pulseOverline()
                            .foregroundStyle(PulseColor.textTertiary)
                        Text("Optional — add it as you go")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                    }

                    Spacer()

                    HStack(alignment: .firstTextBaseline, spacing: 6) {
                        TextField("0.0", text: $distanceText)
                            .keyboardType(.decimalPad)
                            .multilineTextAlignment(.trailing)
                            .font(PulseFont.number(22, weight: .semibold))
                            .foregroundStyle(PulseColor.textPrimary)
                            .frame(width: 88)
                            .accessibilityLabel("Distance in \(units.distanceUnit)")
                        Text(units.distanceUnit)
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textTertiary)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .strokeBorder(PulseColor.hairline, lineWidth: 1)
                    }
                }
                .padding(16)
                .background(PulseColor.surface.opacity(0.65), in: RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous)
                        .strokeBorder(PulseColor.hairline, lineWidth: 1)
                }
                .onChange(of: distanceText) { _, _ in
                    updateDistance()
                }
            }
        }
    }

    private var guidanceCard: some View {
        PulseCard {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 8) {
                    Image(systemName: "quote.opening")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(PulseColor.accent)
                    Text("Session note")
                        .pulseOverline()
                        .foregroundStyle(PulseColor.textTertiary)
                }

                Text(controller.launch.subtitle ?? "Keep your effort honest and your breathing relaxed. You can pause at any time.")
                    .font(PulseFont.callout)
                    .foregroundStyle(PulseColor.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var controls: some View {
        VStack(spacing: 10) {
            if controller.isPaused {
                Button {
                    controller.resume()
                    Haptics.medium()
                } label: {
                    Label("Resume session", systemImage: "play.fill")
                }
                .buttonStyle(.pulsePrimary)
            } else {
                HStack(spacing: 10) {
                    Button {
                        controller.pause()
                        Haptics.medium()
                    } label: {
                        Label("Pause", systemImage: "pause.fill")
                    }
                    .buttonStyle(.pulseSecondary)

                    Button {
                        showFinishConfirmation = true
                    } label: {
                        Label("Finish", systemImage: "checkmark")
                    }
                    .buttonStyle(.pulsePrimary)
                }
            }

            if !controller.isPaused {
                Button("Discard session") {
                    showDiscardConfirmation = true
                }
                .buttonStyle(.pulseTertiary)
                .padding(.vertical, 2)
            }
        }
        .padding(.horizontal, PulseMetrics.screenPadding)
        .padding(.top, 10)
        .padding(.bottom, 8)
        .background(PulseColor.background.opacity(0.98))
        .overlay(alignment: .top) {
            PulseDivider()
        }
    }

    private func liveStat(symbol: String, value: String, unit: String, label: String, tint: Color) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: symbol)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(tint)
            HStack(alignment: .firstTextBaseline, spacing: 3) {
                Text(value)
                    .font(PulseFont.number(22, weight: .semibold))
                    .foregroundStyle(PulseColor.textPrimary)
                    .contentTransition(.numericText())
                Text(unit)
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
            }
            Text(label)
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textSecondary)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous)
                .strokeBorder(PulseColor.hairline, lineWidth: 1)
        }
    }

    private func updateDistance() {
        let normalized = distanceText.replacingOccurrences(of: ",", with: ".")
        guard let value = Double(normalized), value > 0 else {
            controller.distanceMeters = nil
            return
        }
        controller.distanceMeters = units == .metric ? value * 1_000 : value * 1_609.344
    }

    private func finish() {
        if supportsDistance {
            updateDistance()
        }
        _ = controller.finish(in: context, profile: profile, health: app.health)
        Haptics.success()
    }
}
