import SwiftUI
import SwiftData

struct CategoryDetailView: View {
    @Environment(AppState.self) private var app
    @Query(sort: \Routine.createdAt, order: .reverse) private var routines: [Routine]

    let group: TrainCategoryGroup
    let profile: UserProfile

    private var templates: [CardioTemplate] {
        CardioCatalog.templates(for: group.categories)
    }

    private var plans: [WorkoutPlan] {
        WorkoutPlans.all.filter { group.categories.contains($0.category) }
    }

    private var matchingRoutines: [Routine] {
        routines.filter { group.categories.contains($0.category) }
    }

    private var exercises: [Exercise] {
        ExerciseCatalog.all.filter { group.categories.contains($0.category) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                PulsePageTitle(group.title, eyebrow: "Training", subtitle: group.subtitle)

                if !templates.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        PulseSectionHeader("Guided sessions", overline: "Start now")
                        VStack(spacing: 10) {
                            ForEach(templates) { template in
                                CardioTemplateCard(template: template) {
                                    app.activeWorkout = WorkoutLaunch(template: template)
                                }
                            }
                        }
                    }
                }

                if !plans.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        PulseSectionHeader("Plans", overline: "Structured")
                        ForEach(plans) { plan in
                            NavigationLink {
                                PlanDetailView(plan: plan, profile: profile)
                            } label: {
                                PlanSummaryCard(plan: plan)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                VStack(alignment: .leading, spacing: 12) {
                    PulseSectionHeader("Your routines", overline: "Saved")
                    if matchingRoutines.isEmpty {
                        PulseCard {
                            PulseEmptyState(
                                symbol: "square.stack.3d.up",
                                title: "No \(group.title.lowercased()) routines",
                                message: "Create a routine and it will live here, ready to start.",
                                actionTitle: "New routine",
                                action: nil,
                                compact: true
                            )
                            NavigationLink {
                                RoutineEditorView(profile: profile)
                            } label: {
                                Text("Create a routine")
                                    .font(PulseFont.headline)
                                    .foregroundStyle(PulseColor.midnight)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 14)
                                    .background(PulseColor.sage, in: Capsule())
                            }
                            .buttonStyle(.plain)
                            .padding(.horizontal, 4)
                            .padding(.bottom, 4)
                        }
                    } else {
                        ForEach(matchingRoutines) { routine in
                            RoutineStartRow(routine: routine, profile: profile) {
                                app.activeWorkout = WorkoutLaunch(routine: routine)
                            }
                        }
                    }
                }

                if !exercises.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        PulseSectionHeader("Exercises", overline: "Library")
                        PulseCard(padding: 6) {
                            VStack(spacing: 0) {
                                ForEach(Array(exercises.prefix(4).enumerated()), id: \.element.id) { index, exercise in
                                    NavigationLink {
                                        ExerciseDetailView(exercise: exercise)
                                    } label: {
                                        ExerciseRow(exercise: exercise)
                                            .padding(12)
                                    }
                                    .buttonStyle(.plain)
                                    if index < min(exercises.count, 4) - 1 {
                                        PulseDivider().padding(.leading, 52)
                                    }
                                }
                            }
                        }

                        NavigationLink {
                            ExerciseLibraryView(categories: group.categories)
                        } label: {
                            Text("See all \(exercises.count) exercises")
                                .font(PulseFont.footnote.weight(.semibold))
                                .foregroundStyle(PulseColor.accent)
                        }
                    }
                }
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 12)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .navigationTitle(group.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct CardioTemplateCard: View {
    let template: CardioTemplate
    let onStart: () -> Void

    var body: some View {
        PulseCard(padding: 16) {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .top) {
                    HStack(spacing: 11) {
                        Image(systemName: template.category.symbol)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(template.category.tint)
                            .frame(width: 40, height: 40)
                            .background(template.category.tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                        VStack(alignment: .leading, spacing: 2) {
                            Text(template.title)
                                .font(PulseFont.headline)
                                .foregroundStyle(PulseColor.textPrimary)
                            Text("\(template.minutes) min · \(template.effort)")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                    }
                    Spacer()
                    PulsePillBadge(text: template.focus.label, tint: template.category.tint)
                }

                Text(template.summary)
                    .font(PulseFont.footnote)
                    .foregroundStyle(PulseColor.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)

                Button(action: onStart) {
                    Label("Start session", systemImage: "play.fill")
                        .font(PulseFont.footnote.weight(.semibold))
                        .foregroundStyle(PulseColor.midnight)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(PulseColor.sage, in: Capsule())
                }
                .buttonStyle(.plain)
            }
        }
    }
}

private struct RoutineStartRow: View {
    let routine: Routine
    let profile: UserProfile
    let onStart: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            NavigationLink {
                RoutineDetailView(routine: routine, profile: profile)
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: routine.category.symbol)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(routine.category.tint)
                        .frame(width: 40, height: 40)
                        .background(routine.category.tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

                    VStack(alignment: .leading, spacing: 2) {
                        Text(routine.name)
                            .font(PulseFont.headline)
                            .foregroundStyle(PulseColor.textPrimary)
                            .lineLimit(1)
                        Text("\(routine.orderedExercises.count) exercises · \(routine.estimatedMinutes) min")
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)
                    }
                    Spacer(minLength: 0)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Button(action: onStart) {
                Image(systemName: "play.fill")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(PulseColor.midnight)
                    .frame(width: 38, height: 38)
                    .background(PulseColor.sage, in: Circle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Start \(routine.name)")
        }
        .padding(14)
        .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous)
                .strokeBorder(PulseColor.hairline, lineWidth: 1)
        }
    }
}

struct ExerciseRow: View {
    let exercise: Exercise

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "figure.strengthtraining.traditional")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(PulseColor.accent)
                .frame(width: 34, height: 34)
                .background(PulseColor.accent.opacity(0.11), in: RoundedRectangle(cornerRadius: 11, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text(exercise.name)
                    .font(PulseFont.callout.weight(.medium))
                    .foregroundStyle(PulseColor.textPrimary)
                Text("\(exercise.primaryMuscle.label) · \(exercise.equipment.label)")
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(PulseColor.textTertiary)
        }
        .contentShape(Rectangle())
    }
}
