import SwiftUI
import SwiftData

struct ExerciseLibraryView: View {
    var categories: [WorkoutCategory]?

    @State private var query = ""
    @State private var selectedMuscle: MuscleGroup?

    private var baseExercises: [Exercise] {
        guard let categories, !categories.isEmpty else { return ExerciseCatalog.all }
        return ExerciseCatalog.all.filter { categories.contains($0.category) }
    }

    private var filtered: [Exercise] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        return baseExercises.filter { exercise in
            let muscleMatch = selectedMuscle == nil || exercise.muscles.contains(selectedMuscle!)
            let queryMatch = trimmed.isEmpty || exercise.name.localizedCaseInsensitiveContains(trimmed)
            return muscleMatch && queryMatch
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 12) {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            PulseChip(
                                title: "All",
                                isSelected: selectedMuscle == nil,
                                action: {
                                    withAnimation(.snappy(duration: 0.2)) { selectedMuscle = nil }
                                }
                            )
                            ForEach(MuscleGroup.allCases) { muscle in
                                PulseChip(
                                    title: muscle.label,
                                    isSelected: selectedMuscle == muscle,
                                    action: {
                                        withAnimation(.snappy(duration: 0.2)) { selectedMuscle = muscle }
                                    }
                                )
                            }
                        }
                    }

                    HStack {
                        Text("\(filtered.count) movements")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                        Spacer()
                        if selectedMuscle != nil || !query.isEmpty {
                            Button("Clear") {
                                withAnimation(.snappy(duration: 0.2)) {
                                    selectedMuscle = nil
                                    query = ""
                                }
                            }
                            .font(PulseFont.caption.weight(.semibold))
                            .foregroundStyle(PulseColor.accent)
                        }
                    }
                }

                if filtered.isEmpty {
                    PulseEmptyState(
                        symbol: "magnifyingglass",
                        title: "No movements found",
                        message: "Try another search or remove the muscle filter.",
                        actionTitle: "Clear filters",
                        action: {
                            selectedMuscle = nil
                            query = ""
                        }
                    )
                    .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: PulseMetrics.cardRadius, style: .continuous))
                } else {
                    PulseCard(padding: 6) {
                        VStack(spacing: 0) {
                            ForEach(Array(filtered.enumerated()), id: \.element.id) { index, exercise in
                                NavigationLink {
                                    ExerciseDetailView(exercise: exercise)
                                } label: {
                                    ExerciseRow(exercise: exercise)
                                        .padding(12)
                                }
                                .buttonStyle(.plain)

                                if index < filtered.count - 1 {
                                    PulseDivider().padding(.leading, 52)
                                }
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 8)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .navigationTitle("Exercise library")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "Search movements")
    }
}

struct ExerciseDetailView: View {
    @Environment(AppState.self) private var app
    @Query private var profiles: [UserProfile]

    let exercise: Exercise

    private var profile: UserProfile? { profiles.first }

    private var relatedExercises: [Exercise] {
        ExerciseCatalog.all
            .filter { $0.id != exercise.id && $0.primaryMuscle == exercise.primaryMuscle }
            .prefix(3)
            .map { $0 }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Image(systemName: exercise.category.symbol)
                            .font(.system(size: 24, weight: .semibold))
                            .foregroundStyle(exercise.category.tint)
                            .frame(width: 58, height: 58)
                            .background(exercise.category.tint.opacity(0.13), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        Spacer()
                        PulsePillBadge(text: exercise.category.label, tint: exercise.category.tint)
                    }

                    Text(exercise.name)
                        .font(PulseFont.largeTitle)
                        .foregroundStyle(PulseColor.textPrimary)
                        .fixedSize(horizontal: false, vertical: true)

                    HStack(spacing: 16) {
                        Label(exercise.muscleSummary, systemImage: "figure.mixed.cardio")
                        Label(exercise.equipment.label, systemImage: "dumbbell")
                    }
                    .font(PulseFont.footnote)
                    .foregroundStyle(PulseColor.textSecondary)
                }

                VStack(alignment: .leading, spacing: 12) {
                    PulseSectionHeader("How to move", overline: "Technique")
                    PulseCard {
                        VStack(alignment: .leading, spacing: 16) {
                            if exercise.instructions.isEmpty {
                                Text("No technique cues are available for this movement yet.")
                                    .font(PulseFont.footnote)
                                    .foregroundStyle(PulseColor.textSecondary)
                            } else {
                                ForEach(Array(exercise.instructions.enumerated()), id: \.offset) { index, instruction in
                                    HStack(alignment: .top, spacing: 12) {
                                        Text("\(index + 1)")
                                            .font(PulseFont.number(12, weight: .semibold))
                                            .foregroundStyle(PulseColor.accent)
                                            .frame(width: 24, height: 24)
                                            .background(PulseColor.accent.opacity(0.12), in: Circle())
                                        Text(instruction)
                                            .font(PulseFont.callout)
                                            .foregroundStyle(PulseColor.textSecondary)
                                            .fixedSize(horizontal: false, vertical: true)
                                    }
                                }
                            }
                        }
                    }
                }

                VStack(spacing: 10) {
                    Button {
                        startSingleExercise()
                    } label: {
                        Label("Start a quick session", systemImage: "play.fill")
                    }
                    .buttonStyle(.pulsePrimary)

                    NavigationLink {
                        RoutineEditorView(profile: profile, seedExercise: exercise)
                    } label: {
                        Label("Build a routine around this", systemImage: "plus.circle")
                    }
                    .buttonStyle(.pulseSecondary)
                }

                if !relatedExercises.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        PulseSectionHeader("Related", overline: exercise.primaryMuscle.label)
                        PulseCard(padding: 6) {
                            VStack(spacing: 0) {
                                ForEach(Array(relatedExercises.enumerated()), id: \.element.id) { index, related in
                                    NavigationLink {
                                        ExerciseDetailView(exercise: related)
                                    } label: {
                                        ExerciseRow(exercise: related)
                                            .padding(12)
                                    }
                                    .buttonStyle(.plain)
                                    if index < relatedExercises.count - 1 {
                                        PulseDivider().padding(.leading, 52)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 10)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .navigationTitle(exercise.name)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func startSingleExercise() {
        let isMobility = exercise.category == .mobility || exercise.category == .yoga
        let launch = WorkoutLaunch(
            title: exercise.name,
            subtitle: "Single-exercise session",
            category: exercise.category,
            estimatedMinutes: isMobility ? 8 : 12,
            exercises: [
                WorkoutLaunchExercise(
                    exercise: exercise,
                    sets: 3,
                    reps: isMobility ? 8 : 10,
                    weightKg: exercise.defaultStartingWeightKg,
                    restSeconds: isMobility ? 30 : 90
                )
            ]
        )
        app.activeWorkout = launch
    }
}

struct ExercisePickerView: View {
    let onSelect: (Exercise) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var selectedMuscle: MuscleGroup?

    private var filtered: [Exercise] {
        ExerciseCatalog.search(query, muscle: selectedMuscle)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            PulseChip(title: "All", isSelected: selectedMuscle == nil) {
                                selectedMuscle = nil
                            }
                            ForEach(MuscleGroup.allCases) { muscle in
                                PulseChip(title: muscle.label, isSelected: selectedMuscle == muscle) {
                                    selectedMuscle = muscle
                                }
                            }
                        }
                    }

                    if filtered.isEmpty {
                        PulseEmptyState(
                            symbol: "magnifyingglass",
                            title: "No movements found",
                            message: "Try a different search term."
                        )
                        .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: PulseMetrics.cardRadius, style: .continuous))
                    } else {
                        PulseCard(padding: 6) {
                            VStack(spacing: 0) {
                                ForEach(Array(filtered.enumerated()), id: \.element.id) { index, exercise in
                                    Button {
                                        onSelect(exercise)
                                        dismiss()
                                    } label: {
                                        HStack(spacing: 12) {
                                            ExerciseRow(exercise: exercise)
                                            Image(systemName: "plus.circle.fill")
                                                .font(.system(size: 18))
                                                .foregroundStyle(PulseColor.accent)
                                        }
                                        .padding(12)
                                    }
                                    .buttonStyle(.plain)

                                    if index < filtered.count - 1 {
                                        PulseDivider().padding(.leading, 52)
                                    }
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal, PulseMetrics.screenPadding)
                .padding(.top, 8)
                .padding(.bottom, 24)
            }
            .pulseScreen()
            .navigationTitle("Add exercise")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "Search movements")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }
}
