import SwiftUI

struct PlansView: View {
    let profile: UserProfile

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                PulsePageTitle(
                    "Training plans",
                    eyebrow: "Structured",
                    subtitle: "Repeatable weeks that take the guesswork out of your training."
                )

                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "calendar.badge.clock")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(PulseColor.accent)
                    Text("Plans are templates, not a schedule. Start any session whenever it fits your week — your history will still build.")
                        .font(PulseFont.footnote)
                        .foregroundStyle(PulseColor.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(14)
                .background(PulseColor.accent.opacity(0.08), in: RoundedRectangle(cornerRadius: 16, style: .continuous))

                ForEach(WorkoutPlans.all) { plan in
                    NavigationLink {
                        PlanDetailView(plan: plan, profile: profile)
                    } label: {
                        PlanSummaryCard(plan: plan)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 10)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .navigationTitle("Training plans")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct PlanDetailView: View {
    @Environment(AppState.self) private var app

    let plan: WorkoutPlan
    let profile: UserProfile

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        PulsePillBadge(
                            text: plan.level.label,
                            symbol: plan.level.symbol,
                            tint: PulseColor.accent
                        )
                        Spacer()
                        Text("\(plan.weeks) weeks · \(plan.daysPerWeek) days / week")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                    }

                    Text(plan.name)
                        .font(PulseFont.largeTitle)
                        .foregroundStyle(PulseColor.textPrimary)

                    Text(plan.tagline)
                        .font(PulseFont.callout)
                        .foregroundStyle(PulseColor.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                }

                HStack(spacing: 0) {
                    planStat(value: "\(plan.sessionCount)", label: "Sessions")
                    divider
                    planStat(value: "\(plan.daysPerWeek)", label: "Per week")
                    divider
                    planStat(value: "\(plan.weeks)", label: "Weeks")
                    divider
                    planStat(value: plan.category.label, label: "Focus")
                }
                .padding(.vertical, 14)
                .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .strokeBorder(PulseColor.hairline, lineWidth: 1)
                }

                VStack(alignment: .leading, spacing: 12) {
                    PulseSectionHeader("Sessions", overline: "The plan")

                    ForEach(Array(plan.days.enumerated()), id: \.element.id) { index, day in
                        PlanDayCard(day: day, index: index) {
                            app.activeWorkout = WorkoutLaunch(plan: plan, day: day)
                        }
                    }
                }
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 10)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .navigationTitle(plan.name)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var divider: some View {
        Divider()
            .frame(height: 30)
            .overlay(PulseColor.hairline)
    }

    private func planStat(value: String, label: String) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(PulseFont.number(16, weight: .semibold))
                .foregroundStyle(PulseColor.textPrimary)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
            Text(label)
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)
        }
        .frame(maxWidth: .infinity)
    }
}

private struct PlanDayCard: View {
    let day: PlanDay
    let index: Int
    let onStart: () -> Void

    var body: some View {
        PulseCard(padding: 18) {
            VStack(alignment: .leading, spacing: 14) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Session \(index + 1)")
                            .font(PulseFont.overline)
                            .tracking(1.1)
                            .textCase(.uppercase)
                            .foregroundStyle(PulseColor.textTertiary)
                        Text(day.title)
                            .font(PulseFont.headline)
                            .foregroundStyle(PulseColor.textPrimary)
                        Text("\(day.focus) · \(day.estimatedMinutes) min")
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)
                    }

                    Spacer(minLength: 8)

                    Button(action: onStart) {
                        Image(systemName: "play.fill")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundStyle(PulseColor.midnight)
                            .frame(width: 38, height: 38)
                            .background(PulseColor.sage, in: Circle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Start \(day.title)")
                }

                VStack(spacing: 0) {
                    ForEach(Array(day.exercises.enumerated()), id: \.element.id) { exerciseIndex, planned in
                        HStack(spacing: 10) {
                            Text(planned.exercise?.name ?? "Exercise")
                                .font(PulseFont.footnote)
                                .foregroundStyle(PulseColor.textSecondary)
                                .lineLimit(1)
                            Spacer(minLength: 4)
                            Text("\(planned.sets) × \(planned.reps)")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                        .padding(.vertical, 7)

                        if exerciseIndex < day.exercises.count - 1 {
                            PulseDivider()
                        }
                    }
                }
            }
        }
    }
}
