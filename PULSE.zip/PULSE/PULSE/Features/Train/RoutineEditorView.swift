import SwiftUI
import SwiftData

struct RoutineDraftItem: Identifiable, Equatable {
    let id: UUID
    var exercise: Exercise
    var sets: Int
    var reps: Int
    var weightKg: Double
    var restSeconds: Int

    init(
        id: UUID = UUID(),
        exercise: Exercise,
        sets: Int = 3,
        reps: Int = 10,
        weightKg: Double? = nil,
        restSeconds: Int = 90
    ) {
        self.id = id
        self.exercise = exercise
        self.sets = sets
        self.reps = reps
        self.weightKg = weightKg ?? exercise.defaultStartingWeightKg
        self.restSeconds = restSeconds
    }
}

struct RoutineEditorView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    let profile: UserProfile?
    private let existing: Routine?

    @State private var name: String
    @State private var notes: String
    @State private var category: WorkoutCategory
    @State private var estimatedMinutes: Int
    @State private var items: [RoutineDraftItem]
    @State private var showExercisePicker = false
    @State private var editingItem: RoutineDraftItem?

    init(profile: UserProfile? = nil, seedExercise: Exercise? = nil, routine: Routine? = nil) {
        self.profile = profile
        self.existing = routine

        _name = State(initialValue: routine?.name ?? "")
        _notes = State(initialValue: routine?.notes ?? "")
        _category = State(initialValue: routine?.category ?? seedExercise?.category ?? .strength)
        _estimatedMinutes = State(initialValue: routine?.estimatedMinutes ?? 40)

        let startingItems: [RoutineDraftItem]
        if let routine {
            startingItems = routine.orderedExercises.map { item in
                let exercise = ExerciseCatalog.exercise(id: item.exerciseID)
                    ?? Exercise.synthesized(
                        id: item.exerciseID,
                        name: item.exerciseName,
                        muscle: item.muscleGroup
                    )
                return RoutineDraftItem(
                    exercise: exercise,
                    sets: item.targetSets,
                    reps: item.targetReps,
                    weightKg: item.targetWeightKg,
                    restSeconds: item.restSeconds
                )
            }
        } else if let seedExercise {
            startingItems = [RoutineDraftItem(exercise: seedExercise)]
        } else {
            startingItems = []
        }
        _items = State(initialValue: startingItems)
    }

    private var units: UnitSystem { profile?.unitSystem ?? .metric }

    private var canSave: Bool {
        name.trimmingCharacters(in: .whitespacesAndNewlines).count >= 2 && !items.isEmpty
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                PulseField(
                    title: "Routine name",
                    placeholder: "Upper body reset",
                    text: $name,
                    capitalization: .words
                )

                VStack(alignment: .leading, spacing: 10) {
                    Text("Focus")
                        .pulseOverline()
                        .foregroundStyle(PulseColor.textTertiary)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(WorkoutCategory.allCases) { item in
                                PulseChip(
                                    title: item.label,
                                    symbol: item.symbol,
                                    isSelected: category == item,
                                    action: {
                                        withAnimation(.snappy(duration: 0.2)) { category = item }
                                    }
                                )
                            }
                        }
                    }
                }

                PulseCounter(
                    title: "Estimated time",
                    value: $estimatedMinutes,
                    range: 5...180,
                    step: 5,
                    unit: "min"
                )

                VStack(alignment: .leading, spacing: 10) {
                    Text("Notes")
                        .pulseOverline()
                        .foregroundStyle(PulseColor.textTertiary)

                    TextField("What should you remember during this session?", text: $notes, axis: .vertical)
                        .font(PulseFont.callout)
                        .foregroundStyle(PulseColor.textPrimary)
                        .lineLimit(3...5)
                        .padding(16)
                        .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .overlay {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .strokeBorder(PulseColor.hairline, lineWidth: 1)
                        }
                }

                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        PulseSectionHeader("Exercises", overline: "Session")
                        Spacer()
                        Button {
                            showExercisePicker = true
                        } label: {
                            Label("Add", systemImage: "plus")
                                .font(PulseFont.footnote.weight(.semibold))
                                .foregroundStyle(PulseColor.accent)
                        }
                        .buttonStyle(.plain)
                    }

                    if items.isEmpty {
                        PulseCard {
                            PulseEmptyState(
                                symbol: "plus.circle",
                                title: "Add your first exercise",
                                message: "Pick movements from the library, then set target sets, reps and rest.",
                                actionTitle: "Add exercise",
                                action: { showExercisePicker = true },
                                compact: true
                            )
                        }
                    } else {
                        PulseCard(padding: 6) {
                            VStack(spacing: 0) {
                                ForEach(Array(items.enumerated()), id: \.element.id) { index, item in
                                    HStack(spacing: 10) {
                                        Button {
                                            editingItem = item
                                        } label: {
                                            HStack(spacing: 12) {
                                                Image(systemName: "line.3.horizontal")
                                                    .font(.system(size: 12, weight: .semibold))
                                                    .foregroundStyle(PulseColor.textTertiary)
                                                    .frame(width: 20)

                                                VStack(alignment: .leading, spacing: 2) {
                                                    Text(item.exercise.name)
                                                        .font(PulseFont.callout.weight(.medium))
                                                        .foregroundStyle(PulseColor.textPrimary)
                                                        .lineLimit(1)
                                                    Text("\(item.sets) × \(item.reps)\(item.weightKg > 0 ? " · \(UnitFormatter.weight(kg: item.weightKg, units: units))" : "") · \(item.restSeconds)s rest")
                                                        .font(PulseFont.caption)
                                                        .foregroundStyle(PulseColor.textSecondary)
                                                        .lineLimit(1)
                                                }
                                                Spacer(minLength: 0)
                                            }
                                            .contentShape(Rectangle())
                                        }
                                        .buttonStyle(.plain)

                                        Menu {
                                            Button {
                                                editingItem = item
                                            } label: {
                                                Label("Edit", systemImage: "slider.horizontal.3")
                                            }
                                            if index > 0 {
                                                Button {
                                                    move(from: index, to: index - 1)
                                                } label: {
                                                    Label("Move up", systemImage: "arrow.up")
                                                }
                                            }
                                            if index < items.count - 1 {
                                                Button {
                                                    move(from: index, to: index + 1)
                                                } label: {
                                                    Label("Move down", systemImage: "arrow.down")
                                                }
                                            }
                                            Button(role: .destructive) {
                                                remove(item.id)
                                            } label: {
                                                Label("Remove", systemImage: "trash")
                                            }
                                        } label: {
                                            Image(systemName: "ellipsis")
                                                .font(.system(size: 13, weight: .semibold))
                                                .foregroundStyle(PulseColor.textTertiary)
                                                .frame(width: 32, height: 32)
                                                .contentShape(Rectangle())
                                        }
                                        .accessibilityLabel("Options for \(item.exercise.name)")
                                    }
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 11)

                                    if index < items.count - 1 {
                                        PulseDivider().padding(.leading, 54)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 12)
            .padding(.bottom, 24)
        }
        .scrollIndicators(.hidden)
        .scrollDismissesKeyboard(.interactively)
        .pulseScreen()
        .navigationTitle(existing == nil ? "New routine" : "Edit routine")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") { dismiss() }
                    .foregroundStyle(PulseColor.textSecondary)
            }
        }
        .safeAreaInset(edge: .bottom) {
            VStack(spacing: 0) {
                PulseDivider()
                Button(existing == nil ? "Create routine" : "Save changes") {
                    save()
                }
                .buttonStyle(.pulsePrimary)
                .disabled(!canSave)
                .opacity(canSave ? 1 : 0.45)
                .padding(.horizontal, PulseMetrics.screenPadding)
                .padding(.vertical, 12)
            }
            .background(PulseColor.background.opacity(0.97))
        }
        .sheet(isPresented: $showExercisePicker) {
            ExercisePickerView { exercise in
                items.append(RoutineDraftItem(exercise: exercise))
            }
        }
        .sheet(item: $editingItem) { item in
            RoutineExerciseSheet(
                item: item,
                units: units,
                onSave: { updated in
                    if let index = items.firstIndex(where: { $0.id == updated.id }) {
                        items[index] = updated
                    }
                },
                onDelete: {
                    remove(item.id)
                }
            )
        }
    }

    private func move(from index: Int, to destination: Int) {
        guard items.indices.contains(index), items.indices.contains(destination) else { return }
        withAnimation(.snappy(duration: 0.2)) {
            items.swapAt(index, destination)
        }
    }

    private func remove(_ id: UUID) {
        withAnimation(.snappy(duration: 0.25)) {
            items.removeAll { $0.id == id }
        }
    }

    private func save() {
        guard canSave else { return }
        let trimmedNotes = notes.trimmingCharacters(in: .whitespacesAndNewlines)

        let target: Routine
        if let existing {
            target = existing
            for exercise in existing.exercises {
                context.delete(exercise)
            }
            target.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
            target.notes = trimmedNotes
            target.category = category
            target.estimatedMinutes = estimatedMinutes
        } else {
            target = Routine(
                name: name.trimmingCharacters(in: .whitespacesAndNewlines),
                notes: trimmedNotes,
                category: category,
                estimatedMinutes: estimatedMinutes
            )
            context.insert(target)
        }

        for (index, item) in items.enumerated() {
            let record = RoutineExercise(
                exercise: item.exercise,
                order: index,
                sets: item.sets,
                reps: item.reps,
                weightKg: item.weightKg,
                restSeconds: item.restSeconds
            )
            context.insert(record)
            record.routine = target
        }

        try? context.save()
        Haptics.success()
        dismiss()
    }
}

struct RoutineExerciseSheet: View {
    let item: RoutineDraftItem
    let units: UnitSystem
    let onSave: (RoutineDraftItem) -> Void
    let onDelete: () -> Void

    @Environment(\.dismiss) private var dismiss

    @State private var sets: Int
    @State private var reps: Int
    @State private var weightKg: Double
    @State private var restSeconds: Int

    private let restOptions = [30, 45, 60, 75, 90, 120, 180]

    init(
        item: RoutineDraftItem,
        units: UnitSystem,
        onSave: @escaping (RoutineDraftItem) -> Void,
        onDelete: @escaping () -> Void
    ) {
        self.item = item
        self.units = units
        self.onSave = onSave
        self.onDelete = onDelete
        _sets = State(initialValue: item.sets)
        _reps = State(initialValue: item.reps)
        _weightKg = State(initialValue: item.weightKg)
        _restSeconds = State(initialValue: item.restSeconds)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(item.exercise.name)
                            .font(PulseFont.title)
                            .foregroundStyle(PulseColor.textPrimary)
                        Text("\(item.exercise.primaryMuscle.label) · \(item.exercise.equipment.label)")
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)
                    }
                    .padding(.top, 8)

                    PulseCounter(title: "Sets", value: $sets, range: 1...20, unit: "sets")

                    PulseCounter(title: "Reps per set", value: $reps, range: 1...100, unit: "reps")

                    PulseValueSlider(
                        title: "Working weight",
                        valueText: weightKg > 0
                            ? UnitFormatter.weight(kg: weightKg, units: units)
                            : "Bodyweight",
                        value: $weightKg,
                        range: 0...250,
                        step: 0.5,
                        minimumLabel: "Bodyweight",
                        maximumLabel: UnitFormatter.weight(kg: 250, units: units)
                    )

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Rest between sets")
                            .pulseOverline()
                            .foregroundStyle(PulseColor.textTertiary)

                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 64), spacing: 8)], spacing: 8) {
                            ForEach(restOptions, id: \.self) { option in
                                PulseChip(
                                    title: "\(option)s",
                                    isSelected: restSeconds == option,
                                    action: {
                                        withAnimation(.snappy(duration: 0.2)) { restSeconds = option }
                                    }
                                )
                            }
                        }
                    }

                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: "repeat")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(PulseColor.accent)
                        Text("Estimated time is set on the routine. Rest timers run automatically between sets during a workout.")
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(14)
                    .background(PulseColor.surfaceMuted.opacity(0.7), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

                    Button(role: .destructive) {
                        onDelete()
                        dismiss()
                    } label: {
                        Label("Remove exercise", systemImage: "trash")
                            .font(PulseFont.footnote.weight(.semibold))
                            .foregroundStyle(PulseColor.danger)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, PulseMetrics.screenPadding)
                .padding(.bottom, 24)
            }
            .scrollIndicators(.hidden)
            .pulseScreen()
            .navigationTitle("Exercise target")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                        .foregroundStyle(PulseColor.textSecondary)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        var updated = item
                        updated.sets = sets
                        updated.reps = reps
                        updated.weightKg = weightKg
                        updated.restSeconds = restSeconds
                        onSave(updated)
                        Haptics.tap()
                        dismiss()
                    }
                    .fontWeight(.semibold)
                    .foregroundStyle(PulseColor.accent)
                }
            }
        }
        .presentationDetents([.large])
        .presentationDragIndicator(.visible)
    }
}
