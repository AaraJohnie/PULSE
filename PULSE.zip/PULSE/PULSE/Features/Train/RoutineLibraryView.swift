import SwiftUI
import SwiftData

struct RoutineLibraryView: View {
    @Environment(AppState.self) private var app
    @Query(sort: \Routine.createdAt, order: .reverse) private var routines: [Routine]

    let profile: UserProfile

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                PulsePageTitle(
                    "My routines",
                    eyebrow: "Saved sessions",
                    subtitle: "Repeatable workouts built around your equipment and time."
                )

                NavigationLink {
                    RoutineEditorView(profile: profile)
                } label: {
                    HStack(spacing: 14) {
                        Image(systemName: "plus")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(PulseColor.accent)
                            .frame(width: 42, height: 42)
                            .background(PulseColor.accent.opacity(0.12), in: Circle())
                        VStack(alignment: .leading, spacing: 2) {
                            Text("New routine")
                                .font(PulseFont.headline)
                                .foregroundStyle(PulseColor.textPrimary)
                            Text("Choose exercises, sets and rest")
                                .font(PulseFont.footnote)
                                .foregroundStyle(PulseColor.textSecondary)
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(PulseColor.textTertiary)
                    }
                    .padding(16)
                    .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous))
                    .overlay {
                        RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous)
                            .strokeBorder(PulseColor.hairlineStrong, style: StrokeStyle(lineWidth: 1, dash: [5, 4]))
                    }
                }
                .buttonStyle(.plain)

                if routines.isEmpty {
                    PulseCard {
                        PulseEmptyState(
                            symbol: "square.stack.3d.up",
                            title: "No routines yet",
                            message: "Create a routine once and start it whenever you need a session that fits.",
                            compact: false
                        )
                    }
                } else {
                    VStack(spacing: 10) {
                        ForEach(routines) { routine in
                            RoutineLibraryRow(routine: routine, profile: profile) {
                                app.activeWorkout = WorkoutLaunch(routine: routine)
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 10)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .navigationTitle("My routines")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                NavigationLink {
                    RoutineEditorView(profile: profile)
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 13, weight: .semibold))
                }
                .accessibilityLabel("New routine")
            }
        }
    }
}

private struct RoutineLibraryRow: View {
    let routine: Routine
    let profile: UserProfile
    let onStart: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            NavigationLink {
                RoutineDetailView(routine: routine, profile: profile)
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: routine.category.symbol)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(routine.category.tint)
                        .frame(width: 44, height: 44)
                        .background(routine.category.tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

                    VStack(alignment: .leading, spacing: 3) {
                        Text(routine.name)
                            .font(PulseFont.headline)
                            .foregroundStyle(PulseColor.textPrimary)
                            .lineLimit(1)
                        Text("\(routine.orderedExercises.count) exercises · \(routine.totalSets) sets · \(routine.estimatedMinutes) min")
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)
                            .lineLimit(1)
                        if !routine.muscleSummary.isEmpty {
                            Text(routine.muscleSummary)
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                                .lineLimit(1)
                        }
                    }

                    Spacer(minLength: 4)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Button(action: onStart) {
                Image(systemName: "play.fill")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(PulseColor.midnight)
                    .frame(width: 38, height: 38)
                    .background(PulseColor.sage, in: Circle())
            }
            .buttonStyle(.plain)
            .disabled(routine.orderedExercises.isEmpty)
            .opacity(routine.orderedExercises.isEmpty ? 0.4 : 1)
            .accessibilityLabel("Start \(routine.name)")
        }
        .padding(14)
        .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous)
                .strokeBorder(PulseColor.hairline, lineWidth: 1)
        }
    }
}

struct RoutineDetailView: View {
    @Environment(AppState.self) private var app
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss

    @Bindable var routine: Routine
    let profile: UserProfile?

    @State private var showDeleteConfirmation = false

    private var units: UnitSystem { profile?.unitSystem ?? .metric }

    private var plannedVolume: Double {
        routine.orderedExercises.reduce(0) {
            $0 + Double($1.targetSets * $1.targetReps) * $1.targetWeightKg
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        PulsePillBadge(
                            text: routine.category.label,
                            symbol: routine.category.symbol,
                            tint: routine.category.tint
                        )
                        Spacer()
                        Button {
                            showDeleteConfirmation = true
                        } label: {
                            Image(systemName: "trash")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundStyle(PulseColor.danger)
                                .frame(width: 34, height: 34)
                                .background(PulseColor.danger.opacity(0.1), in: Circle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Delete routine")
                    }

                    Text(routine.name)
                        .font(PulseFont.largeTitle)
                        .foregroundStyle(PulseColor.textPrimary)
                        .fixedSize(horizontal: false, vertical: true)

                    if !routine.notes.isEmpty {
                        Text(routine.notes)
                            .font(PulseFont.callout)
                            .foregroundStyle(PulseColor.textSecondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }

                HStack(spacing: 0) {
                    detailStat(value: "\(routine.orderedExercises.count)", label: "Exercises")
                    Divider().frame(height: 30).overlay(PulseColor.hairline)
                    detailStat(value: "\(routine.totalSets)", label: "Sets")
                    Divider().frame(height: 30).overlay(PulseColor.hairline)
                    detailStat(value: "\(routine.estimatedMinutes)", label: "Minutes")
                    Divider().frame(height: 30).overlay(PulseColor.hairline)
                    detailStat(value: UnitFormatter.volume(kg: plannedVolume, units: units), label: "Planned volume")
                }
                .padding(.vertical, 14)
                .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .strokeBorder(PulseColor.hairline, lineWidth: 1)
                }

                VStack(alignment: .leading, spacing: 12) {
                    PulseSectionHeader("Session plan", overline: "Exercises")

                    if routine.orderedExercises.isEmpty {
                        PulseCard {
                            PulseEmptyState(
                                symbol: "list.bullet",
                                title: "This routine is empty",
                                message: "Add a few exercises to make it startable.",
                                compact: true
                            )
                        }
                    } else {
                        PulseCard(padding: 6) {
                            VStack(spacing: 0) {
                                ForEach(Array(routine.orderedExercises.enumerated()), id: \.element.id) { index, item in
                                    HStack(spacing: 12) {
                                        Text("\(index + 1)")
                                            .font(PulseFont.number(12, weight: .semibold))
                                            .foregroundStyle(PulseColor.textTertiary)
                                            .frame(width: 22, alignment: .leading)

                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(item.exerciseName)
                                                .font(PulseFont.callout.weight(.medium))
                                                .foregroundStyle(PulseColor.textPrimary)
                                            Text("\(item.targetSets) sets × \(item.targetReps) reps · \(item.muscleGroup.label)")
                                                .font(PulseFont.footnote)
                                                .foregroundStyle(PulseColor.textSecondary)
                                        }

                                        Spacer(minLength: 6)

                                        if item.targetWeightKg > 0 {
                                            Text(UnitFormatter.weight(kg: item.targetWeightKg, units: units))
                                                .font(PulseFont.caption)
                                                .foregroundStyle(PulseColor.textTertiary)
                                        }
                                    }
                                    .padding(12)

                                    if index < routine.orderedExercises.count - 1 {
                                        PulseDivider().padding(.leading, 46)
                                    }
                                }
                            }
                        }
                    }
                }

                VStack(spacing: 10) {
                    Button {
                        app.activeWorkout = WorkoutLaunch(routine: routine)
                    } label: {
                        Label("Start workout", systemImage: "play.fill")
                    }
                    .buttonStyle(.pulsePrimary)
                    .disabled(routine.orderedExercises.isEmpty)
                    .opacity(routine.orderedExercises.isEmpty ? 0.45 : 1)

                    NavigationLink {
                        RoutineEditorView(profile: profile, routine: routine)
                    } label: {
                        Label("Edit routine", systemImage: "slider.horizontal.3")
                    }
                    .buttonStyle(.pulseSecondary)
                }
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 10)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .navigationTitle("Routine")
        .navigationBarTitleDisplayMode(.inline)
        .alert("Delete this routine?", isPresented: $showDeleteConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Delete", role: .destructive) {
                context.delete(routine)
                try? context.save()
                dismiss()
            }
        } message: {
            Text("Your workout history stays intact, but the routine will be removed.")
        }
    }

    private func detailStat(value: String, label: String) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(PulseFont.number(16, weight: .semibold))
                .foregroundStyle(PulseColor.textPrimary)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
            Text(label)
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity)
    }
}
