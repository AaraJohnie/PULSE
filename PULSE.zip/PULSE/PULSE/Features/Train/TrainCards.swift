import SwiftUI

struct TrainCategoryGroup: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let symbol: String
    let tint: Color
    let categories: [WorkoutCategory]

    static let all: [TrainCategoryGroup] = [
        TrainCategoryGroup(
            id: "strength",
            title: "Strength",
            subtitle: "Build a base that holds",
            symbol: "dumbbell.fill",
            tint: PulseColor.ringMove,
            categories: [.strength]
        ),
        TrainCategoryGroup(
            id: "run-walk",
            title: "Run & Walk",
            subtitle: "Find your aerobic rhythm",
            symbol: "figure.run",
            tint: PulseColor.ringExercise,
            categories: [.running, .walking]
        ),
        TrainCategoryGroup(
            id: "cycle",
            title: "Cycling",
            subtitle: "Steady miles, honest effort",
            symbol: "bicycle",
            tint: PulseColor.ringStand,
            categories: [.cycling]
        ),
        TrainCategoryGroup(
            id: "yoga-mobility",
            title: "Yoga & Mobility",
            subtitle: "Move with more freedom",
            symbol: "figure.yoga",
            tint: PulseColor.accent,
            categories: [.yoga, .mobility]
        )
    ]
}

struct CategoryTile: View {
    let group: TrainCategoryGroup
    let meta: String

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Image(systemName: group.symbol)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(group.tint)
                    .frame(width: 44, height: 44)
                    .background(group.tint.opacity(0.13), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                Spacer()
                Image(systemName: "arrow.up.right")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(PulseColor.textTertiary)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(group.title)
                    .font(PulseFont.headline)
                    .foregroundStyle(PulseColor.textPrimary)
                Text(group.subtitle)
                    .font(PulseFont.footnote)
                    .foregroundStyle(PulseColor.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                Text(meta)
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
                    .padding(.top, 2)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, minHeight: 168, alignment: .topLeading)
        .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous)
                .strokeBorder(PulseColor.hairline, lineWidth: 1)
        }
    }
}

struct PlanSummaryCard: View {
    let plan: WorkoutPlan

    var body: some View {
        PulseCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    PulsePillBadge(text: plan.level.label, symbol: plan.level.symbol, tint: PulseColor.accent)
                    Spacer()
                    Text("\(plan.weeks) weeks")
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.textTertiary)
                }

                VStack(alignment: .leading, spacing: 5) {
                    Text(plan.name)
                        .font(PulseFont.title3)
                        .foregroundStyle(PulseColor.textPrimary)
                    Text(plan.tagline)
                        .font(PulseFont.footnote)
                        .foregroundStyle(PulseColor.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                }

                HStack(spacing: 16) {
                    Label("\(plan.daysPerWeek) days / week", systemImage: "calendar")
                    Label("\(plan.sessionCount) sessions", systemImage: "list.bullet")
                }
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)

                HStack(spacing: 5) {
                    ForEach(0..<plan.daysPerWeek, id: \.self) { _ in
                        Capsule()
                            .fill(PulseColor.accent.opacity(0.35))
                            .frame(height: 3)
                    }
                    ForEach(0..<max(7 - plan.daysPerWeek, 0), id: \.self) { _ in
                        Capsule()
                            .fill(PulseColor.hairline)
                            .frame(height: 3)
                    }
                }
            }
        }
    }
}

struct RoutineSummaryCard: View {
    let routine: Routine
    let units: UnitSystem

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: routine.category.symbol)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(routine.category.tint)
                Text(routine.category.label.uppercased())
                    .font(PulseFont.overline)
                    .tracking(1.1)
                    .foregroundStyle(PulseColor.textTertiary)
                Spacer()
            }

            Text(routine.name)
                .font(PulseFont.headline)
                .foregroundStyle(PulseColor.textPrimary)
                .lineLimit(2)

            Text("\(routine.orderedExercises.count) exercises · \(routine.totalSets) sets")
                .font(PulseFont.footnote)
                .foregroundStyle(PulseColor.textSecondary)

            HStack {
                Label("\(routine.estimatedMinutes) min", systemImage: "clock")
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
                Spacer()
                if routine.lastUsedAt != nil {
                    Text("Last done \(routine.lastUsedAt.map { PulseDate.relativeDay($0).lowercased() } ?? "")")
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.textTertiary)
                        .lineLimit(1)
                }
            }
        }
        .padding(16)
        .frame(width: 226, alignment: .leading)
        .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous)
                .strokeBorder(PulseColor.hairline, lineWidth: 1)
        }
    }
}

struct WorkoutHistoryRow: View {
    let session: WorkoutSession
    let units: UnitSystem

    var body: some View {
        HStack(spacing: 13) {
            Image(systemName: session.category.symbol)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(session.category.tint)
                .frame(width: 40, height: 40)
                .background(session.category.tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text(session.title)
                    .font(PulseFont.headline)
                    .foregroundStyle(PulseColor.textPrimary)
                    .lineLimit(1)
                HStack(spacing: 6) {
                    Text(PulseDate.relativeDay(session.startedAt))
                    Text("·")
                    Text("\(session.durationMinutes) min")
                    if session.totalVolumeKg > 0 {
                        Text("·")
                        Text(UnitFormatter.volume(kg: session.totalVolumeKg, units: units))
                    }
                }
                .font(PulseFont.footnote)
                .foregroundStyle(PulseColor.textSecondary)
            }

            Spacer(minLength: 6)

            if session.isFromWatch {
                Image(systemName: "applewatch")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(PulseColor.textTertiary)
            }

            Image(systemName: "chevron.right")
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(PulseColor.textTertiary)
        }
        .contentShape(Rectangle())
    }
}

struct QuickToolRow: View {
    let symbol: String
    let title: String
    let detail: String
    var tint: Color = PulseColor.accent

    var body: some View {
        HStack(spacing: 13) {
            Image(systemName: symbol)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(tint)
                .frame(width: 36, height: 36)
                .background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 11, style: .continuous))

            VStack(alignment: .leading, spacing: 1) {
                Text(title)
                    .font(PulseFont.callout.weight(.medium))
                    .foregroundStyle(PulseColor.textPrimary)
                Text(detail)
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(PulseColor.textTertiary)
        }
        .contentShape(Rectangle())
    }
}
