import SwiftUI
import SwiftData

struct TrainView: View {
    @Environment(AppState.self) private var app

    let profile: UserProfile

    @Query(sort: \Routine.createdAt, order: .reverse) private var routines: [Routine]
    @Query(sort: \WorkoutSession.startedAt, order: .reverse) private var sessions: [WorkoutSession]

    private var completedSessions: [WorkoutSession] {
        WorkoutAnalytics.completed(sessions)
    }

    private var featuredLaunch: WorkoutLaunch? {
        if let routine = routines.min(by: {
            ($0.lastUsedAt ?? .distantPast) < ($1.lastUsedAt ?? .distantPast)
        }), !routine.orderedExercises.isEmpty {
            return WorkoutLaunch(routine: routine)
        }
        let plan = WorkoutPlans.foundation
        let weekday = PulseDate.calendar.component(.weekday, from: .now)
        let index = (weekday + 5) % max(plan.days.count, 1)
        guard plan.days.indices.contains(index) else { return nil }
        return WorkoutLaunch(plan: plan, day: plan.days[index])
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                PulsePageTitle(
                    "Train",
                    eyebrow: "Your practice",
                    subtitle: "Strength, movement and a rhythm you can keep."
                )

                if profile.usesPreviewData {
                    PreviewDataBanner(compact: true)
                }

                if let launch = featuredLaunch {
                    FeaturedSessionCard(launch: launch) {
                        app.activeWorkout = launch
                    }
                }

                VStack(alignment: .leading, spacing: 12) {
                    PulseSectionHeader("Find your session", overline: "Categories")
                    LazyVGrid(
                        columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)],
                        spacing: 12
                    ) {
                        ForEach(TrainCategoryGroup.all) { group in
                            NavigationLink {
                                CategoryDetailView(group: group, profile: profile)
                            } label: {
                                CategoryTile(group: group, meta: meta(for: group))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                PulseCard(padding: 4) {
                    VStack(spacing: 0) {
                        NavigationLink {
                            ExerciseLibraryView()
                        } label: {
                            QuickToolRow(
                                symbol: "list.bullet.rectangle",
                                title: "Exercise library",
                                detail: "\(ExerciseCatalog.all.count) movements with technique cues",
                                tint: PulseColor.ringMove
                            )
                            .padding(12)
                        }
                        .buttonStyle(.plain)

                        PulseDivider().padding(.leading, 52)

                        NavigationLink {
                            RoutineLibraryView(profile: profile)
                        } label: {
                            QuickToolRow(
                                symbol: "square.stack.3d.up",
                                title: "My routines",
                                detail: "\(routines.count) saved \(routines.count == 1 ? "routine" : "routines")",
                                tint: PulseColor.ringExercise
                            )
                            .padding(12)
                        }
                        .buttonStyle(.plain)

                        PulseDivider().padding(.leading, 52)

                        NavigationLink {
                            PlansView(profile: profile)
                        } label: {
                            QuickToolRow(
                                symbol: "calendar.badge.clock",
                                title: "Training plans",
                                detail: "\(WorkoutPlans.all.count) structured programs",
                                tint: PulseColor.ringStand
                            )
                            .padding(12)
                        }
                        .buttonStyle(.plain)

                        PulseDivider().padding(.leading, 52)

                        NavigationLink {
                            WorkoutHistoryView(profile: profile)
                        } label: {
                            QuickToolRow(
                                symbol: "clock.arrow.circlepath",
                                title: "Workout history",
                                detail: "\(completedSessions.count) completed sessions",
                                tint: PulseColor.accent
                            )
                            .padding(12)
                        }
                        .buttonStyle(.plain)
                    }
                }

                VStack(alignment: .leading, spacing: 12) {
                    PulseSectionHeader("My routines", overline: "Saved")

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            NavigationLink {
                                RoutineEditorView(profile: profile)
                            } label: {
                                NewRoutineCard()
                            }
                            .buttonStyle(.plain)

                            ForEach(routines) { routine in
                                NavigationLink {
                                    RoutineDetailView(routine: routine, profile: profile)
                                } label: {
                                    RoutineSummaryCard(routine: routine, units: profile.unitSystem)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.vertical, 2)
                    }
                    .contentMargins(.horizontal, 0, for: .scrollContent)
                }

                VStack(alignment: .leading, spacing: 12) {
                    HStack(alignment: .bottom) {
                        PulseSectionHeader("Recent sessions", overline: "History")
                        Spacer()
                        NavigationLink("See all") {
                            WorkoutHistoryView(profile: profile)
                        }
                        .font(PulseFont.footnote.weight(.semibold))
                        .foregroundStyle(PulseColor.accent)
                    }

                    if completedSessions.isEmpty {
                        PulseCard {
                            PulseEmptyState(
                                symbol: "figure.run.circle",
                                title: "No sessions yet",
                                message: "Start a workout and your history, volume and personal records will build here.",
                                actionTitle: "Browse plans",
                                action: { app.selectedTab = .train },
                                compact: true
                            )
                        }
                    } else {
                        PulseCard(padding: 6) {
                            VStack(spacing: 0) {
                                ForEach(Array(completedSessions.prefix(3).enumerated()), id: \.element.id) { index, session in
                                    NavigationLink {
                                        WorkoutDetailView(session: session)
                                    } label: {
                                        WorkoutHistoryRow(session: session, units: profile.unitSystem)
                                            .padding(12)
                                    }
                                    .buttonStyle(.plain)

                                    if index < min(completedSessions.count, 3) - 1 {
                                        PulseDivider().padding(.leading, 60)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 8)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .toolbar(.hidden, for: .navigationBar)
    }

    private func meta(for group: TrainCategoryGroup) -> String {
        let routineCount = routines.filter { group.categories.contains($0.category) }.count
        let templateCount = CardioCatalog.templates(for: group.categories).count
        let planCount = WorkoutPlans.all.filter { group.categories.contains($0.category) }.count

        if group.categories == [.strength] {
            return "\(routineCount) routines · \(planCount) plans"
        }
        if planCount > 0 {
            return "\(templateCount) sessions · \(planCount) plan"
        }
        return "\(templateCount) guided sessions"
    }
}

private struct FeaturedSessionCard: View {
    let launch: WorkoutLaunch
    let onStart: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ZStack(alignment: .bottomLeading) {
                PulseGradient.hero

                PulseWaveShape()
                    .stroke(PulseColor.sage.opacity(0.22), style: StrokeStyle(lineWidth: 1.2, lineJoin: .round))
                    .frame(height: 80)
                    .padding(.horizontal, 20)
                    .offset(y: -18)

                VStack(alignment: .leading, spacing: 7) {
                    HStack(spacing: 6) {
                        Image(systemName: launch.category.symbol)
                        Text("Recommended · \(launch.category.label)")
                    }
                    .font(PulseFont.overline)
                    .tracking(1.1)
                    .textCase(.uppercase)
                    .foregroundStyle(PulseColor.sage)

                    Text(launch.title)
                        .font(PulseFont.title)
                        .foregroundStyle(PulseColor.ivory)
                        .lineLimit(2)

                    if let subtitle = launch.subtitle {
                        Text(subtitle)
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.ivory.opacity(0.65))
                            .lineLimit(2)
                    }
                }
                .padding(20)

                PulseLogo(size: 54, ringColor: PulseColor.sage, waveColor: PulseColor.ivory)
                    .padding(18)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                    .opacity(0.85)
            }
            .frame(height: 190)
            .clipShape(
                UnevenRoundedRectangle(
                    topLeadingRadius: PulseMetrics.cardRadius,
                    bottomLeadingRadius: 0,
                    bottomTrailingRadius: 0,
                    topTrailingRadius: PulseMetrics.cardRadius,
                    style: .continuous
                )
            )

            HStack(spacing: 14) {
                Label("\(launch.estimatedMinutes) min", systemImage: "clock")
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                Label("\(launch.exercises.count) exercises", systemImage: "list.bullet")
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                Spacer(minLength: 8)
                Button {
                    onStart()
                } label: {
                    Label("Start", systemImage: "play.fill")
                        .lineLimit(1)
                        .fixedSize()
                }
                .buttonStyle(PulsePrimaryButtonStyle(fullWidth: false))
                .fixedSize()
            }
            .font(PulseFont.caption)
            .foregroundStyle(PulseColor.textSecondary)
            .padding(.horizontal, 18)
            .padding(.vertical, 16)
            .background(PulseColor.surface)
        }
        .clipShape(RoundedRectangle(cornerRadius: PulseMetrics.cardRadius, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: PulseMetrics.cardRadius, style: .continuous)
                .strokeBorder(PulseColor.hairline, lineWidth: 1)
        }
        .shadow(color: PulseColor.shadow.opacity(0.35), radius: 18, x: 0, y: 10)
    }
}

private struct NewRoutineCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: "plus")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(PulseColor.accent)
                .frame(width: 40, height: 40)
                .background(PulseColor.accent.opacity(0.12), in: Circle())

            VStack(alignment: .leading, spacing: 3) {
                Text("New routine")
                    .font(PulseFont.headline)
                    .foregroundStyle(PulseColor.textPrimary)
                Text("Build it your way")
                    .font(PulseFont.footnote)
                    .foregroundStyle(PulseColor.textSecondary)
            }

            Spacer(minLength: 0)

            Text("CUSTOM")
                .pulseOverline()
                .foregroundStyle(PulseColor.textTertiary)
        }
        .padding(16)
        .frame(width: 226, height: 148, alignment: .leading)
        .background(PulseColor.surface.opacity(0.6), in: RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: PulseMetrics.tileRadius, style: .continuous)
                .strokeBorder(
                    PulseColor.hairlineStrong,
                    style: StrokeStyle(lineWidth: 1, dash: [5, 4])
                )
        }
    }
}
