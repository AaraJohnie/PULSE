import SwiftUI
import SwiftData

struct WorkoutHistoryView: View {
    @Environment(AppState.self) private var app
    @Query(sort: \WorkoutSession.startedAt, order: .reverse) private var sessions: [WorkoutSession]

    let profile: UserProfile

    private var completed: [WorkoutSession] {
        WorkoutAnalytics.completed(sessions)
    }

    private var stats: WorkoutStats {
        WorkoutAnalytics.stats(sessions)
    }

    private var groups: [(title: String, sessions: [WorkoutSession])] {
        var order: [String] = []
        var grouped: [String: [WorkoutSession]] = [:]
        for session in completed {
            let key = PulseDate.monthAndYear(session.startedAt)
            if grouped[key] == nil {
                order.append(key)
                grouped[key] = []
            }
            grouped[key]?.append(session)
        }
        return order.compactMap { key in
            guard let items = grouped[key] else { return nil }
            return (key, items)
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                if completed.isEmpty {
                    PulseCard {
                        PulseEmptyState(
                            symbol: "clock.arrow.circlepath",
                            title: "Your history starts with one session",
                            message: "Finish a workout and every set, record and calorie estimate lands here.",
                            actionTitle: "Browse plans",
                            action: { app.selectedTab = .train }
                        )
                    }
                    .padding(.top, 12)
                } else {
                    HStack(spacing: 0) {
                        historyStat(value: "\(stats.totalWorkouts)", label: "Sessions")
                        historyDivider
                        historyStat(value: "\(stats.totalMinutes)", label: "Minutes")
                        historyDivider
                        historyStat(value: UnitFormatter.volume(kg: stats.totalVolumeKg, units: profile.unitSystem), label: "Volume")
                        historyDivider
                        historyStat(value: "\(stats.currentStreak)", label: "Streak")
                    }
                    .padding(.vertical, 16)
                    .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay {
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .strokeBorder(PulseColor.hairline, lineWidth: 1)
                    }

                    ForEach(groups, id: \.title) { group in
                        VStack(alignment: .leading, spacing: 10) {
                            Text(group.title)
                                .pulseOverline()
                                .foregroundStyle(PulseColor.textTertiary)
                                .padding(.horizontal, 4)

                            PulseCard(padding: 6) {
                                VStack(spacing: 0) {
                                    ForEach(Array(group.sessions.enumerated()), id: \.element.id) { index, session in
                                        NavigationLink {
                                            WorkoutDetailView(session: session)
                                        } label: {
                                            WorkoutHistoryRow(session: session, units: profile.unitSystem)
                                                .padding(12)
                                        }
                                        .buttonStyle(.plain)

                                        if index < group.sessions.count - 1 {
                                            PulseDivider().padding(.leading, 60)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 10)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .navigationTitle("Workout history")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var historyDivider: some View {
        Divider()
            .frame(height: 28)
            .overlay(PulseColor.hairline)
    }

    private func historyStat(value: String, label: String) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(PulseFont.number(15, weight: .semibold))
                .foregroundStyle(PulseColor.textPrimary)
                .lineLimit(1)
                .minimumScaleFactor(0.65)
            Text(label)
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)
        }
        .frame(maxWidth: .infinity)
    }
}

struct WorkoutDetailView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query private var profiles: [UserProfile]

    let session: WorkoutSession

    @State private var showDeleteConfirmation = false

    private var units: UnitSystem {
        profiles.first?.unitSystem ?? .metric
    }

    private var shareText: String {
        var lines = [
            "\(session.title) — \(PulseDate.mediumDate(session.startedAt))",
            "\(session.durationMinutes) min · \(session.completedSetsCount) sets · \(session.totalReps) reps"
        ]
        if session.totalVolumeKg > 0 {
            lines.append("Volume: \(UnitFormatter.volume(kg: session.totalVolumeKg, units: units))")
        }
        if let calories = session.estimatedCalories {
            lines.append("Energy: \(UnitFormatter.energy(calories)) kcal")
        }
        if let distance = session.distanceMeters {
            lines.append("Distance: \(UnitFormatter.distance(meters: distance, units: units))")
        }
        lines.append("Logged with PULSE")
        return lines.joined(separator: "\n")
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 16) {
                    HStack {
                        PulsePillBadge(
                            text: session.category.label,
                            symbol: session.category.symbol,
                            tint: session.category.tint
                        )
                        if session.isFromWatch {
                            PulsePillBadge(text: "Apple Watch", symbol: "applewatch", tint: PulseColor.textSecondary)
                        }
                        Spacer()
                        Text(PulseDate.time(session.startedAt))
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                    }

                    Text(session.title)
                        .font(PulseFont.largeTitle)
                        .foregroundStyle(PulseColor.textPrimary)
                        .fixedSize(horizontal: false, vertical: true)

                    Text("\(PulseDate.fullDate(session.startedAt)) · \(PulseDate.time(session.startedAt))")
                        .font(PulseFont.footnote)
                        .foregroundStyle(PulseColor.textSecondary)
                }

                PulseCard(padding: 20) {
                    VStack(spacing: 18) {
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Text(PulseDate.clock(session.duration))
                                .font(PulseFont.number(38, weight: .semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                            Text("duration")
                                .font(PulseFont.footnote)
                                .foregroundStyle(PulseColor.textTertiary)
                        }

                        LazyVGrid(
                            columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())],
                            spacing: 14
                        ) {
                            detailMetric(value: "\(session.completedSetsCount)", label: "Sets")
                            detailMetric(value: "\(session.exerciseCount)", label: "Exercises")
                            detailMetric(value: "\(session.totalReps)", label: "Reps")
                            detailMetric(
                                value: session.estimatedCalories.map { UnitFormatter.energy($0) } ?? "—",
                                label: "kcal"
                            )
                            detailMetric(
                                value: session.distanceMeters.map {
                                    UnitFormatter.distancePlain(meters: $0, units: units, places: 2)
                                } ?? "—",
                                label: session.distanceMeters == nil ? "Distance" : units.distanceUnit
                            )
                            detailMetric(
                                value: session.totalVolumeKg > 0
                                    ? UnitFormatter.volume(kg: session.totalVolumeKg, units: units)
                                    : "—",
                                label: "Volume"
                            )
                        }
                    }
                }

                if let heartRate = session.averageHeartRate {
                    PulseCard(padding: 18) {
                        HStack(spacing: 12) {
                            PulseIconTile(symbol: "heart.fill", tint: PulseColor.danger, size: 38)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Heart rate")
                                    .font(PulseFont.headline)
                                    .foregroundStyle(PulseColor.textPrimary)
                                Text("Average \(Int(heartRate)) bpm\(session.maxHeartRate.map { " · max \(Int($0)) bpm" } ?? "")")
                                    .font(PulseFont.footnote)
                                    .foregroundStyle(PulseColor.textSecondary)
                            }
                            Spacer()
                        }
                    }
                }

                if !session.groupedSets.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        PulseSectionHeader("Sets", overline: "Session detail")
                        PulseCard(padding: 6) {
                            VStack(spacing: 0) {
                                ForEach(Array(session.groupedSets.enumerated()), id: \.element.exerciseID) { groupIndex, group in
                                    VStack(alignment: .leading, spacing: 8) {
                                        Text(group.name)
                                            .font(PulseFont.callout.weight(.semibold))
                                            .foregroundStyle(PulseColor.textPrimary)
                                            .padding(.top, 12)

                                        ForEach(Array(group.sets.enumerated()), id: \.element.id) { setIndex, set in
                                            HStack {
                                                Text("Set \(setIndex + 1)")
                                                    .font(PulseFont.footnote)
                                                    .foregroundStyle(PulseColor.textTertiary)
                                                Spacer()
                                                Text("\(set.reps) reps")
                                                    .font(PulseFont.footnote)
                                                    .foregroundStyle(PulseColor.textSecondary)
                                                Text(set.weightKg > 0 ? UnitFormatter.weight(kg: set.weightKg, units: units) : "Bodyweight")
                                                    .font(PulseFont.footnote.weight(.medium))
                                                    .foregroundStyle(PulseColor.textPrimary)
                                                    .frame(width: 84, alignment: .trailing)
                                            }
                                            .padding(.vertical, 2)
                                        }
                                    }
                                    .padding(.horizontal, 14)
                                    .padding(.bottom, 12)
                                    .background(alignment: .top) {
                                        if groupIndex > 0 {
                                            PulseDivider()
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if let notes = session.notes, !notes.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        PulseSectionHeader("Notes")
                        PulseCard {
                            Text(notes)
                                .font(PulseFont.callout)
                                .foregroundStyle(PulseColor.textSecondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                }

                Button(role: .destructive) {
                    showDeleteConfirmation = true
                } label: {
                    Label("Delete workout", systemImage: "trash")
                        .font(PulseFont.footnote.weight(.semibold))
                        .foregroundStyle(PulseColor.danger)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 10)
            .padding(.bottom, 32)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .navigationTitle("Workout")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                ShareLink(item: shareText) {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 13, weight: .semibold))
                }
                .accessibilityLabel("Share workout")
            }
        }
        .alert("Delete this workout?", isPresented: $showDeleteConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Delete", role: .destructive) {
                context.delete(session)
                try? context.save()
                dismiss()
            }
        } message: {
            Text("This removes the session and all of its set records from your history.")
        }
    }

    private func detailMetric(value: String, label: String) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(PulseFont.number(17, weight: .semibold))
                .foregroundStyle(PulseColor.textPrimary)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Text(label)
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)
        }
        .frame(maxWidth: .infinity)
    }
}
