import Foundation

struct WorkoutLaunch: Identifiable {
    let id = UUID()
    let title: String
    let subtitle: String?
    let category: WorkoutCategory
    let estimatedMinutes: Int
    let routineID: UUID?
    let exercises: [WorkoutLaunchExercise]

    init(
        title: String,
        subtitle: String? = nil,
        category: WorkoutCategory,
        estimatedMinutes: Int,
        routineID: UUID? = nil,
        exercises: [WorkoutLaunchExercise]
    ) {
        self.title = title
        self.subtitle = subtitle
        self.category = category
        self.estimatedMinutes = estimatedMinutes
        self.routineID = routineID
        self.exercises = exercises
    }

    init(routine: Routine) {
        let items = routine.orderedExercises.map { item in
            let exercise = ExerciseCatalog.exercise(id: item.exerciseID)
                ?? Exercise.synthesized(id: item.exerciseID, name: item.exerciseName, muscle: item.muscleGroup)
            return WorkoutLaunchExercise(
                exercise: exercise,
                sets: item.targetSets,
                reps: item.targetReps,
                weightKg: item.targetWeightKg,
                restSeconds: item.restSeconds
            )
        }
        self.init(
            title: routine.name,
            subtitle: routine.notes.isEmpty ? nil : routine.notes,
            category: routine.category,
            estimatedMinutes: routine.estimatedMinutes,
            routineID: routine.id,
            exercises: items
        )
    }

    init(plan: WorkoutPlan, day: PlanDay) {
        let items = day.exercises.compactMap { planned -> WorkoutLaunchExercise? in
            guard let exercise = ExerciseCatalog.exercise(id: planned.exerciseID) else { return nil }
            return WorkoutLaunchExercise(
                exercise: exercise,
                sets: planned.sets,
                reps: planned.reps,
                weightKg: exercise.defaultStartingWeightKg,
                restSeconds: planned.restSeconds
            )
        }
        self.init(
            title: day.title,
            subtitle: "\(plan.name) · \(day.focus)",
            category: plan.category,
            estimatedMinutes: day.estimatedMinutes,
            routineID: nil,
            exercises: items
        )
    }

    init(template: CardioTemplate) {
        self.init(
            title: template.title,
            subtitle: template.summary,
            category: template.category,
            estimatedMinutes: template.minutes,
            exercises: []
        )
    }
}

struct WorkoutLaunchExercise: Identifiable {
    let id = UUID()
    let exercise: Exercise
    let sets: Int
    let reps: Int
    let weightKg: Double
    let restSeconds: Int
}

extension Exercise {
    var defaultStartingWeightKg: Double {
        switch equipment {
        case .barbell: 20
        case .dumbbell: 8
        case .cable: 15
        case .machine: 20
        case .kettlebell: 12
        case .band, .bodyweight, .none: 0
        }
    }

    static func synthesized(id: String, name: String, muscle: MuscleGroup) -> Exercise {
        Exercise(
            id: id,
            name: name,
            category: .strength,
            muscles: [muscle],
            equipment: .bodyweight,
            instructions: []
        )
    }
}
