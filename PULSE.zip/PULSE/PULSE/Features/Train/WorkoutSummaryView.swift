import SwiftUI
import SwiftData

struct WorkoutSummaryView: View {
    @Query private var profiles: [UserProfile]

    let completion: WorkoutCompletion
    let healthState: HealthSaveState
    let onDone: () -> Void

    @State private var reveal = false

    private var session: WorkoutSession { completion.session }
    private var units: UnitSystem { profiles.first?.unitSystem ?? .metric }

    private var shareText: String {
        var lines = [
            "\(session.title) complete",
            "\(PulseDate.mediumDate(session.startedAt)) · \(session.durationMinutes) min",
            "\(session.completedSetsCount) sets · \(session.totalReps) reps"
        ]
        if session.totalVolumeKg > 0 {
            lines.append("Volume: \(UnitFormatter.volume(kg: session.totalVolumeKg, units: units))")
        }
        if let calories = session.estimatedCalories {
            lines.append("Energy: \(UnitFormatter.energy(calories)) kcal")
        }
        if let distance = session.distanceMeters {
            lines.append("Distance: \(UnitFormatter.distance(meters: distance, units: units, places: 2))")
        }
        if !completion.newRecords.isEmpty {
            lines.append("\(completion.newRecords.count) personal record\(completion.newRecords.count == 1 ? "" : "s")")
        }
        lines.append("Tracked with PULSE")
        return lines.joined(separator: "\n")
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 22) {
                completionMark

                VStack(spacing: 6) {
                    Text("Session complete")
                        .pulseOverline()
                        .foregroundStyle(PulseColor.accent)

                    Text(session.title)
                        .font(PulseFont.largeTitle)
                        .foregroundStyle(PulseColor.textPrimary)
                        .multilineTextAlignment(.center)
                        .fixedSize(horizontal: false, vertical: true)

                    Text("\(PulseDate.mediumDate(session.startedAt)) · \(PulseDate.time(session.startedAt))")
                        .font(PulseFont.footnote)
                        .foregroundStyle(PulseColor.textSecondary)
                }

                PulseCard {
                    VStack(spacing: 18) {
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Text(PulseDate.clock(session.duration))
                                .font(PulseFont.number(42, weight: .semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                            Text(session.isFromWatch ? "on Apple Watch" : "of movement")
                                .font(PulseFont.footnote)
                                .foregroundStyle(PulseColor.textTertiary)
                        }

                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) {
                            ForEach(Array(metricItems.enumerated()), id: \.offset) { pair in
                                summaryMetric(value: pair.element.value, label: pair.element.label)
                            }
                        }
                    }
                }

                if !completion.newRecords.isEmpty {
                    personalRecordsCard
                }

                healthCard

                if !session.groupedSets.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        PulseSectionHeader("What you did", overline: "Exercises")
                        PulseCard(padding: 6) {
                            VStack(spacing: 0) {
                                ForEach(Array(session.groupedSets.enumerated()), id: \.element.exerciseID) { index, group in
                                    exerciseRow(group)
                                        .padding(14)
                                    if index < session.groupedSets.count - 1 {
                                        PulseDivider().padding(.leading, 16)
                                    }
                                }
                            }
                        }
                    }
                } else if session.category == .running || session.category == .walking || session.category == .cycling {
                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: "info.circle")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(PulseColor.accent)
                        Text("Distance and heart rate from Apple Watch appear in your workout history when available.")
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(14)
                    .background(PulseColor.accent.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 28)
            .padding(.bottom, 24)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .safeAreaInset(edge: .bottom) {
            VStack(spacing: 10) {
                Button("Done", action: onDone)
                    .buttonStyle(.pulsePrimary)

                ShareLink(item: shareText) {
                    Label("Share summary", systemImage: "square.and.arrow.up")
                }
                .buttonStyle(.pulseSecondary)
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 10)
            .padding(.bottom, 10)
            .background(PulseColor.background.opacity(0.98))
            .overlay(alignment: .top) {
                PulseDivider()
            }
        }
        .onAppear {
            withAnimation(.spring(response: 0.7, dampingFraction: 0.72).delay(0.1)) {
                reveal = true
            }
        }
    }

    private var completionMark: some View {
        ZStack {
            Circle()
                .stroke(PulseColor.accent.opacity(0.14), lineWidth: 2)
                .frame(width: 128, height: 128)

            Circle()
                .trim(from: 0, to: reveal ? 1 : 0)
                .stroke(
                    PulseColor.accent,
                    style: StrokeStyle(lineWidth: 2.5, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
                .frame(width: 128, height: 128)

            Circle()
                .fill(PulseColor.accent.opacity(0.12))
                .frame(width: 104, height: 104)

            Image(systemName: "checkmark")
                .font(.system(size: 38, weight: .semibold))
                .foregroundStyle(PulseColor.accent)
                .scaleEffect(reveal ? 1 : 0.55)
                .opacity(reveal ? 1 : 0)
        }
        .padding(.top, 6)
        .accessibilityHidden(true)
    }

    private var metricItems: [(value: String, label: String)] {
        var items: [(String, String)] = [
            ("\(session.completedSetsCount)", "Sets"),
            ("\(session.exerciseCount)", "Exercises"),
            ("\(session.totalReps)", "Reps")
        ]
        if let calories = session.estimatedCalories {
            items.append((UnitFormatter.energy(calories), "Active kcal"))
        }
        if session.totalVolumeKg > 0 {
            items.append((UnitFormatter.volume(kg: session.totalVolumeKg, units: units), "Total volume"))
        }
        if let distance = session.distanceMeters {
            items.append((UnitFormatter.distance(meters: distance, units: units, places: 2), "Distance"))
        }
        if let heartRate = session.averageHeartRate {
            items.append(("\(Int(heartRate)) bpm", "Avg heart rate"))
        }
        return items
    }

    private var personalRecordsCard: some View {
        PulseCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 9) {
                    Image(systemName: "trophy.fill")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(PulseColor.warning)
                        .frame(width: 32, height: 32)
                        .background(PulseColor.warning.opacity(0.13), in: Circle())
                    VStack(alignment: .leading, spacing: 1) {
                        Text("Personal records")
                            .font(PulseFont.headline)
                            .foregroundStyle(PulseColor.textPrimary)
                        Text("Your strongest sets so far")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                    }
                }

                VStack(spacing: 0) {
                    ForEach(Array(completion.newRecords.enumerated()), id: \.element.id) { index, record in
                        HStack(spacing: 10) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(record.exerciseName)
                                    .font(PulseFont.callout.weight(.medium))
                                    .foregroundStyle(PulseColor.textPrimary)
                                Text(record.isFirst ? "First time logged" : "New best")
                                    .font(PulseFont.caption)
                                    .foregroundStyle(record.isFirst ? PulseColor.textTertiary : PulseColor.warning)
                            }
                            Spacer()
                            Text("\(UnitFormatter.weight(kg: record.weightKg, units: units)) × \(record.reps)")
                                .font(PulseFont.footnote.weight(.semibold))
                                .foregroundStyle(PulseColor.accent)
                        }
                        .padding(.vertical, 8)

                        if index < completion.newRecords.count - 1 {
                            PulseDivider()
                        }
                    }
                }
            }
        }
    }

    private var healthCard: some View {
        HStack(alignment: .top, spacing: 11) {
            Group {
                switch healthState {
                case .saving:
                    ProgressView().controlSize(.small).tint(PulseColor.accent)
                case .saved:
                    Image(systemName: "heart.fill")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(PulseColor.danger)
                case .failed:
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(PulseColor.warning)
                case .idle, .notRequested:
                    Image(systemName: "applewatch")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(PulseColor.textSecondary)
                }
            }
            .frame(width: 24)

            VStack(alignment: .leading, spacing: 2) {
                Text(healthTitle)
                    .font(PulseFont.footnote.weight(.semibold))
                    .foregroundStyle(PulseColor.textPrimary)
                Text(healthMessage)
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer(minLength: 0)
        }
        .padding(14)
        .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(PulseColor.hairline, lineWidth: 1)
        }
    }

    private var healthTitle: String {
        switch healthState {
        case .saving: "Saving to Apple Health"
        case .saved: "Saved to Apple Health"
        case .failed: "Saved in PULSE only"
        case .idle, .notRequested: "Saved in PULSE"
        }
    }

    private var healthMessage: String {
        switch healthState {
        case .saving: "Finishing your Health workout record."
        case .saved: "Your workout is now part of your Health timeline."
        case .failed: "Apple Health couldn't be updated, but this session is safe in your history."
        case .idle, .notRequested: "Connect Apple Health in You to add future workouts to Health."
        }
    }

    private func summaryMetric(value: String, label: String) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(PulseFont.number(19, weight: .semibold))
                .foregroundStyle(PulseColor.textPrimary)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Text(label)
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)
        }
        .frame(maxWidth: .infinity)
    }

    private func exerciseRow(_ group: (name: String, exerciseID: String, sets: [WorkoutSetRecord])) -> some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                Text(group.name)
                    .font(PulseFont.callout.weight(.medium))
                    .foregroundStyle(PulseColor.textPrimary)
                Text("\(group.sets.count) sets · \(group.sets.reduce(0) { $0 + $1.reps }) reps")
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
            }

            Spacer()

            if let heaviest = group.sets.map(\.weightKg).max(), heaviest > 0 {
                Text(UnitFormatter.weight(kg: heaviest, units: units))
                    .font(PulseFont.footnote.weight(.semibold))
                    .foregroundStyle(PulseColor.textSecondary)
            }
        }
    }
}
