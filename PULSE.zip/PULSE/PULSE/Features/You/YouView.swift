import SwiftUI
import SwiftData
import UniformTypeIdentifiers
import UIKit
import UserNotifications

struct YouView: View {
    @Environment(AppState.self) private var app
    @Environment(\.modelContext) private var context
    @Environment(\.openURL) private var openURL
    @Environment(\.scenePhase) private var scenePhase

    @Query(sort: \WorkoutSession.startedAt, order: .reverse) private var sessions: [WorkoutSession]
    @Query(sort: \Routine.createdAt, order: .reverse) private var routines: [Routine]
    @Query(sort: \FoodEntry.date, order: .reverse) private var meals: [FoodEntry]
    @Query(sort: \HydrationEntry.date, order: .reverse) private var hydration: [HydrationEntry]
    @Query(sort: \WeightEntry.date, order: .reverse) private var weights: [WeightEntry]

    let profile: UserProfile

    @State private var notificationStatus: UNAuthorizationStatus = .notDetermined
    @State private var isConnectingHealth = false
    @State private var exportDocument: PulseExportDocument?
    @State private var showExporter = false
    @State private var showDeleteAll = false
    @State private var showLoadPreview = false
    @State private var showClearPreview = false

    private var stats: WorkoutStats {
        WorkoutAnalytics.stats(sessions)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                identityHeader

                if profile.usesPreviewData {
                    PreviewDataBanner(compact: true)
                }

                statsCard
                goalsCard
                preferencesCard
                healthCard
                notificationsCard
                dataCard
                footer
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 8)
            .padding(.bottom, 36)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .toolbar(.hidden, for: .navigationBar)
        .task {
            notificationStatus = await NotificationService.shared.authorizationStatus()
        }
        .onChange(of: scenePhase) { _, phase in
            guard phase == .active else { return }
            Task {
                notificationStatus = await NotificationService.shared.authorizationStatus()
            }
        }
        .fileExporter(
            isPresented: $showExporter,
            document: exportDocument,
            contentType: .json,
            defaultFilename: "PULSE-export"
        ) { result in
            switch result {
            case .success:
                app.showToast("Data exported", symbol: "square.and.arrow.up")
            case .failure(let error):
                if (error as? CocoaError)?.code != .userCancelled {
                    app.showToast("Export failed. Please try again.", symbol: "exclamationmark.triangle.fill", tone: .error)
                }
            }
        }
        .alert("Delete all data?", isPresented: $showDeleteAll) {
            Button("Delete everything", role: .destructive) {
                deleteAllData()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This removes your profile, workout history, routines, meals, hydration and weight entries from this device. It cannot be undone.")
        }
        .alert("Load sample data?", isPresented: $showLoadPreview) {
            Button("Load samples", role: .destructive) {
                loadPreviewData()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Sample records replace the workouts, meals, routines and weight entries currently on this device. They are clearly labelled as preview data.")
        }
        .alert("Clear sample data?", isPresented: $showClearPreview) {
            Button("Clear everything", role: .destructive) {
                clearPreviewData()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Preview data and any records added since loading samples will be removed from this device.")
        }
    }

    // MARK: - Identity

    private var identityHeader: some View {
        HStack(alignment: .center, spacing: 14) {
            ZStack {
                Circle()
                    .fill(PulseGradient.sage)
                Text(profile.initials)
                    .font(PulseFont.number(22, weight: .semibold))
                    .foregroundStyle(PulseColor.midnight)
            }
            .frame(width: 62, height: 62)
            .overlay(Circle().strokeBorder(Color.white.opacity(0.18), lineWidth: 1))
            .accessibilityHidden(true)

            VStack(alignment: .leading, spacing: 6) {
                Text(profile.name.isEmpty ? "Athlete" : profile.name)
                    .font(PulseFont.text(28, weight: .semibold))
                    .foregroundStyle(PulseColor.textPrimary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.72)

                HStack(spacing: 6) {
                    PulsePillBadge(text: profile.level.label, tint: PulseColor.accent)
                        .lineLimit(1)
                        .fixedSize()
                    PulsePillBadge(text: profile.goal.label, tint: PulseColor.textSecondary)
                        .lineLimit(1)
                        .fixedSize()
                }
            }

            Spacer(minLength: 4)

            NavigationLink {
                ProfileEditView(profile: profile)
            } label: {
                Image(systemName: "pencil")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(PulseColor.textPrimary)
                    .frame(width: 40, height: 40)
                    .background(PulseColor.surface, in: Circle())
                    .overlay(Circle().strokeBorder(PulseColor.hairline, lineWidth: 1))
            }
            .accessibilityLabel("Edit profile")
        }
    }

    private var statsCard: some View {
        PulseCard {
            HStack(spacing: 0) {
                statColumn("\(stats.totalWorkouts)", label: "Workouts")
                statDivider
                statColumn("\(stats.currentStreak)", label: "Day streak")
                statDivider
                statColumn("\(stats.workoutsThisWeek)", label: "This week")
            }
        }
    }

    private var statDivider: some View {
        Rectangle()
            .fill(PulseColor.hairline)
            .frame(width: 1, height: 36)
    }

    private func statColumn(_ value: String, label: String) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(PulseFont.number(24, weight: .semibold))
                .foregroundStyle(PulseColor.textPrimary)
            Text(label)
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)
        }
        .frame(maxWidth: .infinity)
        .accessibilityElement(children: .combine)
    }

    // MARK: - Goals

    private var goalsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            PulseSectionHeader("Goals & targets", overline: "Daily")

            NavigationLink {
                TargetsView(profile: profile)
            } label: {
                PulseCard {
                    VStack(spacing: 14) {
                        HStack {
                            VStack(alignment: .leading, spacing: 3) {
                                Text("\(UnitFormatter.integer(Double(profile.calorieGoal))) kcal")
                                    .font(PulseFont.number(26, weight: .semibold))
                                    .foregroundStyle(PulseColor.textPrimary)
                                Text("Calorie target · \(profile.goal.label.lowercased())")
                                    .font(PulseFont.caption)
                                    .foregroundStyle(PulseColor.textTertiary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(PulseColor.textTertiary)
                        }

                        HStack(spacing: 0) {
                            macroTarget("Protein", value: profile.proteinGoalG, tint: PulseColor.ringMove)
                            macroTarget("Carbs", value: profile.carbsGoalG, tint: PulseColor.ringExercise)
                            macroTarget("Fat", value: profile.fatGoalG, tint: PulseColor.ringStand)
                        }

                        PulseDivider()

                        HStack {
                            HStack(spacing: 8) {
                                Image(systemName: "drop.fill")
                                    .font(.system(size: 12, weight: .semibold))
                                    .foregroundStyle(PulseColor.ringStand)
                                Text("Hydration")
                                    .font(PulseFont.footnote)
                                    .foregroundStyle(PulseColor.textSecondary)
                            }
                            Spacer()
                            Text(UnitFormatter.waterGoal(ml: Double(profile.hydrationGoalMl), units: profile.unitSystem))
                                .font(PulseFont.footnote.weight(.semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                        }
                    }
                }
            }
            .buttonStyle(.plain)
        }
    }

    private func macroTarget(_ title: String, value: Int, tint: Color) -> some View {
        VStack(spacing: 3) {
            Text("\(value) g")
                .font(PulseFont.number(17, weight: .semibold))
                .foregroundStyle(PulseColor.textPrimary)
            Text(title)
                .font(PulseFont.caption)
                .foregroundStyle(tint)
        }
        .frame(maxWidth: .infinity)
        .accessibilityElement(children: .combine)
    }

    // MARK: - Preferences

    private var preferencesCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            PulseSectionHeader("Preferences", overline: "Experience")

            PulseCard {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 9) {
                        preferenceTitle("Units", symbol: "ruler")
                        PulseSegmentedControl(
                            items: UnitSystem.allCases,
                            label: \.label,
                            selection: Binding(
                                get: { profile.unitSystem },
                                set: { newValue in
                                    profile.unitSystem = newValue
                                    profile.updatedAt = .now
                                    try? context.save()
                                    Haptics.selection()
                                }
                            )
                        )
                        Text(profile.unitSystem.detail)
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                    }

                    PulseDivider()

                    VStack(alignment: .leading, spacing: 9) {
                        preferenceTitle("Appearance", symbol: "circle.lefthalf.filled")
                        PulseSegmentedControl(
                            items: AppearanceMode.allCases,
                            label: \.label,
                            selection: Binding(
                                get: { profile.appearance },
                                set: { newValue in
                                    profile.appearance = newValue
                                    profile.updatedAt = .now
                                    try? context.save()
                                    Haptics.selection()
                                }
                            )
                        )
                        Text("System follows your iPhone's light and dark setting.")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                    }
                }
            }
        }
    }

    private func preferenceTitle(_ title: String, symbol: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: symbol)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(PulseColor.accent)
            Text(title)
                .font(PulseFont.footnote.weight(.semibold))
                .foregroundStyle(PulseColor.textSecondary)
        }
    }

    // MARK: - Apple Health

    private var healthCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            PulseSectionHeader("Apple Health", overline: "Permissions")

            PulseCard {
                VStack(alignment: .leading, spacing: 14) {
                    HStack(spacing: 12) {
                        PulseIconTile(symbol: "heart.fill", tint: PulseColor.danger, size: 38)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Apple Health")
                                .font(PulseFont.headline)
                                .foregroundStyle(PulseColor.textPrimary)
                            Text(healthStatusDetail)
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                        Spacer()
                        PulsePillBadge(
                            text: healthBadge,
                            symbol: app.health.accessState == .requested ? "checkmark" : nil,
                            tint: app.health.accessState == .requested ? PulseColor.accent : PulseColor.textTertiary
                        )
                    }

                    Text("PULSE reads steps, active energy, exercise minutes, distance and stand hours, and saves workouts you complete. Health data stays on your device.")
                        .font(PulseFont.footnote)
                        .foregroundStyle(PulseColor.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)

                    if profile.usesPreviewData, app.health.accessState == .requested {
                        HStack(alignment: .top, spacing: 8) {
                            Image(systemName: "info.circle.fill")
                                .font(.system(size: 12))
                                .foregroundStyle(PulseColor.warning)
                            Text("Preview data is currently shown instead of live Health data. Clear samples in Data & privacy to see your own activity.")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textSecondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }

                    if app.health.accessState == .unavailable {
                        Text("Apple Health isn't available on this device.")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                    } else if app.health.accessState == .requested {
                        HStack(spacing: 10) {
                            Button {
                                refreshHealth()
                            } label: {
                                HStack(spacing: 7) {
                                    if app.health.isLoading {
                                        ProgressView()
                                            .controlSize(.small)
                                            .tint(PulseColor.textPrimary)
                                    } else {
                                        Image(systemName: "arrow.triangle.2.circlepath")
                                    }
                                    Text(app.health.isLoading ? "Syncing…" : "Refresh data")
                                }
                                .font(PulseFont.footnote.weight(.semibold))
                                .foregroundStyle(PulseColor.textPrimary)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 11)
                                .background(PulseColor.surfaceMuted, in: Capsule())
                            }
                            .buttonStyle(.plain)
                            .disabled(app.health.isLoading)
                        }

                        if let lastRefresh = app.health.lastRefresh {
                            Text("Last synced \(PulseDate.time(lastRefresh))")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                    } else {
                        Button {
                            connectHealth()
                        } label: {
                            HStack(spacing: 7) {
                                if isConnectingHealth {
                                    ProgressView()
                                        .controlSize(.small)
                                        .tint(PulseColor.midnight)
                                }
                                Text(isConnectingHealth ? "Connecting…" : "Connect Apple Health")
                            }
                        }
                        .buttonStyle(.pulsePrimary)
                        .disabled(isConnectingHealth)
                    }
                }
            }
        }
    }

    private var healthBadge: String {
        switch app.health.accessState {
        case .requested: "Connected"
        case .unavailable: "Unavailable"
        case .notRequested, .unknown: "Off"
        }
    }

    private var healthStatusDetail: String {
        switch app.health.accessState {
        case .requested:
            return profile.healthKitRequested ? "Read and write access requested" : "Access granted"
        case .unavailable:
            return "Not supported on this device"
        case .notRequested, .unknown:
            return "Not connected"
        }
    }

    private func connectHealth() {
        guard !isConnectingHealth else { return }
        isConnectingHealth = true
        Task {
            profile.healthKitRequested = true
            profile.updatedAt = .now
            try? context.save()
            let granted = await app.health.requestAuthorization()
            isConnectingHealth = false
            if granted {
                app.showToast("Apple Health connected", symbol: "heart.fill")
            } else {
                app.showToast(
                    app.health.lastError ?? "Apple Health could not be reached.",
                    symbol: "heart.slash",
                    tone: .error
                )
            }
        }
    }

    private func refreshHealth() {
        Task {
            await app.health.refresh(days: 30, force: true)
            Haptics.success()
            app.showToast("Health data refreshed", symbol: "arrow.triangle.2.circlepath")
        }
    }

    // MARK: - Notifications

    private var notificationsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            PulseSectionHeader("Notifications", overline: "Alerts & reminders")

            PulseCard {
                VStack(alignment: .leading, spacing: 14) {
                    Toggle(isOn: notificationsBinding) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Allow notifications")
                                .font(PulseFont.callout.weight(.medium))
                                .foregroundStyle(PulseColor.textPrimary)
                            Text("Rest timers and daily reminders.")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                    }
                    .tint(PulseColor.accent)

                    PulseDivider()

                    Toggle(isOn: restTimerNotificationsBinding) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Rest timer alerts")
                                .font(PulseFont.callout.weight(.medium))
                                .foregroundStyle(profile.notificationsEnabled ? PulseColor.textPrimary : PulseColor.textTertiary)
                            Text("Notify you when a rest period ends.")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                    }
                    .tint(PulseColor.accent)
                    .disabled(!profile.notificationsEnabled)

                    PulseDivider()

                    Toggle(isOn: remindersBinding) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Daily workout reminder")
                                .font(PulseFont.callout.weight(.medium))
                                .foregroundStyle(profile.notificationsEnabled ? PulseColor.textPrimary : PulseColor.textTertiary)
                            Text("A gentle nudge at 6:00 PM each day.")
                                .font(PulseFont.caption)
                                .foregroundStyle(PulseColor.textTertiary)
                        }
                    }
                    .tint(PulseColor.accent)
                    .disabled(!profile.notificationsEnabled)

                    if notificationStatus == .denied {
                        HStack(alignment: .top, spacing: 8) {
                            Image(systemName: "bell.slash.fill")
                                .font(.system(size: 12))
                                .foregroundStyle(PulseColor.warning)
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Notifications are turned off in iOS Settings.")
                                    .font(PulseFont.caption)
                                    .foregroundStyle(PulseColor.textSecondary)
                                    .fixedSize(horizontal: false, vertical: true)
                                Button("Open iOS Settings") {
                                    openNotificationSettings()
                                }
                                .font(PulseFont.caption.weight(.semibold))
                                .foregroundStyle(PulseColor.accent)
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
            }
        }
    }

    private var notificationsBinding: Binding<Bool> {
        Binding(
            get: { profile.notificationsEnabled },
            set: { enabled in
                profile.notificationsEnabled = enabled
                profile.updatedAt = .now
                if enabled {
                    Task {
                        let granted = await NotificationService.shared.requestAuthorization()
                        notificationStatus = await NotificationService.shared.authorizationStatus()
                        if granted {
                            try? context.save()
                            app.showToast("Notifications enabled", symbol: "bell.fill")
                        } else {
                            profile.notificationsEnabled = false
                            profile.workoutRemindersEnabled = false
                            try? context.save()
                            app.showToast(
                                "Notifications are blocked. Enable them in iOS Settings.",
                                symbol: "bell.slash.fill",
                                tone: .error
                            )
                        }
                    }
                } else {
                    profile.workoutRemindersEnabled = false
                    try? context.save()
                    Task {
                        _ = await NotificationService.shared.setWorkoutReminders(enabled: false)
                    }
                }
            }
        )
    }

    private var restTimerNotificationsBinding: Binding<Bool> {
        Binding(
            get: { profile.restTimerNotificationsEnabled },
            set: { enabled in
                profile.restTimerNotificationsEnabled = enabled
                profile.updatedAt = .now
                try? context.save()
            }
        )
    }

    private var remindersBinding: Binding<Bool> {
        Binding(
            get: { profile.workoutRemindersEnabled },
            set: { enabled in
                profile.workoutRemindersEnabled = enabled
                profile.updatedAt = .now
                Task {
                    let success = await NotificationService.shared.setWorkoutReminders(enabled: enabled)
                    notificationStatus = await NotificationService.shared.authorizationStatus()
                    if success {
                        try? context.save()
                    } else {
                        profile.workoutRemindersEnabled = false
                        try? context.save()
                        app.showToast(
                            "Allow notifications before setting a reminder.",
                            symbol: "bell.slash.fill",
                            tone: .error
                        )
                    }
                }
            }
        )
    }

    private func openNotificationSettings() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
        openURL(url)
    }

    // MARK: - Data & privacy

    private var dataCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            PulseSectionHeader("Data & privacy", overline: "You are in control")

            PulseCard(padding: 6) {
                VStack(spacing: 0) {
                    actionRow(
                        symbol: "square.and.arrow.up",
                        title: "Export my data",
                        detail: "Profile, workouts, meals, water and weight as JSON",
                        tint: PulseColor.accent
                    ) {
                        exportData()
                    }

                    PulseDivider().padding(.leading, 54)

                    actionRow(
                        symbol: "sparkles",
                        title: profile.usesPreviewData ? "Reload sample data" : "Load sample data",
                        detail: "Explore PULSE with clearly labelled demo records",
                        tint: PulseColor.ringExercise
                    ) {
                        showLoadPreview = true
                    }

                    if profile.usesPreviewData {
                        PulseDivider().padding(.leading, 54)

                        actionRow(
                            symbol: "eraser",
                            title: "Clear sample data",
                            detail: "Remove demo records and return to your own data",
                            tint: PulseColor.textSecondary
                        ) {
                            showClearPreview = true
                        }
                    }

                    PulseDivider().padding(.leading, 54)

                    actionRow(
                        symbol: "trash",
                        title: "Delete all data",
                        detail: "Reset PULSE and remove everything from this device",
                        tint: PulseColor.danger
                    ) {
                        showDeleteAll = true
                    }
                }
            }

            Text("PULSE stores your profile and records on this device. Nothing is uploaded. Exports are created only when you ask.")
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)
                .padding(.horizontal, 4)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private func actionRow(
        symbol: String,
        title: String,
        detail: String,
        tint: Color,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: symbol)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(tint)
                    .frame(width: 34, height: 34)
                    .background(tint.opacity(0.10), in: RoundedRectangle(cornerRadius: 10, style: .continuous))

                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(PulseFont.callout.weight(.medium))
                        .foregroundStyle(tint == PulseColor.danger ? PulseColor.danger : PulseColor.textPrimary)
                    Text(detail)
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.textTertiary)
                        .fixedSize(horizontal: false, vertical: true)
                        .multilineTextAlignment(.leading)
                }

                Spacer(minLength: 8)

                Image(systemName: "chevron.right")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(PulseColor.textTertiary)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 12)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private var footer: some View {
        VStack(spacing: 6) {
            PulseLogo(size: 26, ringColor: PulseColor.accent, waveColor: PulseColor.textSecondary)
            Text("PULSE 1.0")
                .pulseOverline()
                .foregroundStyle(PulseColor.textTertiary)
            Text("Your Health. Your Rhythm. Your Progress.")
                .font(PulseFont.caption)
                .foregroundStyle(PulseColor.textTertiary)
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 10)
    }

    // MARK: - Actions

    private func exportData() {
        let payload = PulseExportPayload(
            generatedAt: .now,
            usesPreviewData: profile.usesPreviewData,
            profile: PulseExportPayload.Profile(
                name: profile.name,
                age: profile.age,
                heightCm: profile.heightCm,
                weightKg: profile.weightKg,
                level: profile.level.label,
                goal: profile.goal.label,
                activities: profile.activities.map(\.label),
                unitSystem: profile.unitSystem.label,
                calorieGoal: profile.calorieGoal,
                proteinGoalG: profile.proteinGoalG,
                carbsGoalG: profile.carbsGoalG,
                fatGoalG: profile.fatGoalG,
                hydrationGoalMl: profile.hydrationGoalMl,
                createdAt: profile.createdAt
            ),
            workouts: sessions.map { session in
                PulseExportPayload.Workout(
                    id: session.id,
                    title: session.title,
                    category: session.category.label,
                    startedAt: session.startedAt,
                    endedAt: session.endedAt,
                    durationMinutes: session.durationMinutes,
                    status: session.status.rawValue,
                    totalVolumeKg: session.totalVolumeKg,
                    estimatedCalories: session.estimatedCalories,
                    averageHeartRate: session.averageHeartRate,
                    maxHeartRate: session.maxHeartRate,
                    distanceMeters: session.distanceMeters,
                    notes: session.notes,
                    isFromWatch: session.isFromWatch,
                    sets: session.sets.map { set in
                        PulseExportPayload.WorkoutSet(
                            exerciseID: set.exerciseID,
                            exerciseName: set.exerciseName,
                            muscleGroup: set.muscleGroup.label,
                            setIndex: set.setIndex,
                            reps: set.reps,
                            weightKg: set.weightKg,
                            completedAt: set.completedAt
                        )
                    }
                )
            },
            routines: routines.map { routine in
                PulseExportPayload.Routine(
                    id: routine.id,
                    name: routine.name,
                    notes: routine.notes,
                    category: routine.category.label,
                    estimatedMinutes: routine.estimatedMinutes,
                    exercises: routine.orderedExercises.map { exercise in
                        PulseExportPayload.RoutineExercise(
                            exerciseID: exercise.exerciseID,
                            exerciseName: exercise.exerciseName,
                            sets: exercise.targetSets,
                            reps: exercise.targetReps,
                            weightKg: exercise.targetWeightKg,
                            restSeconds: exercise.restSeconds
                        )
                    }
                )
            },
            meals: meals.map { entry in
                PulseExportPayload.Meal(
                    date: entry.date,
                    meal: entry.meal.label,
                    name: entry.name,
                    calories: entry.calories,
                    proteinG: entry.proteinG,
                    carbsG: entry.carbsG,
                    fatG: entry.fatG,
                    servings: entry.servings,
                    servingDescription: entry.servingDescription
                )
            },
            hydration: hydration.map { entry in
                PulseExportPayload.Hydration(date: entry.date, amountMl: entry.amountMl)
            },
            weights: weights.map { entry in
                PulseExportPayload.Weight(date: entry.date, weightKg: entry.weightKg)
            }
        )

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        guard let data = try? encoder.encode(payload) else {
            app.showToast("Couldn't prepare your export.", symbol: "exclamationmark.triangle.fill", tone: .error)
            return
        }
        exportDocument = PulseExportDocument(data: data)
        showExporter = true
    }

    private func loadPreviewData() {
        PreviewData.seed(in: context, profile: profile)
        Haptics.success()
        app.showToast("Sample data loaded", symbol: "sparkles")
    }

    private func clearPreviewData() {
        PreviewData.clearPreviewData(in: context, profile: profile)
        Haptics.tap()
        app.showToast("Sample data cleared", symbol: "eraser")
    }

    private func deleteAllData() {
        for entry in meals { context.delete(entry) }
        for entry in hydration { context.delete(entry) }
        for entry in weights { context.delete(entry) }
        for session in sessions { context.delete(session) }
        for routine in routines { context.delete(routine) }
        context.delete(profile)
        try? context.save()
        Haptics.tap()
        app.showToast("All data deleted", symbol: "trash")
    }
}

// MARK: - Profile editor

struct ProfileEditView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Environment(AppState.self) private var app

    let profile: UserProfile

    @State private var name: String
    @State private var age: Int
    @State private var heightDisplay: Double
    @State private var weightDisplay: Double
    @State private var level: FitnessLevel
    @State private var goal: FitnessGoal
    @State private var activities: Set<ActivityPreference>

    init(profile: UserProfile) {
        self.profile = profile
        _name = State(initialValue: profile.name)
        _age = State(initialValue: profile.age)
        _heightDisplay = State(
            initialValue: UnitFormatter.heightValue(cm: profile.heightCm, units: profile.unitSystem)
        )
        _weightDisplay = State(
            initialValue: UnitFormatter.weightValue(kg: profile.weightKg, units: profile.unitSystem)
        )
        _level = State(initialValue: profile.level)
        _goal = State(initialValue: profile.goal)
        _activities = State(initialValue: Set(profile.activities))
    }

    private var units: UnitSystem { profile.unitSystem }

    private var trimmedName: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var canSave: Bool {
        trimmedName.count >= 2 && !activities.isEmpty
    }

    private var heightRange: ClosedRange<Double> {
        units == .metric ? 120...220 : 47...87
    }

    private var weightRange: ClosedRange<Double> {
        units == .metric ? 35...200 : 77...440
    }

    private var heightValueText: String {
        if units == .metric {
            return "\(Int(heightDisplay.rounded())) cm"
        }
        let parts = UnitFormatter.heightParts(cm: heightDisplay * 2.54, units: .imperial)
        return "\(parts.primary)′ \(parts.secondary ?? 0)″"
    }

    private var weightValueText: String {
        "\(UnitFormatter.decimal(weightDisplay, places: 1)) \(units.weightUnit)"
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                PulseField(
                    title: "Name",
                    placeholder: "How should we greet you?",
                    text: $name,
                    capitalization: .words,
                    error: trimmedName.count < 2 ? "Use at least two characters." : nil
                )

                PulseCounter(title: "Age", value: $age, range: 13...100, step: 1, unit: "years")

                PulseValueSlider(
                    title: "Height",
                    valueText: heightValueText,
                    value: $heightDisplay,
                    range: heightRange,
                    step: units == .metric ? 1 : 0.5,
                    minimumLabel: heightLabel(for: heightRange.lowerBound),
                    maximumLabel: heightLabel(for: heightRange.upperBound)
                )

                PulseValueSlider(
                    title: "Weight",
                    valueText: weightValueText,
                    value: $weightDisplay,
                    range: weightRange,
                    step: 0.5,
                    minimumLabel: weightLabel(for: weightRange.lowerBound),
                    maximumLabel: weightLabel(for: weightRange.upperBound)
                )

                VStack(alignment: .leading, spacing: 10) {
                    Text("Fitness level")
                        .pulseOverline()
                        .foregroundStyle(PulseColor.textTertiary)

                    VStack(spacing: 8) {
                        ForEach(FitnessLevel.allCases) { option in
                            optionRow(
                                symbol: option.symbol,
                                title: option.label,
                                detail: option.detail,
                                isSelected: level == option
                            ) {
                                level = option
                                Haptics.selection()
                            }
                        }
                    }
                }

                VStack(alignment: .leading, spacing: 10) {
                    Text("Primary goal")
                        .pulseOverline()
                        .foregroundStyle(PulseColor.textTertiary)

                    VStack(spacing: 8) {
                        ForEach(FitnessGoal.allCases) { option in
                            optionRow(
                                symbol: option.symbol,
                                title: option.label,
                                detail: option.detail,
                                isSelected: goal == option
                            ) {
                                goal = option
                                Haptics.selection()
                            }
                        }
                    }
                }

                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("Activities")
                            .pulseOverline()
                            .foregroundStyle(PulseColor.textTertiary)
                        Spacer()
                        Text("\(activities.count) selected")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.textTertiary)
                    }

                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)], spacing: 8) {
                        ForEach(ActivityPreference.allCases) { activity in
                            let selected = activities.contains(activity)
                            Button {
                                if selected {
                                    activities.remove(activity)
                                } else {
                                    activities.insert(activity)
                                }
                                Haptics.selection()
                            } label: {
                                HStack(spacing: 8) {
                                    Image(systemName: activity.symbol)
                                        .font(.system(size: 13, weight: .semibold))
                                    Text(activity.label)
                                        .font(PulseFont.footnote.weight(.medium))
                                    Spacer(minLength: 0)
                                    if selected {
                                        Image(systemName: "checkmark")
                                            .font(.system(size: 10, weight: .bold))
                                    }
                                }
                                .foregroundStyle(selected ? PulseColor.midnight : PulseColor.textSecondary)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 12)
                                .background(
                                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                                        .fill(selected ? PulseColor.sage : PulseColor.surface)
                                )
                                .overlay(
                                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                                        .strokeBorder(selected ? Color.clear : PulseColor.hairline, lineWidth: 1)
                                )
                            }
                            .buttonStyle(.plain)
                            .accessibilityAddTraits(selected ? .isSelected : [])
                        }
                    }

                    if activities.isEmpty {
                        Text("Choose at least one activity to continue.")
                            .font(PulseFont.caption)
                            .foregroundStyle(PulseColor.danger)
                    }
                }

                Text("Saving recalculates your daily calorie, macro and hydration targets from your updated profile. Manual target edits in Goals & targets will be replaced.")
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 12)
            .padding(.bottom, 24)
        }
        .scrollIndicators(.hidden)
        .scrollDismissesKeyboard(.interactively)
        .pulseScreen()
        .navigationTitle("Edit profile")
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom) {
            Button("Save profile") {
                save()
            }
            .buttonStyle(.pulsePrimary)
            .disabled(!canSave)
            .opacity(canSave ? 1 : 0.45)
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.vertical, 12)
            .background(.ultraThinMaterial)
        }
    }

    private func heightLabel(for value: Double) -> String {
        if units == .metric {
            return "\(Int(value)) cm"
        }
        let parts = UnitFormatter.heightParts(cm: value * 2.54, units: .imperial)
        return "\(parts.primary)′ \(parts.secondary ?? 0)″"
    }

    private func weightLabel(for value: Double) -> String {
        "\(UnitFormatter.decimal(value, places: 0)) \(units.weightUnit)"
    }

    private func optionRow(
        symbol: String,
        title: String,
        detail: String,
        isSelected: Bool,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: symbol)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(isSelected ? PulseColor.midnight : PulseColor.accent)
                    .frame(width: 34, height: 34)
                    .background(
                        isSelected ? PulseColor.sage : PulseColor.accentSoft,
                        in: RoundedRectangle(cornerRadius: 10, style: .continuous)
                    )

                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(PulseFont.callout.weight(.medium))
                        .foregroundStyle(PulseColor.textPrimary)
                    Text(detail)
                        .font(PulseFont.caption)
                        .foregroundStyle(PulseColor.textTertiary)
                        .fixedSize(horizontal: false, vertical: true)
                        .multilineTextAlignment(.leading)
                }

                Spacer(minLength: 6)

                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(isSelected ? PulseColor.accent : PulseColor.hairlineStrong)
            }
            .padding(12)
            .background(PulseColor.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .strokeBorder(isSelected ? PulseColor.accent.opacity(0.55) : PulseColor.hairline, lineWidth: 1)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(isSelected ? .isSelected : [])
    }

    private func save() {
        guard canSave else { return }
        let heightCm = units == .metric ? heightDisplay : heightDisplay * 2.54
        let weightKg = units == .metric ? weightDisplay : weightDisplay / 2.2046226218

        profile.name = trimmedName
        profile.age = age
        profile.heightCm = heightCm
        profile.weightKg = weightKg
        profile.level = level
        profile.goal = goal
        profile.activities = Array(activities)
        profile.recalculateTargets()
        profile.updatedAt = .now
        try? context.save()
        Haptics.success()
        app.showToast("Profile updated", symbol: "person.crop.circle.fill")
        dismiss()
    }
}

// MARK: - Targets

struct TargetsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Environment(AppState.self) private var app

    let profile: UserProfile

    @State private var calorieGoal: Double
    @State private var proteinGoal: Double
    @State private var carbsGoal: Double
    @State private var fatGoal: Double
    @State private var hydrationGoal: Double

    init(profile: UserProfile) {
        self.profile = profile
        _calorieGoal = State(initialValue: Double(profile.calorieGoal))
        _proteinGoal = State(initialValue: Double(profile.proteinGoalG))
        _carbsGoal = State(initialValue: Double(profile.carbsGoalG))
        _fatGoal = State(initialValue: Double(profile.fatGoalG))
        _hydrationGoal = State(initialValue: Double(profile.hydrationGoalMl))
    }

    private var macroCalories: Double {
        proteinGoal * 4 + carbsGoal * 4 + fatGoal * 9
    }

    private var macroDifference: Double {
        macroCalories - calorieGoal
    }

    private var balanceLabel: String {
        if abs(macroDifference) <= 80 {
            return "Macros are balanced with your energy target."
        }
        if macroDifference > 0 {
            return "Your macro targets total \(UnitFormatter.integer(abs(macroDifference))) kcal above your calorie goal."
        }
        return "Your macro targets total \(UnitFormatter.integer(abs(macroDifference))) kcal below your calorie goal."
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                PulseValueSlider(
                    title: "Calories",
                    valueText: "\(UnitFormatter.integer(calorieGoal)) kcal",
                    value: $calorieGoal,
                    range: 1400...4200,
                    step: 50,
                    minimumLabel: "1,400 kcal",
                    maximumLabel: "4,200 kcal"
                )

                VStack(alignment: .leading, spacing: 12) {
                    PulseValueSlider(
                        title: "Protein",
                        valueText: "\(UnitFormatter.integer(proteinGoal)) g",
                        value: $proteinGoal,
                        range: 60...300,
                        step: 5,
                        minimumLabel: "60 g",
                        maximumLabel: "300 g"
                    )
                    PulseValueSlider(
                        title: "Carbs",
                        valueText: "\(UnitFormatter.integer(carbsGoal)) g",
                        value: $carbsGoal,
                        range: 50...500,
                        step: 5,
                        minimumLabel: "50 g",
                        maximumLabel: "500 g"
                    )
                    PulseValueSlider(
                        title: "Fat",
                        valueText: "\(UnitFormatter.integer(fatGoal)) g",
                        value: $fatGoal,
                        range: 30...200,
                        step: 5,
                        minimumLabel: "30 g",
                        maximumLabel: "200 g"
                    )
                }

                PulseCard {
                    HStack(spacing: 10) {
                        Image(systemName: abs(macroDifference) <= 80 ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(abs(macroDifference) <= 80 ? PulseColor.accent : PulseColor.warning)
                        Text(balanceLabel)
                            .font(PulseFont.footnote)
                            .foregroundStyle(PulseColor.textSecondary)
                            .fixedSize(horizontal: false, vertical: true)
                        Spacer(minLength: 0)
                    }
                }

                PulseValueSlider(
                    title: "Hydration",
                    valueText: UnitFormatter.waterGoal(ml: hydrationGoal, units: profile.unitSystem),
                    value: $hydrationGoal,
                    range: 1500...4500,
                    step: 50,
                    minimumLabel: UnitFormatter.waterGoal(ml: 1500, units: profile.unitSystem),
                    maximumLabel: UnitFormatter.waterGoal(ml: 4500, units: profile.unitSystem)
                )

                Button {
                    applyRecommendations()
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "arrow.counterclockwise")
                        Text("Use profile recommendation")
                    }
                    .font(PulseFont.footnote.weight(.semibold))
                    .foregroundStyle(PulseColor.accent)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(PulseColor.accentSoft, in: Capsule())
                }
                .buttonStyle(.plain)

                Text("Targets guide your day but never block a meal. Macros are calculated at 4 kcal per gram of protein and carbs, and 9 kcal per gram of fat.")
                    .font(PulseFont.caption)
                    .foregroundStyle(PulseColor.textTertiary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.top, 12)
            .padding(.bottom, 24)
        }
        .scrollIndicators(.hidden)
        .pulseScreen()
        .navigationTitle("Daily targets")
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom) {
            Button("Save targets") {
                save()
            }
            .buttonStyle(.pulsePrimary)
            .padding(.horizontal, PulseMetrics.screenPadding)
            .padding(.vertical, 12)
            .background(.ultraThinMaterial)
        }
    }

    private func applyRecommendations() {
        let reference = UserProfile(
            name: profile.name,
            age: profile.age,
            heightCm: profile.heightCm,
            weightKg: profile.weightKg,
            level: profile.level,
            goal: profile.goal,
            activities: profile.activities,
            unitSystem: profile.unitSystem
        )
        reference.recalculateTargets()

        withAnimation(.snappy(duration: 0.25)) {
            calorieGoal = Double(reference.calorieGoal)
            proteinGoal = Double(reference.proteinGoalG)
            carbsGoal = Double(reference.carbsGoalG)
            fatGoal = Double(reference.fatGoalG)
            hydrationGoal = Double(reference.hydrationGoalMl)
        }
        Haptics.selection()
        app.showToast("Recommendations applied — save to keep", symbol: "sparkles")
    }

    private func save() {
        profile.calorieGoal = Int(calorieGoal)
        profile.proteinGoalG = Int(proteinGoal)
        profile.carbsGoalG = Int(carbsGoal)
        profile.fatGoalG = Int(fatGoal)
        profile.hydrationGoalMl = Int(hydrationGoal)
        profile.updatedAt = .now
        try? context.save()
        Haptics.success()
        app.showToast("Targets updated", symbol: "target")
        dismiss()
    }
}

// MARK: - Export document

struct PulseExportDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }

    var data: Data

    init(data: Data) {
        self.data = data
    }

    init(configuration: ReadConfiguration) throws {
        guard let contents = configuration.file.regularFileContents else {
            throw CocoaError(.fileReadCorruptFile)
        }
        data = contents
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

struct PulseExportPayload: Encodable {
    struct Profile: Encodable {
        let name: String
        let age: Int
        let heightCm: Double
        let weightKg: Double
        let level: String
        let goal: String
        let activities: [String]
        let unitSystem: String
        let calorieGoal: Int
        let proteinGoalG: Int
        let carbsGoalG: Int
        let fatGoalG: Int
        let hydrationGoalMl: Int
        let createdAt: Date
    }

    struct WorkoutSet: Encodable {
        let exerciseID: String
        let exerciseName: String
        let muscleGroup: String
        let setIndex: Int
        let reps: Int
        let weightKg: Double
        let completedAt: Date
    }

    struct Workout: Encodable {
        let id: UUID
        let title: String
        let category: String
        let startedAt: Date
        let endedAt: Date?
        let durationMinutes: Int
        let status: String
        let totalVolumeKg: Double
        let estimatedCalories: Double?
        let averageHeartRate: Double?
        let maxHeartRate: Double?
        let distanceMeters: Double?
        let notes: String?
        let isFromWatch: Bool
        let sets: [WorkoutSet]
    }

    struct RoutineExercise: Encodable {
        let exerciseID: String
        let exerciseName: String
        let sets: Int
        let reps: Int
        let weightKg: Double
        let restSeconds: Int
    }

    struct Routine: Encodable {
        let id: UUID
        let name: String
        let notes: String
        let category: String
        let estimatedMinutes: Int
        let exercises: [RoutineExercise]
    }

    struct Meal: Encodable {
        let date: Date
        let meal: String
        let name: String
        let calories: Double
        let proteinG: Double
        let carbsG: Double
        let fatG: Double
        let servings: Double
        let servingDescription: String
    }

    struct Hydration: Encodable {
        let date: Date
        let amountMl: Double
    }

    struct Weight: Encodable {
        let date: Date
        let weightKg: Double
    }

    let generatedAt: Date
    let usesPreviewData: Bool
    let profile: Profile
    let workouts: [Workout]
    let routines: [Routine]
    let meals: [Meal]
    let hydration: [Hydration]
    let weights: [Weight]
}
