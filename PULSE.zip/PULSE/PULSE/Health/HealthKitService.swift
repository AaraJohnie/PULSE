import Foundation
import HealthKit
import Observation

@MainActor
@Observable
final class HealthKitService {
    private let store = HKHealthStore()

    var accessState: HealthAccessState = .unknown
    var today: HealthSnapshot = .zero
    var dailyMetrics: [DailyHealthMetric] = []
    var hourlySteps: [HourlyStep] = []
    var isLoading = false
    var lastError: String?
    var lastRefresh: Date?

    var isAvailable: Bool {
        HKHealthStore.isHealthDataAvailable()
    }

    var hasDashboardData: Bool {
        !today.isEmpty
    }

    static let readTypes: Set<HKObjectType> = {
        var types = Set<HKObjectType>()
        let quantityIdentifiers: [HKQuantityTypeIdentifier] = [
            .stepCount,
            .activeEnergyBurned,
            .appleExerciseTime,
            .distanceWalkingRunning
        ]
        for identifier in quantityIdentifiers {
            if let type = HKObjectType.quantityType(forIdentifier: identifier) {
                types.insert(type)
            }
        }
        if let standType = HKObjectType.categoryType(forIdentifier: .appleStandHour) {
            types.insert(standType)
        }
        types.insert(HKObjectType.workoutType())
        return types
    }()

    static let shareTypes: Set<HKSampleType> = {
        var types = Set<HKSampleType>()
        if let energy = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned) {
            types.insert(energy)
        }
        types.insert(HKObjectType.workoutType())
        return types
    }()

    func prepare(requested: Bool) async {
        guard isAvailable else {
            accessState = .unavailable
            return
        }
        if accessState == .unknown {
            accessState = requested ? .requested : .notRequested
        }
        if requested {
            await refresh(days: 30)
        }
    }

    @discardableResult
    func requestAuthorization() async -> Bool {
        guard isAvailable else {
            accessState = .unavailable
            lastError = "Apple Health is not available on this device."
            return false
        }
        do {
            try await store.requestAuthorization(toShare: Self.shareTypes, read: Self.readTypes)
            accessState = .requested
            lastError = nil
            await refresh(days: 30, force: true)
            return true
        } catch {
            accessState = .requested
            lastError = error.localizedDescription
            return false
        }
    }

    func refresh(days: Int = 30, force: Bool = false) async {
        guard accessState == .requested else { return }
        if !force, let lastRefresh, Date().timeIntervalSince(lastRefresh) < 90 {
            return
        }
        isLoading = true
        defer { isLoading = false }

        async let todaySnapshot = fetchToday()
        async let daily = fetchDailyMetrics(days: days)
        async let hourly = fetchHourlyStepsToday()
        let results = await (todaySnapshot, daily, hourly)

        today = results.0
        dailyMetrics = results.1
        hourlySteps = results.2
        lastRefresh = .now
    }

    // MARK: - Reads

    private func fetchToday() async -> HealthSnapshot {
        let start = PulseDate.startOfDay()
        let end = Date()

        async let steps = quantitySum(.stepCount, unit: .count(), start: start, end: end)
        async let energy = quantitySum(.activeEnergyBurned, unit: .kilocalorie(), start: start, end: end)
        async let exercise = quantitySum(.appleExerciseTime, unit: .minute(), start: start, end: end)
        async let distance = quantitySum(.distanceWalkingRunning, unit: .meter(), start: start, end: end)
        async let stand = standHours(start: start, end: end)

        let values = await (steps, energy, exercise, distance, stand)
        return HealthSnapshot(
            date: end,
            steps: values.0 ?? 0,
            activeEnergy: values.1 ?? 0,
            exerciseMinutes: values.2 ?? 0,
            distanceMeters: values.3 ?? 0,
            standHours: values.4
        )
    }

    private func fetchDailyMetrics(days: Int) async -> [DailyHealthMetric] {
        let calendar = PulseDate.calendar
        let end = PulseDate.startOfDay()
        guard let start = calendar.date(byAdding: .day, value: -(max(days, 1) - 1), to: end) else {
            return []
        }
        let queryEnd = Date()

        async let steps = dailyQuantity(.stepCount, unit: .count(), start: start, end: queryEnd)
        async let energy = dailyQuantity(.activeEnergyBurned, unit: .kilocalorie(), start: start, end: queryEnd)
        async let exercise = dailyQuantity(.appleExerciseTime, unit: .minute(), start: start, end: queryEnd)
        async let distance = dailyQuantity(.distanceWalkingRunning, unit: .meter(), start: start, end: queryEnd)
        async let stand = dailyStandHours(start: start, end: queryEnd)
        let values = await (steps, energy, exercise, distance, stand)

        var metrics: [DailyHealthMetric] = []
        for offset in 0..<days {
            guard let day = calendar.date(byAdding: .day, value: offset, to: start) else { continue }
            let key = calendar.startOfDay(for: day)
            metrics.append(
                DailyHealthMetric(
                    date: key,
                    steps: values.0[key] ?? 0,
                    activeEnergy: values.1[key] ?? 0,
                    exerciseMinutes: values.2[key] ?? 0,
                    distanceMeters: values.3[key] ?? 0,
                    standHours: values.4[key] ?? 0
                )
            )
        }
        return metrics
    }

    private func fetchHourlyStepsToday() async -> [HourlyStep] {
        guard let type = HKObjectType.quantityType(forIdentifier: .stepCount) else { return [] }
        let calendar = PulseDate.calendar
        let start = PulseDate.startOfDay()
        let now = Date()
        let predicate = HKQuery.predicateForSamples(withStart: start, end: now, options: .strictStartDate)
        let query = HKStatisticsCollectionQuery(
            quantityType: type,
            quantitySamplePredicate: predicate,
            options: [.cumulativeSum],
            anchorDate: start,
            intervalComponents: DateComponents(hour: 1)
        )

        let values: [Date: Double] = await withCheckedContinuation { continuation in
            query.initialResultsHandler = { _, results, _ in
                var map: [Date: Double] = [:]
                results?.enumerateStatistics(from: start, to: now) { statistics, _ in
                    map[statistics.startDate] = statistics.sumQuantity()?.doubleValue(for: .count()) ?? 0
                }
                continuation.resume(returning: map)
            }
            store.execute(query)
        }

        var points: [HourlyStep] = []
        let currentHour = calendar.component(.hour, from: now)
        for hour in 0...max(currentHour, 0) {
            guard let date = calendar.date(byAdding: .hour, value: hour, to: start) else { continue }
            points.append(HourlyStep(hour: date, steps: values[date] ?? 0))
        }
        return points
    }

    private func quantitySum(
        _ identifier: HKQuantityTypeIdentifier,
        unit: HKUnit,
        start: Date,
        end: Date
    ) async -> Double? {
        guard let type = HKObjectType.quantityType(forIdentifier: identifier) else { return nil }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)

        return await withCheckedContinuation { continuation in
            let query = HKStatisticsQuery(
                quantityType: type,
                quantitySamplePredicate: predicate,
                options: [.cumulativeSum]
            ) { _, statistics, _ in
                continuation.resume(returning: statistics?.sumQuantity()?.doubleValue(for: unit))
            }
            store.execute(query)
        }
    }

    private func dailyQuantity(
        _ identifier: HKQuantityTypeIdentifier,
        unit: HKUnit,
        start: Date,
        end: Date
    ) async -> [Date: Double] {
        guard let type = HKObjectType.quantityType(forIdentifier: identifier) else { return [:] }
        let anchor = PulseDate.startOfDay(start)
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        let query = HKStatisticsCollectionQuery(
            quantityType: type,
            quantitySamplePredicate: predicate,
            options: [.cumulativeSum],
            anchorDate: anchor,
            intervalComponents: DateComponents(day: 1)
        )

        return await withCheckedContinuation { continuation in
            query.initialResultsHandler = { _, results, _ in
                var map: [Date: Double] = [:]
                results?.enumerateStatistics(from: start, to: end) { statistics, _ in
                    map[PulseDate.startOfDay(statistics.startDate)] =
                        statistics.sumQuantity()?.doubleValue(for: unit) ?? 0
                }
                continuation.resume(returning: map)
            }
            store.execute(query)
        }
    }

    private func standHours(start: Date, end: Date) async -> Double {
        let map = await standSamplesByDay(start: start, end: end)
        return map.values.reduce(0, +)
    }

    private func dailyStandHours(start: Date, end: Date) async -> [Date: Double] {
        await standSamplesByDay(start: start, end: end)
    }

    private func standSamplesByDay(start: Date, end: Date) async -> [Date: Double] {
        guard let type = HKObjectType.categoryType(forIdentifier: .appleStandHour) else { return [:] }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)

        return await withCheckedContinuation { continuation in
            let query = HKSampleQuery(
                sampleType: type,
                predicate: predicate,
                limit: HKObjectQueryNoLimit,
                sortDescriptors: nil
            ) { _, samples, _ in
                var map: [Date: Double] = [:]
                for sample in (samples as? [HKCategorySample]) ?? [] {
                    guard sample.value == HKCategoryValueAppleStandHour.stood.rawValue else { continue }
                    let day = PulseDate.startOfDay(sample.startDate)
                    map[day, default: 0] += 1
                }
                continuation.resume(returning: map)
            }
            store.execute(query)
        }
    }

    // MARK: - Write

    @discardableResult
    func saveWorkout(_ session: WorkoutSession) async -> Bool {
        guard accessState == .requested, let endedAt = session.endedAt else { return false }
        let configuration = HKWorkoutConfiguration()
        configuration.activityType = Self.activityType(for: session.category)
        configuration.locationType = .unknown

        let builder = HKWorkoutBuilder(healthStore: store, configuration: configuration, device: HKDevice.local())
        do {
            try await builder.beginCollection(at: session.startedAt)

            if let calories = session.estimatedCalories, calories > 0 {
                let type = HKQuantityType(.activeEnergyBurned)
                let quantity = HKQuantity(unit: .kilocalorie(), doubleValue: calories)
                let sample = HKQuantitySample(
                    type: type,
                    quantity: quantity,
                    start: session.startedAt,
                    end: endedAt
                )
                try await builder.addSamples([sample])
            }

            try await builder.addMetadata([
                HKMetadataKeyExternalUUID: session.id.uuidString,
                HKMetadataKeyWorkoutBrandName: "PULSE"
            ])
            try await builder.endCollection(at: endedAt)
            _ = try await builder.finishWorkout()
            return true
        } catch {
            lastError = error.localizedDescription
            return false
        }
    }

    private static func activityType(for category: WorkoutCategory) -> HKWorkoutActivityType {
        switch category {
        case .strength: .traditionalStrengthTraining
        case .running: .running
        case .walking: .walking
        case .cycling: .cycling
        case .yoga: .yoga
        case .mobility: .flexibility
        case .hiit: .highIntensityIntervalTraining
        }
    }
}
