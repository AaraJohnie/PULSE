import Foundation

struct HealthSnapshot: Equatable {
    var date: Date = .now
    var steps: Double = 0
    var activeEnergy: Double = 0
    var exerciseMinutes: Double = 0
    var distanceMeters: Double = 0
    var standHours: Double = 0

    static let zero = HealthSnapshot()

    var isEmpty: Bool {
        steps == 0 && activeEnergy == 0 && exerciseMinutes == 0 && distanceMeters == 0 && standHours == 0
    }
}

struct DailyHealthMetric: Identifiable, Equatable {
    var date: Date
    var steps: Double = 0
    var activeEnergy: Double = 0
    var exerciseMinutes: Double = 0
    var distanceMeters: Double = 0
    var standHours: Double = 0

    var id: Date { date }
}

struct HourlyStep: Identifiable, Equatable {
    var hour: Date
    var steps: Double

    var id: Date { hour }
}
