import XCTest
import SwiftData
@testable import PULSE

final class UnitFormatterTests: XCTestCase {
    func testWeightConversionRoundTrips() {
        let pounds = UnitFormatter.weightValue(kg: 100, units: .imperial)
        XCTAssertEqual(pounds, 220.46226218, accuracy: 0.0001)
        XCTAssertEqual(UnitFormatter.kilograms(from: pounds, units: .imperial), 100, accuracy: 0.0001)
        XCTAssertEqual(UnitFormatter.weightValue(kg: 100, units: .metric), 100, accuracy: 0.0001)
    }

    func testHeightPartsForMetricAndImperial() {
        let metric = UnitFormatter.heightParts(cm: 178, units: .metric)
        XCTAssertEqual(metric.primary, 178)
        XCTAssertNil(metric.secondary)

        let imperial = UnitFormatter.heightParts(cm: 178, units: .imperial)
        XCTAssertEqual(imperial.primary, 5)
        XCTAssertEqual(imperial.secondary, 10)
    }

    func testDistanceAndPaceFormatting() {
        XCTAssertEqual(UnitFormatter.distance(meters: 5_000, units: .metric), "5.0 km")
        XCTAssertEqual(UnitFormatter.distance(meters: 5_000, units: .imperial), "3.1 mi")
        XCTAssertEqual(UnitFormatter.pace(secondsPerKilometre: 300, units: .metric), "5′00″/km")
        XCTAssertEqual(UnitFormatter.pace(secondsPerKilometre: 300, units: .imperial), "8′02″/mi")
        XCTAssertEqual(UnitFormatter.pace(secondsPerKilometre: 0, units: .metric), "—")
    }

    func testWaterAndVolumeFormatting() {
        XCTAssertEqual(UnitFormatter.waterTotal(ml: 1_500, units: .metric), "1.50 L")
        XCTAssertEqual(UnitFormatter.waterTotal(ml: 900, units: .metric), "900 ml")
        XCTAssertEqual(UnitFormatter.waterTotal(ml: 1_000, units: .imperial), "34 fl oz")
        XCTAssertEqual(UnitFormatter.volume(kg: 1_500, units: .metric), "1.5 t")
        XCTAssertEqual(UnitFormatter.volume(kg: 100, units: .imperial), "220 lb")
        XCTAssertEqual(UnitFormatter.percent(0.125), "13%")
    }

    func testWaterConversionRoundTrips() {
        let ounces = UnitFormatter.waterValue(ml: 1_000, units: .imperial)
        XCTAssertEqual(UnitFormatter.millilitres(from: ounces, units: .imperial), 1_000, accuracy: 0.001)
    }
}

final class WorkoutAnalyticsTests: XCTestCase {
    private var calendar: Calendar {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        calendar.firstWeekday = 2
        return calendar
    }

    private func day(_ offset: Int, from base: Date) -> Date {
        calendar.date(byAdding: .day, value: offset, to: base)!
    }

    private func session(
        _ title: String,
        start: Date,
        minutes: Int = 30,
        status: WorkoutStatus = .completed,
        sets: [(id: String, name: String, weight: Double, reps: Int, date: Date)] = []
    ) -> WorkoutSession {
        let workout = WorkoutSession(
            title: title,
            category: .strength,
            startedAt: start,
            endedAt: start.addingTimeInterval(Double(minutes) * 60),
            status: status,
            totalVolumeKg: sets.reduce(0) { $0 + Double($1.weight) * Double($1.reps) }
        )
        workout.sets = sets.enumerated().map { index, entry in
            WorkoutSetRecord(
                exerciseID: entry.id,
                exerciseName: entry.name,
                muscleGroup: .fullBody,
                setIndex: index + 1,
                reps: entry.reps,
                weightKg: entry.weight,
                completedAt: entry.date
            )
        }
        return workout
    }

    func testCurrentStreakCountsTodayBackwards() {
        let today = calendar.date(from: DateComponents(year: 2026, month: 10, day: 15))!
        let days: Set<Date> = [today, day(-1, from: today), day(-2, from: today)]
        XCTAssertEqual(WorkoutAnalytics.currentStreak(workoutDays: days, today: today, calendar: calendar), 3)

        let withoutToday: Set<Date> = [day(-1, from: today), day(-2, from: today)]
        XCTAssertEqual(WorkoutAnalytics.currentStreak(workoutDays: withoutToday, today: today, calendar: calendar), 2)

        let stale: Set<Date> = [today, day(-3, from: today)]
        XCTAssertEqual(WorkoutAnalytics.currentStreak(workoutDays: stale, today: today, calendar: calendar), 1)

        XCTAssertEqual(WorkoutAnalytics.currentStreak(workoutDays: [], today: today, calendar: calendar), 0)
    }

    func testLongestStreakFindsTheLongestRun() {
        let start = calendar.date(from: DateComponents(year: 2026, month: 10, day: 1))!
        let days: Set<Date> = [day(0, from: start), day(1, from: start), day(2, from: start), day(5, from: start)]
        XCTAssertEqual(WorkoutAnalytics.longestStreak(workoutDays: days, calendar: calendar), 3)
        XCTAssertEqual(WorkoutAnalytics.longestStreak(workoutDays: [], calendar: calendar), 0)
    }

    func testStatsIgnoreActiveAndDiscardedSessions() {
        let start = calendar.date(from: DateComponents(year: 2026, month: 10, day: 1))!
        let completed = session("Completed", start: start, minutes: 40)
        let active = session("Active", start: day(1, from: start), minutes: 10, status: .active)
        let discarded = session("Discarded", start: day(2, from: start), minutes: 5, status: .discarded)

        let stats = WorkoutAnalytics.stats([completed, active, discarded], calendar: calendar)
        XCTAssertEqual(stats.totalWorkouts, 1)
        XCTAssertEqual(stats.totalMinutes, 40)
        XCTAssertEqual(stats.averageDurationMinutes, 40)
    }

    func testPersonalRecordsPreferWeightThenReps() {
        let start = calendar.date(from: DateComponents(year: 2026, month: 10, day: 1))!
        let first = session(
            "Session one",
            start: start,
            sets: [
                ("push-up", "Push-Up", 20, 10, start),
                ("row", "Row", 30, 8, start)
            ]
        )
        let second = session(
            "Session two",
            start: day(1, from: start),
            sets: [
                ("push-up", "Push-Up", 25, 8, day(1, from: start)),
                ("row", "Row", 30, 10, day(1, from: start))
            ]
        )

        let records = WorkoutAnalytics.personalRecords(from: [first, second])
        XCTAssertEqual(records.count, 2)
        XCTAssertEqual(records.first { $0.exerciseID == "push-up" }?.weightKg, 25)
        XCTAssertEqual(records.first { $0.exerciseID == "row" }?.reps, 10)
    }

    func testNewRecordsDetectImprovementsAndFirsts() {
        let start = calendar.date(from: DateComponents(year: 2026, month: 10, day: 1))!
        let previous = session(
            "Previous",
            start: start,
            sets: [("push-up", "Push-Up", 20, 10, start)]
        )
        let current = session(
            "Current",
            start: day(1, from: start),
            sets: [
                ("push-up", "Push-Up", 22, 8, day(1, from: start)),
                ("squat", "Squat", 40, 10, day(1, from: start))
            ]
        )

        let records = WorkoutAnalytics.newRecords(in: current, comparedTo: [previous])
        XCTAssertEqual(records.count, 2)
        XCTAssertEqual(records.first { $0.exerciseID == "squat" }?.isFirst, true)
        XCTAssertEqual(records.first { $0.exerciseID == "push-up" }?.weightKg, 22)
    }

    func testStrengthProgressionUsesBestSetPerSession() {
        let start = calendar.date(from: DateComponents(year: 2026, month: 10, day: 1))!
        let first = session(
            "First",
            start: start,
            sets: [
                ("row", "Row", 20, 12, start),
                ("row", "Row", 30, 8, start)
            ]
        )
        let second = session(
            "Second",
            start: day(4, from: start),
            sets: [("row", "Row", 32, 8, day(4, from: start))]
        )

        let points = WorkoutAnalytics.strengthProgression(exerciseID: "row", sessions: [second, first])
        XCTAssertEqual(points.map(\.weightKg), [30, 32])
        XCTAssertEqual(points.first?.reps, 8)
    }

    func testExerciseFrequencyCountsSessionsNotSets() {
        let start = calendar.date(from: DateComponents(year: 2026, month: 10, day: 1))!
        let first = session(
            "First",
            start: start,
            sets: [
                ("row", "Row", 20, 12, start),
                ("row", "Row", 20, 10, start)
            ]
        )
        let second = session(
            "Second",
            start: day(1, from: start),
            sets: [("row", "Row", 22, 10, day(1, from: start))]
        )

        let frequency = WorkoutAnalytics.exerciseFrequency(sessions: [first, second])
        XCTAssertEqual(frequency.first?.sessions, 2)
    }

    func testEstimatedCalories() {
        XCTAssertEqual(WorkoutAnalytics.estimatedCalories(category: .running, minutes: 30, weightKg: 70), 315)
        XCTAssertEqual(WorkoutAnalytics.estimatedCalories(category: .strength, minutes: 30, weightKg: 70), 175)
        XCTAssertNil(WorkoutAnalytics.estimatedCalories(category: .running, minutes: 0, weightKg: 70))
        XCTAssertNil(WorkoutAnalytics.estimatedCalories(category: .running, minutes: 30, weightKg: 0))
    }
}

final class InsightEngineTests: XCTestCase {
    private func context(
        steps: Double = 5_000,
        averageSteps: Double? = nil,
        workouts: Int = 1,
        streak: Int = 0,
        hydration: Double = 2_000,
        goal: Double = 2_500,
        hour: Int = 9
    ) -> InsightContext {
        InsightContext(
            stepsToday: steps,
            averageSteps: averageSteps,
            workoutsThisWeek: workouts,
            streak: streak,
            hydrationMl: hydration,
            hydrationGoalMl: goal,
            hour: hour
        )
    }

    func testAfternoonHydrationWinsWhenBehind() {
        let insight = InsightEngine.insight(
            for: context(hydration: 500, goal: 2_500, hour: 14),
            units: .metric
        )
        XCTAssertEqual(insight.title, "A little more water")
        XCTAssertEqual(insight.tone, .attention)
    }

    func testStreakInsight() {
        let insight = InsightEngine.insight(for: context(streak: 4, hydration: 2_400), units: .metric)
        XCTAssertEqual(insight.title, "4-day rhythm")
        XCTAssertEqual(insight.tone, .positive)
    }

    func testStepsAheadOfAverage() {
        let insight = InsightEngine.insight(
            for: context(steps: 9_000, averageSteps: 6_000, workouts: 1),
            units: .metric
        )
        XCTAssertEqual(insight.title, "Ahead of your usual pace")
    }

    func testWeeklyConsistencyInsight() {
        let insight = InsightEngine.insight(for: context(workouts: 3), units: .metric)
        XCTAssertEqual(insight.title, "Consistency is compounding")
    }

    func testEmptyWeekInsight() {
        let insight = InsightEngine.insight(for: context(workouts: 0), units: .metric)
        XCTAssertEqual(insight.title, "Your week is still open")
    }

    func testFallbackInsight() {
        let insight = InsightEngine.insight(for: context(workouts: 1), units: .metric)
        XCTAssertEqual(insight.title, "Stay with your rhythm")
        XCTAssertEqual(insight.tone, .positive)
    }
}

final class NutritionTotalsTests: XCTestCase {
    func testTotalsSumEveryEntry() {
        let entries = [
            FoodEntry(
                meal: .breakfast,
                name: "Oats",
                calories: 300,
                proteinG: 20,
                carbsG: 30,
                fatG: 10
            ),
            FoodEntry(
                meal: .lunch,
                name: "Chicken bowl",
                calories: 150,
                proteinG: 10,
                carbsG: 15,
                fatG: 5
            )
        ]

        let totals = NutritionTotals(entries: entries)
        XCTAssertEqual(totals.calories, 450)
        XCTAssertEqual(totals.protein, 30)
        XCTAssertEqual(totals.carbs, 45)
        XCTAssertEqual(totals.fat, 15)
    }

    func testEmptyTotalsAreZero() {
        let totals = NutritionTotals(entries: [])
        XCTAssertEqual(totals.calories, 0)
        XCTAssertEqual(totals.protein, 0)
        XCTAssertEqual(totals.carbs, 0)
        XCTAssertEqual(totals.fat, 0)
    }
}

final class UserProfileTargetsTests: XCTestCase {
    func testIntermediateStrengthTargets() {
        let profile = UserProfile(
            name: "Test",
            age: 30,
            heightCm: 175,
            weightKg: 72,
            level: .intermediate,
            goal: .buildStrength
        )
        profile.recalculateTargets()

        XCTAssertEqual(profile.calorieGoal, 2_450)
        XCTAssertEqual(profile.proteinGoalG, 137)
        XCTAssertEqual(profile.fatGoalG, 82)
        XCTAssertEqual(profile.carbsGoalG, 292)
        XCTAssertEqual(profile.hydrationGoalMl, 2_500)
    }

    func testCalorieGoalClampsToSafeFloor() {
        let profile = UserProfile(
            name: "Test",
            age: 30,
            heightCm: 150,
            weightKg: 45,
            level: .beginner,
            goal: .loseWeight
        )
        profile.recalculateTargets()

        XCTAssertEqual(profile.calorieGoal, 1_400)
        XCTAssertEqual(profile.proteinGoalG, 90)
        XCTAssertEqual(profile.hydrationGoalMl, 1_600)
    }

    func testBMIAndInitials() {
        let profile = UserProfile(
            name: "Alex Morgan",
            age: 31,
            heightCm: 178,
            weightKg: 72.4
        )
        XCTAssertEqual(profile.bmi, 22.85, accuracy: 0.01)
        XCTAssertEqual(profile.initials, "AM")
        XCTAssertEqual(profile.firstName, "Alex")
    }
}

final class WatchPayloadTests: XCTestCase {
    func testPayloadRoundTripsWithPhoneContract() throws {
        let start = Date(timeIntervalSince1970: 1_700_000_000)
        let payload = WatchWorkoutPayload(
            id: UUID(),
            title: "Running",
            categoryRaw: WorkoutCategory.running.rawValue,
            startedAt: start,
            endedAt: start.addingTimeInterval(2_700),
            activeEnergy: 320,
            averageHeartRate: 142,
            maxHeartRate: 165,
            distanceMeters: 5_000
        )

        let data = try JSONEncoder().encode(payload)
        let decoded = try JSONDecoder().decode(WatchWorkoutPayload.self, from: data)

        XCTAssertEqual(decoded, payload)
        XCTAssertEqual(decoded.category, .running)
        XCTAssertEqual(decoded.durationMinutes, 45)
    }
}

final class PersistenceTests: XCTestCase {
    func testPreviewSeedPopulatesAndClearsRecords() throws {
        let container = PulseStore.makePreviewContainer()
        let context = ModelContext(container)

        let profiles = try context.fetch(FetchDescriptor<UserProfile>())
        XCTAssertEqual(profiles.count, 1)
        let profile = try XCTUnwrap(profiles.first)
        XCTAssertTrue(profile.usesPreviewData)
        XCTAssertEqual(profile.name, "Alex Morgan")

        XCTAssertGreaterThan(try context.fetchCount(FetchDescriptor<WorkoutSession>()), 0)
        XCTAssertGreaterThan(try context.fetchCount(FetchDescriptor<WorkoutSetRecord>()), 0)
        XCTAssertGreaterThan(try context.fetchCount(FetchDescriptor<Routine>()), 0)
        XCTAssertGreaterThan(try context.fetchCount(FetchDescriptor<FoodEntry>()), 0)
        XCTAssertGreaterThan(try context.fetchCount(FetchDescriptor<HydrationEntry>()), 0)
        XCTAssertGreaterThan(try context.fetchCount(FetchDescriptor<WeightEntry>()), 0)

        PreviewData.clearPreviewData(in: context, profile: profile)

        XCTAssertFalse(profile.usesPreviewData)
        XCTAssertEqual(try context.fetchCount(FetchDescriptor<WorkoutSession>()), 0)
        XCTAssertEqual(try context.fetchCount(FetchDescriptor<Routine>()), 0)
        XCTAssertEqual(try context.fetchCount(FetchDescriptor<FoodEntry>()), 0)
        XCTAssertEqual(try context.fetchCount(FetchDescriptor<HydrationEntry>()), 0)
        XCTAssertEqual(try context.fetchCount(FetchDescriptor<WeightEntry>()), 0)
        XCTAssertEqual(try context.fetchCount(FetchDescriptor<UserProfile>()), 1)
    }

    func testPreviewMetricsHaveStableShape() {
        let end = Date(timeIntervalSince1970: 1_700_000_000)
        let metrics = PreviewData.dailyMetrics(days: 7, endingAt: end)
        XCTAssertEqual(metrics.count, 7)
        XCTAssertTrue(metrics.allSatisfy { $0.steps >= 0 && $0.activeEnergy >= 0 })
        XCTAssertTrue(metrics.allSatisfy { $0.date <= end.addingTimeInterval(86_400) })
    }
}
