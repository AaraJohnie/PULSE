import SwiftUI

@main
struct PulseWatchApp: App {
    @State private var health = WatchHealthManager()
    @State private var sync = WatchSyncService()

    var body: some Scene {
        WindowGroup {
            WatchRootView()
                .environment(health)
                .environment(sync)
                .preferredColorScheme(.dark)
                .task {
                    sync.activate()
                    await health.prepare()
                }
        }
    }
}
