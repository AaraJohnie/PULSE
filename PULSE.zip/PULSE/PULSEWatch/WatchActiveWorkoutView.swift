import SwiftUI

struct WatchActiveWorkoutView: View {
    @Environment(WatchHealthManager.self) private var health
    @Environment(WatchSyncService.self) private var sync

    @State private var confirmEnd = false

    private var kind: WatchWorkoutKind { health.kind }

    private var restProgress: Double {
        guard health.restTotal > 0 else { return 0 }
        return Double(health.restTotal - health.restSecondsRemaining) / Double(health.restTotal)
    }

    var body: some View {
        WatchScreen {
            ZStack(alignment: .bottom) {
                ScrollView {
                    VStack(spacing: 8) {
                        header
                        timer

                        HStack(spacing: 8) {
                            WatchMetricTile(
                                label: "Heart",
                                value: WatchFormat.heartRate(health.heartRate),
                                unit: "BPM",
                                symbol: "heart.fill",
                                tint: WatchColor.danger
                            )
                            WatchMetricTile(
                                label: "Energy",
                                value: WatchFormat.number(health.activeEnergy),
                                unit: "kcal",
                                symbol: "flame.fill",
                                tint: WatchColor.sage
                            )
                        }

                        if kind.showsDistance {
                            distanceCard
                        }

                        if health.isResting {
                            restCard
                        }
                    }
                    .padding(.horizontal, 8)
                    .padding(.top, 2)
                    .padding(.bottom, 60)
                }
                .scrollIndicators(.hidden)

                if health.isEnding {
                    savingBar
                } else {
                    controlBar
                }
            }
            .ignoresSafeArea(edges: .bottom)
        }
        .confirmationDialog("End this workout?", isPresented: $confirmEnd, titleVisibility: .visible) {
            Button("End and save", role: .destructive) {
                Task { await health.endWorkout() }
            }
            Button("Keep going", role: .cancel) {}
        } message: {
            Text("Your session is saved to Apple Health and sent to your iPhone.")
        }
    }

    private var savingBar: some View {
        HStack(spacing: 6) {
            ProgressView()
                .tint(WatchColor.sage)
            Text("Saving workout")
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(WatchColor.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(WatchColor.background.opacity(0.96))
    }

    private var header: some View {
        HStack(spacing: 5) {
            Image(systemName: kind.symbol)
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(kind.tint)
            Text(kind.title)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(WatchColor.ivory)
            Spacer(minLength: 4)
            if health.phase == .paused {
                WatchPill(text: "Paused", symbol: "pause.fill", tint: WatchColor.gold)
            } else if health.phase == .finishing {
                WatchPill(text: "Saving", symbol: "arrow.down.circle", tint: WatchColor.tertiary)
            } else {
                WatchPill(text: "Live", symbol: "circle.fill", tint: kind.tint)
            }
        }
    }

    private var timer: some View {
        Text(WatchFormat.elapsed(health.elapsed))
            .font(WatchFont.number(36, weight: .semibold))
            .foregroundStyle(health.phase == .paused ? WatchColor.tertiary : WatchColor.ivory)
            .contentTransition(.numericText())
            .lineLimit(1)
            .minimumScaleFactor(0.65)
            .frame(maxWidth: .infinity)
            .accessibilityLabel("Elapsed time")
            .accessibilityValue(WatchFormat.elapsed(health.elapsed))
    }

    private var distanceCard: some View {
        WatchCard(padding: 9) {
            HStack(spacing: 8) {
                inlineMetric(
                    symbol: kind.symbol,
                    label: "Distance",
                    value: "\(WatchFormat.distanceValue(health.distanceMeters, usesMetric: sync.usesMetric)) \(WatchFormat.distanceUnit(usesMetric: sync.usesMetric))"
                )

                if kind.showsPace {
                    Rectangle()
                        .fill(WatchColor.hairline)
                        .frame(width: 1, height: 26)

                    inlineMetric(
                        symbol: "speedometer",
                        label: "Pace",
                        value: WatchFormat.pace(health.currentPaceSecondsPerKilometre, usesMetric: sync.usesMetric)
                    )
                }
            }
        }
    }

    private func inlineMetric(symbol: String, label: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack(spacing: 3) {
                Image(systemName: symbol)
                    .font(.system(size: 8, weight: .bold))
                Text(label.uppercased())
                    .font(.system(size: 8, weight: .semibold))
                    .tracking(0.5)
            }
            .foregroundStyle(WatchColor.tertiary)

            Text(value)
                .font(WatchFont.number(15, weight: .semibold))
                .foregroundStyle(WatchColor.ivory)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var restCard: some View {
        WatchCard(padding: 10) {
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    HStack(spacing: 4) {
                        Image(systemName: "timer")
                            .font(.system(size: 10, weight: .semibold))
                        Text("REST")
                            .font(.system(size: 9, weight: .semibold))
                            .tracking(0.7)
                    }
                    .foregroundStyle(WatchColor.gold)

                    Spacer()

                    Text(WatchFormat.elapsed(Double(health.restSecondsRemaining)))
                        .font(WatchFont.number(17, weight: .semibold))
                        .foregroundStyle(WatchColor.ivory)
                        .contentTransition(.numericText())
                }

                WatchProgressBar(value: restProgress, tint: WatchColor.gold)

                HStack {
                    Text("Your wrist will tap when it's time.")
                        .font(.system(size: 9))
                        .foregroundStyle(WatchColor.tertiary)
                    Spacer(minLength: 4)
                    Button("Skip") {
                        health.stopRest()
                    }
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(WatchColor.sage)
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var controlBar: some View {
        HStack(spacing: 10) {
            roundControl(
                symbol: health.phase == .paused ? "play.fill" : "pause.fill",
                label: health.phase == .paused ? "Resume" : "Pause",
                tint: WatchColor.ivory
            ) {
                if health.phase == .paused {
                    health.resumeWorkout()
                } else {
                    health.pauseWorkout()
                }
            }

            roundControl(
                symbol: "timer",
                label: health.isResting ? "Restart" : "Rest",
                tint: WatchColor.gold
            ) {
                health.startRest(seconds: 90)
            }

            roundControl(
                symbol: "stop.fill",
                label: "End",
                tint: WatchColor.danger,
                filled: true
            ) {
                confirmEnd = true
            }
        }
        .padding(.horizontal, 10)
        .padding(.top, 8)
        .padding(.bottom, 4)
        .background(WatchColor.background.opacity(0.98))
        .overlay(alignment: .top) {
            Rectangle()
                .fill(WatchColor.hairline)
                .frame(height: 1)
        }
    }

    private func roundControl(
        symbol: String,
        label: String,
        tint: Color,
        filled: Bool = false,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                ZStack {
                    Circle()
                        .fill(filled ? tint.opacity(0.18) : WatchColor.surface)
                    Circle()
                        .strokeBorder(filled ? tint.opacity(0.35) : WatchColor.hairline, lineWidth: 1)
                    Image(systemName: symbol)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(tint)
                }
                .frame(width: 38, height: 38)

                Text(label)
                    .font(.system(size: 8, weight: .medium))
                    .foregroundStyle(tint)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(WatchScaleButtonStyle())
        .accessibilityLabel(label)
    }
}
