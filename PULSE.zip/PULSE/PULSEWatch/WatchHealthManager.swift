import Foundation
import HealthKit
import Observation
import WatchKit

enum WatchWorkoutPhase: Equatable {
    case idle
    case running
    case paused
    case finishing
    case summary
}

@MainActor
@Observable
final class WatchHealthManager: NSObject {
    private let store = HKHealthStore()
    private let defaults = UserDefaults.standard
    private let healthRequestKey = "pulse.watch.healthRequested"

    private var session: HKWorkoutSession?
    private var builder: HKLiveWorkoutBuilder?
    private var timerTask: Task<Void, Never>?
    private var restTask: Task<Void, Never>?

    var isHealthAvailable = HKHealthStore.isHealthDataAvailable()
    var hasRequestedHealth = false
    var isRefreshing = false
    var lastError: String?

    var today = WatchDailySnapshot.zero

    var phase: WatchWorkoutPhase = .idle
    var kind: WatchWorkoutKind = .strength
    var startedAt: Date?
    var elapsed: TimeInterval = 0
    var heartRate: Double?
    var averageHeartRate: Double?
    var maxHeartRate: Double?
    var activeEnergy: Double = 0
    var distanceMeters: Double = 0
    var isStarting = false
    var isEnding = false
    var finishedResult: WatchWorkoutResult?

    var restSecondsRemaining = 0
    var restTotal = 0
    var isResting = false

    override init() {
        super.init()
        hasRequestedHealth = defaults.bool(forKey: healthRequestKey)
    }

    var isWorkoutActive: Bool {
        phase == .running || phase == .paused || phase == .finishing
    }

    var currentPaceSecondsPerKilometre: Double? {
        guard distanceMeters > 50, elapsed > 5, kind.showsPace else { return nil }
        return elapsed / (distanceMeters / 1000)
    }

    // MARK: - Permission and daily activity

    static let readTypes: Set<HKObjectType> = {
        var types = Set<HKObjectType>()
        let identifiers: [HKQuantityTypeIdentifier] = [
            .heartRate,
            .activeEnergyBurned,
            .stepCount,
            .appleExerciseTime,
            .distanceWalkingRunning,
            .distanceCycling
        ]
        for identifier in identifiers {
            if let type = HKObjectType.quantityType(forIdentifier: identifier) {
                types.insert(type)
            }
        }
        if let stand = HKObjectType.categoryType(forIdentifier: .appleStandHour) {
            types.insert(stand)
        }
        types.insert(HKObjectType.workoutType())
        return types
    }()

    static let shareTypes: Set<HKSampleType> = {
        var types = Set<HKSampleType>()
        if let energy = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned) {
            types.insert(energy)
        }
        types.insert(HKObjectType.workoutType())
        return types
    }()

    func prepare() async {
        guard isHealthAvailable else { return }
        if hasRequestedHealth {
            await refreshToday()
        }
    }

    func requestHealthAccess() async {
        guard isHealthAvailable else {
            lastError = "Apple Health is not available on this Apple Watch."
            return
        }
        do {
            try await store.requestAuthorization(toShare: Self.shareTypes, read: Self.readTypes)
            hasRequestedHealth = true
            defaults.set(true, forKey: healthRequestKey)
            lastError = nil
            await refreshToday()
        } catch {
            lastError = error.localizedDescription
        }
    }

    func refreshToday() async {
        guard isHealthAvailable, !isRefreshing else { return }
        isRefreshing = true
        defer { isRefreshing = false }

        let start = Calendar.current.startOfDay(for: .now)
        let end = Date()

        async let steps = sum(.stepCount, unit: .count(), start: start, end: end)
        async let energy = sum(.activeEnergyBurned, unit: .kilocalorie(), start: start, end: end)
        async let exercise = sum(.appleExerciseTime, unit: .minute(), start: start, end: end)
        async let stand = standHours(start: start, end: end)
        let values = await (steps, energy, exercise, stand)

        today = WatchDailySnapshot(
            steps: values.0 ?? 0,
            activeEnergy: values.1 ?? 0,
            exerciseMinutes: values.2 ?? 0,
            standHours: values.3
        )
    }

    private func sum(
        _ identifier: HKQuantityTypeIdentifier,
        unit: HKUnit,
        start: Date,
        end: Date
    ) async -> Double? {
        guard let type = HKObjectType.quantityType(forIdentifier: identifier) else { return nil }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)

        return await withCheckedContinuation { continuation in
            let query = HKStatisticsQuery(
                quantityType: type,
                quantitySamplePredicate: predicate,
                options: [.cumulativeSum]
            ) { _, statistics, _ in
                continuation.resume(returning: statistics?.sumQuantity()?.doubleValue(for: unit))
            }
            store.execute(query)
        }
    }

    private func standHours(start: Date, end: Date) async -> Double {
        guard let type = HKObjectType.categoryType(forIdentifier: .appleStandHour) else { return 0 }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)

        return await withCheckedContinuation { continuation in
            let query = HKSampleQuery(
                sampleType: type,
                predicate: predicate,
                limit: HKObjectQueryNoLimit,
                sortDescriptors: nil
            ) { _, samples, _ in
                let hours = ((samples as? [HKCategorySample]) ?? []).filter {
                    $0.value == HKCategoryValueAppleStandHour.stood.rawValue
                }.count
                continuation.resume(returning: Double(hours))
            }
            store.execute(query)
        }
    }

    // MARK: - Workout lifecycle

    @discardableResult
    func startWorkout(kind: WatchWorkoutKind) async -> Bool {
        guard !isWorkoutActive, !isStarting else { return false }
        isStarting = true
        defer { isStarting = false }

        if !hasRequestedHealth {
            await requestHealthAccess()
        }
        guard isHealthAvailable else {
            lastError = "Apple Health is not available on this Apple Watch."
            return false
        }

        let configuration = HKWorkoutConfiguration()
        configuration.activityType = kind.activityType
        configuration.locationType = kind.locationType

        do {
            let newSession = try HKWorkoutSession(healthStore: store, configuration: configuration)
            let newBuilder = newSession.associatedWorkoutBuilder()
            newBuilder.dataSource = HKLiveWorkoutDataSource(
                healthStore: store,
                workoutConfiguration: configuration
            )
            newSession.delegate = self
            newBuilder.delegate = self

            let start = Date()
            session = newSession
            builder = newBuilder
            self.kind = kind
            startedAt = start
            elapsed = 0
            heartRate = nil
            averageHeartRate = nil
            maxHeartRate = nil
            activeEnergy = 0
            distanceMeters = 0
            finishedResult = nil
            stopRest()
            lastError = nil
            phase = .running

            newSession.startActivity(with: start)
            try await newBuilder.beginCollection(at: start)
            startTimer()
            WKInterfaceDevice.current().play(.start)
            return true
        } catch {
            session = nil
            builder = nil
            phase = .idle
            lastError = "Could not start the workout. \(error.localizedDescription)"
            return false
        }
    }

    func pauseWorkout() {
        guard phase == .running else { return }
        session?.pause()
        phase = .paused
        WKInterfaceDevice.current().play(.click)
    }

    func resumeWorkout() {
        guard phase == .paused else { return }
        session?.resume()
        phase = .running
        WKInterfaceDevice.current().play(.click)
    }

    func endWorkout() async {
        guard phase == .running || phase == .paused else { return }
        isEnding = true
        phase = .finishing
        stopTimer()
        stopRest()
        WKInterfaceDevice.current().play(.stop)

        let end = Date()
        session?.end()
        await persistFinished(at: end)
        isEnding = false
    }

    private func persistFinished(at end: Date) async {
        if let builder {
            do {
                try await builder.endCollection(at: end)
                _ = try await builder.finishWorkout()
            } catch {
                lastError = "The workout finished, but Apple Health could not save it."
            }
        }

        guard let start = startedAt else {
            resetToToday()
            return
        }

        let result = WatchWorkoutResult(
            kind: kind,
            startedAt: start,
            endedAt: end,
            activeEnergy: activeEnergy > 0 ? activeEnergy : nil,
            averageHeartRate: averageHeartRate,
            maxHeartRate: maxHeartRate,
            distanceMeters: distanceMeters > 0 ? distanceMeters : nil
        )
        finishedResult = result
        phase = .summary
        session = nil
        builder = nil
        WKInterfaceDevice.current().play(.success)
        await refreshToday()
    }

    func resetToToday() {
        stopTimer()
        stopRest()
        phase = .idle
        finishedResult = nil
        startedAt = nil
        elapsed = 0
        heartRate = nil
        averageHeartRate = nil
        maxHeartRate = nil
        activeEnergy = 0
        distanceMeters = 0
        isEnding = false
        Task { await refreshToday() }
    }

    func dismissError() {
        lastError = nil
    }

    private func startTimer() {
        stopTimer()
        timerTask = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(1))
                guard let self, !Task.isCancelled else { return }
                guard self.phase == .running else { continue }
                self.elapsed += 1
            }
        }
    }

    private func stopTimer() {
        timerTask?.cancel()
        timerTask = nil
    }

    // MARK: - Rest timer

    func startRest(seconds: Int = 90) {
        stopRest()
        restTotal = max(seconds, 10)
        restSecondsRemaining = restTotal
        isResting = true
        WKInterfaceDevice.current().play(.start)

        restTask = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(1))
                guard let self, self.isResting, !Task.isCancelled else { return }
                self.restSecondsRemaining -= 1

                if self.restSecondsRemaining <= 0 {
                    self.isResting = false
                    self.restSecondsRemaining = 0
                    WKInterfaceDevice.current().play(.notification)
                    try? await Task.sleep(for: .seconds(0.45))
                    WKInterfaceDevice.current().play(.notification)
                    return
                }

                if self.restSecondsRemaining % 15 == 0 {
                    WKInterfaceDevice.current().play(.click)
                }
            }
        }
    }

    func stopRest() {
        restTask?.cancel()
        restTask = nil
        isResting = false
        restSecondsRemaining = 0
        restTotal = 0
    }
}

extension WatchHealthManager: HKWorkoutSessionDelegate {
    nonisolated func workoutSession(
        _ workoutSession: HKWorkoutSession,
        didChangeTo toState: HKWorkoutSessionState,
        from fromState: HKWorkoutSessionState,
        date: Date
    ) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            switch toState {
            case .running:
                if self.phase == .paused { self.phase = .running }
            case .paused:
                if self.phase == .running { self.phase = .paused }
            case .ended:
                guard self.phase == .running || self.phase == .paused else { return }
                self.phase = .finishing
                self.stopTimer()
                self.stopRest()
                await self.persistFinished(at: date)
            default:
                break
            }
        }
    }

    nonisolated func workoutSession(
        _ workoutSession: HKWorkoutSession,
        didFailWithError error: Error
    ) {
        Task { @MainActor [weak self] in
            self?.lastError = "The workout session stopped. \(error.localizedDescription)"
            self?.phase = .idle
            self?.session = nil
            self?.builder = nil
            self?.stopTimer()
            self?.stopRest()
        }
    }
}

extension WatchHealthManager: HKLiveWorkoutBuilderDelegate {
    nonisolated func workoutBuilder(
        _ workoutBuilder: HKLiveWorkoutBuilder,
        didCollectDataOf collectedTypes: Set<HKSampleType>
    ) {
        var heart: Double?
        var average: Double?
        var maximum: Double?
        let heartUnit = HKUnit.count().unitDivided(by: .minute())

        if let heartType = HKQuantityType.quantityType(forIdentifier: .heartRate),
           collectedTypes.contains(heartType),
           let statistics = workoutBuilder.statistics(for: heartType) {
            heart = statistics.mostRecentQuantity()?.doubleValue(for: heartUnit)
            average = statistics.averageQuantity()?.doubleValue(for: heartUnit)
            maximum = statistics.maximumQuantity()?.doubleValue(for: heartUnit)
        }

        var energy: Double?
        if let energyType = HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned),
           collectedTypes.contains(energyType),
           let statistics = workoutBuilder.statistics(for: energyType) {
            energy = statistics.sumQuantity()?.doubleValue(for: .kilocalorie())
        }

        var distance = 0.0
        let distanceIdentifiers: [HKQuantityTypeIdentifier] = [.distanceWalkingRunning, .distanceCycling]
        for identifier in distanceIdentifiers {
            guard let type = HKQuantityType.quantityType(forIdentifier: identifier),
                  collectedTypes.contains(type),
                  let statistics = workoutBuilder.statistics(for: type) else { continue }
            distance += statistics.sumQuantity()?.doubleValue(for: .meter()) ?? 0
        }

        Task { @MainActor [weak self] in
            guard let self else { return }
            if let heart { self.heartRate = heart }
            if let average { self.averageHeartRate = average }
            if let maximum { self.maxHeartRate = maximum }
            if let energy { self.activeEnergy = energy }
            if distance > 0 { self.distanceMeters = distance }
        }
    }

    nonisolated func workoutBuilderDidCollectEvent(_ workoutBuilder: HKLiveWorkoutBuilder) {}
}
