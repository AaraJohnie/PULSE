import Foundation
import HealthKit
import SwiftUI

enum WatchWorkoutKind: String, CaseIterable, Identifiable, Hashable {
    case strength
    case running
    case walking
    case cycling
    case yoga
    case hiit

    var id: String { rawValue }

    var title: String {
        switch self {
        case .strength: "Strength"
        case .running: "Running"
        case .walking: "Walking"
        case .cycling: "Cycling"
        case .yoga: "Yoga"
        case .hiit: "HIIT"
        }
    }

    var symbol: String {
        switch self {
        case .strength: "figure.strengthtraining.traditional"
        case .running: "figure.run"
        case .walking: "figure.walk"
        case .cycling: "bicycle"
        case .yoga: "figure.yoga"
        case .hiit: "figure.highintensity.intervaltraining"
        }
    }

    var activityType: HKWorkoutActivityType {
        switch self {
        case .strength: .traditionalStrengthTraining
        case .running: .running
        case .walking: .walking
        case .cycling: .cycling
        case .yoga: .yoga
        case .hiit: .highIntensityIntervalTraining
        }
    }

    var locationType: HKWorkoutSessionLocationType {
        switch self {
        case .running, .walking, .cycling: .outdoor
        case .strength, .yoga, .hiit: .indoor
        }
    }

    var showsDistance: Bool {
        switch self {
        case .running, .walking, .cycling: true
        default: false
        }
    }

    var showsPace: Bool {
        self == .running || self == .walking
    }

    var supportsRestTimer: Bool {
        self == .strength || self == .hiit
    }

    var tint: Color {
        switch self {
        case .strength: WatchColor.sage
        case .running: WatchColor.gold
        case .walking: WatchColor.blue
        case .cycling: WatchColor.blue
        case .yoga: WatchColor.gold
        case .hiit: WatchColor.danger
        }
    }

    var prompt: String {
        switch self {
        case .strength: "Move with control. Log every rep on your wrist."
        case .running: "Find your cadence. Distance and pace in real time."
        case .walking: "A steady stride is still a workout."
        case .cycling: "Hold your effort and watch the kilometres build."
        case .yoga: "Breathe, flow, and finish with intention."
        case .hiit: "Short bursts, full effort. Rest when your wrist tells you."
        }
    }
}

struct WatchDailySnapshot: Equatable {
    var steps: Double = 0
    var activeEnergy: Double = 0
    var exerciseMinutes: Double = 0
    var standHours: Double = 0

    static let zero = WatchDailySnapshot()
}

struct WatchWorkoutResult: Identifiable, Equatable {
    let id: UUID
    let kind: WatchWorkoutKind
    let startedAt: Date
    let endedAt: Date
    let activeEnergy: Double?
    let averageHeartRate: Double?
    let maxHeartRate: Double?
    let distanceMeters: Double?

    var durationSeconds: TimeInterval {
        max(1, endedAt.timeIntervalSince(startedAt))
    }

    var durationMinutes: Int {
        max(1, Int(durationSeconds / 60))
    }

    var averagePaceSecondsPerKilometre: Double? {
        guard let distanceMeters, distanceMeters > 50, kind.showsPace else { return nil }
        return durationSeconds / (distanceMeters / 1000)
    }

    init(
        id: UUID = UUID(),
        kind: WatchWorkoutKind,
        startedAt: Date,
        endedAt: Date,
        activeEnergy: Double?,
        averageHeartRate: Double?,
        maxHeartRate: Double?,
        distanceMeters: Double?
    ) {
        self.id = id
        self.kind = kind
        self.startedAt = startedAt
        self.endedAt = endedAt
        self.activeEnergy = activeEnergy
        self.averageHeartRate = averageHeartRate
        self.maxHeartRate = maxHeartRate
        self.distanceMeters = distanceMeters
    }
}

enum WatchFormat {
    static func elapsed(_ seconds: TimeInterval) -> String {
        let total = max(0, Int(seconds))
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let secs = total % 60
        if hours > 0 {
            return String(format: "%d:%02d:%02d", hours, minutes, secs)
        }
        return String(format: "%02d:%02d", minutes, secs)
    }

    static func duration(_ seconds: TimeInterval) -> String {
        let minutes = max(1, Int(seconds / 60))
        guard minutes >= 60 else { return "\(minutes) min" }
        return "\(minutes / 60) h \(minutes % 60) min"
    }

    static func distance(_ meters: Double, usesMetric: Bool) -> String {
        "\(distanceValue(meters, usesMetric: usesMetric)) \(distanceUnit(usesMetric: usesMetric))"
    }

    static func distanceValue(_ meters: Double, usesMetric: Bool) -> String {
        let value = usesMetric ? meters / 1000 : meters / 1609.344
        return String(format: "%.2f", value)
    }

    static func distanceUnit(usesMetric: Bool) -> String {
        usesMetric ? "km" : "mi"
    }

    static func pace(_ secondsPerKilometre: Double?, usesMetric: Bool) -> String {
        guard let secondsPerKilometre, secondsPerKilometre.isFinite, secondsPerKilometre > 0 else {
            return "—"
        }
        let seconds = usesMetric ? secondsPerKilometre : secondsPerKilometre * 1.609344
        let minutes = Int(seconds) / 60
        let remainder = Int(seconds) % 60
        return "\(minutes)′\(String(format: "%02d", remainder))″/\(usesMetric ? "km" : "mi")"
    }

    static func energy(_ value: Double?) -> String {
        guard let value, value > 0 else { return "—" }
        return "\(Int(value.rounded())) kcal"
    }

    static func heartRate(_ value: Double?) -> String {
        guard let value, value > 0 else { return "—" }
        return "\(Int(value.rounded()))"
    }

    static func number(_ value: Double) -> String {
        value.formatted(.number.precision(.fractionLength(0)))
    }
}
