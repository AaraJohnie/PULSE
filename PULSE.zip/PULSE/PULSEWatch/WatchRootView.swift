import SwiftUI

struct WatchRootView: View {
    @Environment(WatchHealthManager.self) private var health
    @Environment(WatchSyncService.self) private var sync
    @Environment(\.scenePhase) private var scenePhase

    @State private var showingPicker = false

    var body: some View {
        Group {
            if let result = health.finishedResult {
                WatchSummaryView(result: result)
                    .transition(.opacity)
            } else if health.isWorkoutActive {
                WatchActiveWorkoutView()
                    .transition(.opacity)
            } else {
                WatchTodayView(showingPicker: $showingPicker)
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.25), value: health.phase)
        .animation(.easeInOut(duration: 0.25), value: health.finishedResult)
        .sheet(isPresented: $showingPicker) {
            WatchWorkoutPickerView()
        }
        .onChange(of: health.finishedResult) { _, result in
            if let result {
                sync.send(result)
            }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active {
                Task { await health.refreshToday() }
            }
        }
    }
}
