import SwiftUI

struct WatchSummaryView: View {
    @Environment(WatchHealthManager.self) private var health
    @Environment(WatchSyncService.self) private var sync
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    let result: WatchWorkoutResult

    @State private var appeared = false

    private var syncText: String {
        switch sync.status {
        case .sent: "Synced to iPhone"
        case .queued: "Will sync when nearby"
        case .idle: "Preparing sync"
        }
    }

    private var syncSymbol: String {
        switch sync.status {
        case .sent: "checkmark.circle.fill"
        case .queued: "arrow.triangle.2.circlepath"
        case .idle: "iphone"
        }
    }

    private var syncTint: Color {
        switch sync.status {
        case .sent: WatchColor.sage
        case .queued: WatchColor.gold
        case .idle: WatchColor.tertiary
        }
    }

    var body: some View {
        WatchScreen {
            ScrollView {
                VStack(spacing: 10) {
                    completionBadge

                    VStack(spacing: 2) {
                        Text("Workout complete")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(WatchColor.ivory)
                        Text(result.kind.title)
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(result.kind.tint)
                    }

                    HStack(spacing: 8) {
                        SummaryStat(
                            label: "Duration",
                            value: WatchFormat.duration(result.durationSeconds),
                            symbol: "clock"
                        )
                        SummaryStat(
                            label: "Energy",
                            value: WatchFormat.energy(result.activeEnergy),
                            symbol: "flame.fill"
                        )
                    }

                    if let distance = result.distanceMeters {
                        HStack(spacing: 8) {
                            SummaryStat(
                                label: "Distance",
                                value: WatchFormat.distance(distance, usesMetric: sync.usesMetric),
                                symbol: "location.fill"
                            )
                            SummaryStat(
                                label: "Avg pace",
                                value: WatchFormat.pace(
                                    result.averagePaceSecondsPerKilometre,
                                    usesMetric: sync.usesMetric
                                ),
                                symbol: "speedometer"
                            )
                        }
                    }

                    HStack(spacing: 8) {
                        SummaryStat(
                            label: "Avg heart",
                            value: "\(WatchFormat.heartRate(result.averageHeartRate)) BPM",
                            symbol: "heart.fill"
                        )
                        SummaryStat(
                            label: "Max heart",
                            value: "\(WatchFormat.heartRate(result.maxHeartRate)) BPM",
                            symbol: "waveform.path.ecg"
                        )
                    }

                    WatchPill(text: syncText, symbol: syncSymbol, tint: syncTint)
                        .padding(.top, 1)

                    if let error = health.lastError {
                        Text(error)
                            .font(.system(size: 9))
                            .foregroundStyle(WatchColor.tertiary)
                            .multilineTextAlignment(.center)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    Button {
                        health.resetToToday()
                    } label: {
                        WatchPrimaryButton(title: "Done")
                    }
                    .buttonStyle(WatchScaleButtonStyle())
                    .padding(.top, 2)
                }
                .padding(.horizontal, 8)
                .padding(.bottom, 12)
            }
            .scrollIndicators(.hidden)
        }
        .onAppear {
            if reduceMotion {
                appeared = true
            } else {
                withAnimation(.spring(response: 0.55, dampingFraction: 0.72)) {
                    appeared = true
                }
            }
        }
    }

    private var completionBadge: some View {
        ZStack {
            Circle()
                .fill(WatchColor.sage.opacity(0.14))
                .frame(width: 54, height: 54)
            Circle()
                .strokeBorder(WatchColor.sage.opacity(0.35), lineWidth: 1)
                .frame(width: 68, height: 68)
            Image(systemName: "checkmark")
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(WatchColor.sage)
        }
        .scaleEffect(appeared ? 1 : 0.65)
        .opacity(appeared ? 1 : 0)
        .accessibilityHidden(true)
    }
}

private struct SummaryStat: View {
    var label: String
    var value: String
    var symbol: String

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(spacing: 3) {
                Image(systemName: symbol)
                    .font(.system(size: 8, weight: .bold))
                Text(label.uppercased())
                    .font(.system(size: 8, weight: .semibold))
                    .tracking(0.5)
                    .lineLimit(1)
            }
            .foregroundStyle(WatchColor.tertiary)

            Text(value)
                .font(WatchFont.number(15, weight: .semibold))
                .foregroundStyle(WatchColor.ivory)
                .lineLimit(1)
                .minimumScaleFactor(0.65)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(9)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(WatchColor.surface)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(WatchColor.hairline, lineWidth: 1)
        )
    }
}
