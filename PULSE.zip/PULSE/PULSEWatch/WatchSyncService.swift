import Foundation
import Observation
import WatchConnectivity

struct WatchWorkoutMessage: Codable {
    var id: UUID
    var title: String
    var categoryRaw: String
    var startedAt: Date
    var endedAt: Date
    var activeEnergy: Double?
    var averageHeartRate: Double?
    var maxHeartRate: Double?
    var distanceMeters: Double?
}

enum WatchSyncStatus: Equatable {
    case idle
    case sent
    case queued
}

@Observable
final class WatchSyncService: NSObject {
    private let defaults = UserDefaults.standard
    private let unitsKey = "pulse.watch.usesMetric"
    private let moveGoalKey = "pulse.watch.moveGoal"

    var isReachable = false
    var isActivated = false
    var status: WatchSyncStatus = .idle
    var usesMetric: Bool {
        didSet { defaults.set(usesMetric, forKey: unitsKey) }
    }
    var moveGoal: Double {
        didSet { defaults.set(moveGoal, forKey: moveGoalKey) }
    }

    @ObservationIgnored private var didActivate = false

    override init() {
        let storedUnits = defaults.object(forKey: unitsKey) as? Bool
        usesMetric = storedUnits ?? true
        let storedGoal = defaults.double(forKey: moveGoalKey)
        moveGoal = storedGoal > 0 ? storedGoal : 500
        super.init()
    }

    func activate() {
        guard WCSession.isSupported(), !didActivate else { return }
        didActivate = true
        let session = WCSession.default
        session.delegate = self
        session.activate()
    }

    func send(_ result: WatchWorkoutResult) {
        guard WCSession.isSupported() else {
            status = .queued
            return
        }

        let message = WatchWorkoutMessage(
            id: result.id,
            title: result.kind.title,
            categoryRaw: result.kind.rawValue,
            startedAt: result.startedAt,
            endedAt: result.endedAt,
            activeEnergy: result.activeEnergy,
            averageHeartRate: result.averageHeartRate,
            maxHeartRate: result.maxHeartRate,
            distanceMeters: result.distanceMeters
        )

        guard let data = try? JSONEncoder().encode(message) else {
            status = .queued
            return
        }

        let payload: [String: Any] = ["workout": data]
        let session = WCSession.default

        if session.activationState == .activated, session.isReachable {
            session.sendMessage(payload, replyHandler: { _ in
                DispatchQueue.main.async {
                    self.status = .sent
                    self.isReachable = true
                }
            }, errorHandler: { _ in
                self.transfer(payload)
            })
        } else {
            transfer(payload)
        }
    }

    private func transfer(_ payload: [String: Any]) {
        guard WCSession.isSupported() else {
            DispatchQueue.main.async { self.status = .queued }
            return
        }
        WCSession.default.transferUserInfo(payload)
        DispatchQueue.main.async {
            self.status = .queued
        }
    }

    private func apply(context: [String: Any]) {
        let units = context["units"] as? String
        let goal = context["moveGoal"] as? Double ?? (context["moveGoal"] as? Int).map(Double.init)
        DispatchQueue.main.async {
            if let units {
                self.usesMetric = units == "metric"
            }
            if let goal, goal > 100 {
                self.moveGoal = goal
            }
        }
    }
}

extension WatchSyncService: WCSessionDelegate {
    func session(
        _ session: WCSession,
        activationDidCompleteWith activationState: WCSessionActivationState,
        error: Error?
    ) {
        DispatchQueue.main.async {
            self.isActivated = activationState == .activated
            self.isReachable = session.isReachable
            if activationState == .activated, !session.receivedApplicationContext.isEmpty {
                self.apply(context: session.receivedApplicationContext)
            }
        }
    }

    func sessionReachabilityDidChange(_ session: WCSession) {
        DispatchQueue.main.async {
            self.isReachable = session.isReachable
        }
    }

    func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String: Any]) {
        apply(context: applicationContext)
    }
}
