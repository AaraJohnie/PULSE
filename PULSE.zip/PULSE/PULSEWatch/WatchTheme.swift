import SwiftUI

enum WatchColor {
    static let background = Color(hex: 0x0B0D0C)
    static let surface = Color(hex: 0x171C19)
    static let surfaceRaised = Color(hex: 0x212823)
    static let sage = Color(hex: 0xB5D8BE)
    static let sageDeep = Color(hex: 0x628B6F)
    static let ivory = Color(hex: 0xF2F0E9)
    static let secondary = Color(hex: 0xA6B1AA)
    static let tertiary = Color(hex: 0x737E77)
    static let gold = Color(hex: 0xE4CB9A)
    static let blue = Color(hex: 0x9CC2CC)
    static let danger = Color(hex: 0xE2A294)
    static let hairline = Color.white.opacity(0.08)
}

extension Color {
    init(hex: UInt32, opacity: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: opacity
        )
    }
}

enum WatchFont {
    static func number(_ size: CGFloat, weight: Font.Weight = .semibold) -> Font {
        .system(size: size, weight: weight, design: .rounded).monospacedDigit()
    }

    static func text(_ size: CGFloat, weight: Font.Weight = .regular) -> Font {
        .system(size: size, weight: weight, design: .default)
    }

    static let overline = Font.system(size: 10, weight: .semibold, design: .default)
    static let headline = Font.system(size: 15, weight: .semibold, design: .default)
    static let body = Font.system(size: 14, weight: .regular, design: .default)
    static let caption = Font.system(size: 12, weight: .medium, design: .default)
}

struct WatchScreen<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        ZStack {
            WatchColor.background
                .ignoresSafeArea()

            RadialGradient(
                colors: [WatchColor.sage.opacity(0.14), .clear],
                center: .topTrailing,
                startRadius: 4,
                endRadius: 220
            )
            .ignoresSafeArea()

            content
        }
    }
}

struct WatchCard<Content: View>: View {
    private let padding: CGFloat
    private let content: Content

    init(padding: CGFloat = 12, @ViewBuilder content: () -> Content) {
        self.padding = padding
        self.content = content()
    }

    var body: some View {
        content
            .padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(WatchColor.surface)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .strokeBorder(WatchColor.hairline, lineWidth: 1)
            )
    }
}

struct WatchPill: View {
    var text: String
    var symbol: String?
    var tint: Color = WatchColor.sage

    var body: some View {
        HStack(spacing: 4) {
            if let symbol {
                Image(systemName: symbol)
                    .font(.system(size: 9, weight: .bold))
            }
            Text(text.uppercased())
                .font(.system(size: 9, weight: .semibold))
                .tracking(0.6)
                .lineLimit(1)
        }
        .foregroundStyle(tint)
        .padding(.horizontal, 7)
        .padding(.vertical, 4)
        .background(Capsule().fill(tint.opacity(0.14)))
    }
}

struct WatchRing: View {
    var progress: Double
    var color: Color
    var lineWidth: CGFloat
    @State private var animated: Double = 0
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        ZStack {
            Circle()
                .stroke(color.opacity(0.18), lineWidth: lineWidth)

            Circle()
                .trim(from: 0, to: min(max(animated, 0), 1))
                .stroke(
                    color,
                    style: StrokeStyle(lineWidth: lineWidth, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
                .animation(.easeOut(duration: 0.9), value: animated)
        }
        .onAppear {
            animated = reduceMotion ? progress : 0
            if !reduceMotion {
                withAnimation(.easeOut(duration: 0.9)) { animated = progress }
            }
        }
        .onChange(of: progress) { _, newValue in
            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.7)) {
                animated = newValue
            }
        }
    }
}

struct WatchProgressBar: View {
    var value: Double
    var tint: Color = WatchColor.sage

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Capsule().fill(WatchColor.surfaceRaised)
                Capsule()
                    .fill(tint)
                    .frame(width: max(0, min(value, 1)) * geometry.size.width)
            }
        }
        .frame(height: 5)
    }
}

struct WatchScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.94 : 1)
            .opacity(configuration.isPressed ? 0.85 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

struct WatchPrimaryButton: View {
    var title: String
    var symbol: String? = nil
    var tint: Color = WatchColor.sage

    var body: some View {
        HStack(spacing: 6) {
            if let symbol {
                Image(systemName: symbol)
                    .font(.system(size: 13, weight: .bold))
            }
            Text(title)
                .font(.system(size: 14, weight: .semibold))
                .lineLimit(1)
                .minimumScaleFactor(0.8)
        }
        .foregroundStyle(WatchColor.background)
        .frame(maxWidth: .infinity)
        .padding(.vertical, 11)
        .background(Capsule().fill(tint))
    }
}

struct WatchMetricTile: View {
    var label: String
    var value: String
    var unit: String
    var symbol: String
    var tint: Color = WatchColor.secondary

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(spacing: 3) {
                Image(systemName: symbol)
                    .font(.system(size: 8, weight: .bold))
                Text(label.uppercased())
                    .font(.system(size: 8, weight: .semibold))
                    .tracking(0.5)
                    .lineLimit(1)
            }
            .foregroundStyle(tint)

            HStack(alignment: .firstTextBaseline, spacing: 2) {
                Text(value)
                    .font(WatchFont.number(19, weight: .semibold))
                    .foregroundStyle(WatchColor.ivory)
                    .lineLimit(1)
                    .minimumScaleFactor(0.6)
                Text(unit)
                    .font(.system(size: 9, weight: .medium))
                    .foregroundStyle(WatchColor.tertiary)
                    .lineLimit(1)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(8)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(WatchColor.surface)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(WatchColor.hairline, lineWidth: 1)
        )
    }
}

