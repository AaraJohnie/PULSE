import SwiftUI

struct WatchTodayView: View {
    @Environment(WatchHealthManager.self) private var health
    @Environment(WatchSyncService.self) private var sync

    @Binding var showingPicker: Bool

    private var dateLine: String {
        Date.now.formatted(.dateTime.weekday(.wide).day().month(.abbreviated))
    }

    private var moveProgress: Double {
        sync.moveGoal > 0 ? health.today.activeEnergy / sync.moveGoal : 0
    }

    private var exerciseProgress: Double {
        health.today.exerciseMinutes / 30
    }

    private var standProgress: Double {
        health.today.standHours / 12
    }

    var body: some View {
        WatchScreen {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    header

                    if let error = health.lastError {
                        errorCard(error)
                    }

                    if health.hasRequestedHealth {
                        activityCard
                    } else {
                        healthAccessCard
                    }

                    Button {
                        showingPicker = true
                    } label: {
                        WatchPrimaryButton(title: "Start workout", symbol: "play.fill")
                    }
                    .buttonStyle(WatchScaleButtonStyle())
                    .accessibilityHint("Choose a workout to begin")

                    HStack(spacing: 8) {
                        WatchMetricTile(
                            label: "Steps",
                            value: WatchFormat.number(health.today.steps),
                            unit: "steps",
                            symbol: "figure.walk",
                            tint: WatchColor.blue
                        )
                        WatchMetricTile(
                            label: "Active",
                            value: WatchFormat.number(health.today.activeEnergy),
                            unit: "kcal",
                            symbol: "flame.fill",
                            tint: WatchColor.sage
                        )
                    }

                    Text("Your rings, heart rate and workouts stay with you, even without your iPhone.")
                        .font(.system(size: 10))
                        .foregroundStyle(WatchColor.tertiary)
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                        .padding(.top, 2)
                }
                .padding(.horizontal, 8)
                .padding(.bottom, 12)
            }
            .scrollIndicators(.hidden)
        }
    }

    private var header: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 2) {
                Text("PULSE")
                    .font(.system(size: 11, weight: .bold))
                    .tracking(1.7)
                    .foregroundStyle(WatchColor.sage)
                Text(dateLine.uppercased())
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(WatchColor.secondary)
                    .lineLimit(1)
            }

            Spacer(minLength: 4)

            Button {
                Task { await health.refreshToday() }
            } label: {
                Group {
                    if health.isRefreshing {
                        ProgressView()
                            .tint(WatchColor.sage)
                    } else {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(WatchColor.secondary)
                    }
                }
                .frame(width: 26, height: 26)
                .background(Circle().fill(WatchColor.surface))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Refresh activity")
        }
    }

    private var activityCard: some View {
        WatchCard(padding: 11) {
            HStack(spacing: 10) {
                ZStack {
                    WatchRing(progress: moveProgress, color: WatchColor.sage, lineWidth: 8)
                    WatchRing(progress: exerciseProgress, color: WatchColor.gold, lineWidth: 8)
                        .padding(10)
                    WatchRing(progress: standProgress, color: WatchColor.blue, lineWidth: 8)
                        .padding(20)
                }
                .frame(width: 88, height: 88)

                VStack(alignment: .leading, spacing: 7) {
                    legend(
                        "Move",
                        value: "\(WatchFormat.number(health.today.activeEnergy))/\(WatchFormat.number(sync.moveGoal))",
                        color: WatchColor.sage
                    )
                    legend(
                        "Exercise",
                        value: "\(WatchFormat.number(health.today.exerciseMinutes))/30",
                        color: WatchColor.gold
                    )
                    legend(
                        "Stand",
                        value: "\(WatchFormat.number(health.today.standHours))/12",
                        color: WatchColor.blue
                    )
                }

                Spacer(minLength: 0)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Activity rings")
        .accessibilityValue(
            "Move \(Int(moveProgress * 100)) percent, exercise \(Int(exerciseProgress * 100)) percent, stand \(Int(standProgress * 100)) percent"
        )
    }

    private func legend(_ title: String, value: String, color: Color) -> some View {
        HStack(spacing: 4) {
            Circle()
                .fill(color)
                .frame(width: 5, height: 5)
            VStack(alignment: .leading, spacing: 0) {
                Text(title)
                    .font(.system(size: 9, weight: .medium))
                    .foregroundStyle(WatchColor.secondary)
                Text(value)
                    .font(WatchFont.number(10, weight: .semibold))
                    .foregroundStyle(WatchColor.ivory)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
        }
    }

    private func errorCard(_ message: String) -> some View {
        WatchCard(padding: 10) {
            HStack(alignment: .top, spacing: 7) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(WatchColor.gold)
                Text(message)
                    .font(.system(size: 10))
                    .foregroundStyle(WatchColor.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 2)
                Button {
                    health.dismissError()
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundStyle(WatchColor.tertiary)
                        .frame(width: 18, height: 18)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Dismiss error")
            }
        }
    }

    @ViewBuilder
    private var healthAccessCard: some View {
        if health.isHealthAvailable {
            Button {
                Task { await health.requestHealthAccess() }
            } label: {
                WatchCard(padding: 11) {
                    HStack(spacing: 9) {
                        Image(systemName: "heart.text.square.fill")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(WatchColor.sage)
                            .frame(width: 32, height: 32)
                            .background(Circle().fill(WatchColor.sage.opacity(0.14)))

                        VStack(alignment: .leading, spacing: 2) {
                            Text("Connect Apple Health")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundStyle(WatchColor.ivory)
                            Text("See your rings and save every workout.")
                                .font(.system(size: 10))
                                .foregroundStyle(WatchColor.secondary)
                                .lineLimit(2)
                        }

                        Spacer(minLength: 2)

                        Image(systemName: "chevron.right")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundStyle(WatchColor.tertiary)
                    }
                }
            }
            .buttonStyle(WatchScaleButtonStyle())
            .accessibilityHint("Requests access to Apple Health")
        } else {
            WatchCard(padding: 11) {
                HStack(spacing: 9) {
                    Image(systemName: "heart.slash")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(WatchColor.tertiary)
                        .frame(width: 32, height: 32)
                        .background(Circle().fill(WatchColor.surfaceRaised))

                    VStack(alignment: .leading, spacing: 2) {
                        Text("Health unavailable")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(WatchColor.ivory)
                        Text("Health data isn't available on this Apple Watch.")
                            .font(.system(size: 10))
                            .foregroundStyle(WatchColor.secondary)
                            .lineLimit(2)
                    }
                    Spacer(minLength: 0)
                }
            }
        }
    }
}
