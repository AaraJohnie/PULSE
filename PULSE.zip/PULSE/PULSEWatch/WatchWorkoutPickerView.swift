import SwiftUI

struct WatchWorkoutPickerView: View {
    @Environment(WatchHealthManager.self) private var health
    @Environment(\.dismiss) private var dismiss

    @State private var startingKind: WatchWorkoutKind?
    @State private var errorMessage: String?

    var body: some View {
        WatchScreen {
            ScrollView {
                VStack(alignment: .leading, spacing: 9) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Start a workout")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(WatchColor.ivory)
                        Text("PULSE tracks heart rate, active energy and distance as you move.")
                            .font(.system(size: 11))
                            .foregroundStyle(WatchColor.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(.bottom, 2)

                    ForEach(WatchWorkoutKind.allCases) { kind in
                        Button {
                            start(kind)
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: kind.symbol)
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundStyle(kind.tint)
                                    .frame(width: 32, height: 32)
                                    .background(Circle().fill(kind.tint.opacity(0.14)))

                                VStack(alignment: .leading, spacing: 1) {
                                    Text(kind.title)
                                        .font(.system(size: 14, weight: .semibold))
                                        .foregroundStyle(WatchColor.ivory)
                                    Text(kind.showsDistance ? "Distance · pace" : "Heart rate · energy")
                                        .font(.system(size: 9))
                                        .foregroundStyle(WatchColor.tertiary)
                                        .lineLimit(1)
                                }

                                Spacer(minLength: 4)

                                if startingKind == kind {
                                    ProgressView()
                                        .tint(WatchColor.sage)
                                } else {
                                    Image(systemName: "chevron.right")
                                        .font(.system(size: 10, weight: .bold))
                                        .foregroundStyle(WatchColor.tertiary)
                                }
                            }
                            .padding(.horizontal, 10)
                            .padding(.vertical, 7)
                            .background(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .fill(WatchColor.surface)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .strokeBorder(WatchColor.hairline, lineWidth: 1)
                            )
                        }
                        .buttonStyle(WatchScaleButtonStyle())
                        .disabled(startingKind != nil)
                        .accessibilityHint("Starts a \(kind.title.lowercased()) workout")
                    }
                }
                .padding(.horizontal, 6)
                .padding(.bottom, 12)
            }
            .scrollIndicators(.hidden)
        }
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Close") { dismiss() }
            }
        }
        .alert("Couldn't start workout", isPresented: errorBinding) {
            Button("OK") {
                errorMessage = nil
                health.dismissError()
            }
        } message: {
            Text(errorMessage ?? "Please try again.")
        }
    }

    private var errorBinding: Binding<Bool> {
        Binding(
            get: { errorMessage != nil },
            set: { showing in
                if !showing {
                    errorMessage = nil
                    health.dismissError()
                }
            }
        )
    }

    private func start(_ kind: WatchWorkoutKind) {
        guard startingKind == nil else { return }
        startingKind = kind
        Task {
            let didStart = await health.startWorkout(kind: kind)
            startingKind = nil
            if didStart {
                dismiss()
            } else {
                errorMessage = health.lastError ?? "PULSE couldn't begin the workout."
            }
        }
    }
}
